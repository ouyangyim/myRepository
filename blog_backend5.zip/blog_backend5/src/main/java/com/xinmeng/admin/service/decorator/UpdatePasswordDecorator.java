package com.xinmeng.admin.service.decorator;

import cn.hutool.core.util.ObjUtil;
import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.entity.User;
import org.springframework.stereotype.Component;

/**
 *  修改密码 装饰类
 */
//@Component
public class UpdatePasswordDecorator extends UpdatePasswordComponent{

    private UpdatePasswordComponent component;

    public void updatePasswordDecorator(UpdatePasswordComponent component){
        this.component = component;
    }

    @Override
    public String updatePassword(User user, PasswordChangeDTO request) {
        if (!ObjUtil.isNull(component)){
            return component.updatePassword(user, request);
        }
        return null;
    }

}
