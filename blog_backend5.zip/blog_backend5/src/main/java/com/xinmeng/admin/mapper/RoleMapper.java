package com.xinmeng.admin.mapper;

import com.xinmeng.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Repository
public interface RoleMapper extends BaseMapper<Role> {

    List<String> getRoleNameByUserId(Integer id);

    Integer getRoleIdByName(String roleName);
}
