package com.xinmeng.admin.dto;

import com.xinmeng.entity.Article;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDTO {

    private Integer id;

    /**
     * 分类名
     */
    private String categoryName;


    /**
     * 分类对应的文章集合
     */
    private List<Article> articleList;


}
