package com.xinmeng.admin.controller;


import com.xinmeng.pubick.service.UploadService;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import static com.xinmeng.constant.ResultConstant.UPLOAD_SUCCESS;

@Api(tags = "上传图片")
@RestController
@RequestMapping("/upload")
public class UploadController {

    @Autowired
    private UploadService uploadService;

    @ApiOperation("上传图片")
    @PostMapping("/upload")
    public Result<?> uploadImg(@RequestParam("img") MultipartFile img){  // , @RequestParam("token") String token
        String url = uploadService.uploadImg(img);
        return Result.ok(url, UPLOAD_SUCCESS);
    }


}
