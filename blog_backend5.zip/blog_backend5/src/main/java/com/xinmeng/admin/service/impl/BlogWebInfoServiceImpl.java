package com.xinmeng.admin.service.impl;

import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.admin.service.BlogWebInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BlogWebInfoServiceImpl implements BlogWebInfoService {

    @Autowired
    private UserMapper userMapper;


    @Override
    public Integer getBlogCount() {
        Integer count = userMapper.selectCount(null);
        return count;
    }

}
