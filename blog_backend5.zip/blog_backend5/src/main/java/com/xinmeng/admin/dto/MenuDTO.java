package com.xinmeng.admin.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.xinmeng.entity.Menu;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MenuDTO {

    private Integer id;
    /**
     * 菜单名
     */
    private String menuName;
    /**
     * 路径
     */
    private String path;
    /**
     * 组件
     */
    private String component;
    /**
     * 重定向
     */
    private String redirect;
    /**
     * 展示的标题
     */
    private String title;
    /**
     * 菜单需要的字体图标
     */
    private String icon;
    /**
     * 父id
     */
    private Integer parentId;
    /**
     * 是否是叶子节点
     */
    private String isLeaf;
    /**
     * 是否隐藏, 隐藏1, 不隐藏0
     */
    private Integer hidden;

    /**
     * 子节点
     */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)   // 如果是null，就不返回
    private List<MenuDTO> children;   // 此处属性名 要和前端prop的值一样

    private Map<String, Object> meta;

    public Map<String, Object> getMeta(){
        meta = new HashMap<>();
        meta.put("title", title);
        meta.put("icon", icon);
        return meta;
    }


}
