package com.xinmeng.admin.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArticleDTO {

    private Integer id;

    /**
     * 作者
     */
    private String author;

    /**
     * 文章名
     */
    private String articleName;

    /**
     * 是否置顶 是1 否0
     */
    private Integer isTop;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 修改时间
     */
    private String updateTime;

    /**
     * 文章状态
     */
    private String status;

    /**
     * 分类id集合
     */
    private Integer categoryId;

    /**
     *  标签id集合
     */
    private List<Integer> tagIdList;


    /**
     * 文章缩略图
     */
    private String thumbnail;


    /**
     *  文章内容
     */
    private String content;


}
