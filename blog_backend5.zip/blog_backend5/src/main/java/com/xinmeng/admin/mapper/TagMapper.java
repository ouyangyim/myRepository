package com.xinmeng.admin.mapper;

import com.xinmeng.entity.Article;
import com.xinmeng.entity.Tag;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Repository
public interface TagMapper extends BaseMapper<Tag> {

    List<String> getTagNameByArticleId(Integer id);

    List<Article> getArticleListByTagId(Integer id);

    List<Tag> getTopTags();

    Integer getTagIdByName(String tagName);

}
