package com.xinmeng.admin.dto;


import com.xinmeng.dto.ParameterDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO extends ParameterDTO {
    /**
     * id
     */
    private Integer id;
    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private String password;
    /**
     * 邮箱号
     */
    private String mail;
    /**
     * 电话号码
     */
    private String tel;
    /**
     * 头像
     */
    private String avatar;

    /**
     * 用户状态(是否禁用 禁用1 不禁用0)
     */
    private Integer status;


    /**
     * 角色id集合
     */
    private List<Integer> roleIdList;

}
