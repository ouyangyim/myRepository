package com.xinmeng.admin.service.decorator.UpdatePasswordConcreteDecorator;

import com.xinmeng.admin.service.decorator.UpdatePasswordComponent;
import com.xinmeng.admin.service.decorator.UpdatePasswordDecorator;
import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.entity.User;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.RegexConstant.PASSWORDREGEX;
import static com.xinmeng.constant.ResultConstant.PASSWORD_FORMAT_ERROR;

/**
 *  具体装饰类 (判断新密码的格式是否正确)
 */
//@Component
public class JudgePasswordFormatConcreteDecorator extends UpdatePasswordDecorator {

    @Override
    public void updatePasswordDecorator(UpdatePasswordComponent component) {
        super.updatePasswordDecorator(component);
    }

    @Override
    public String updatePassword(User user, PasswordChangeDTO request) {
        if(request.getNewPassword().matches(PASSWORDREGEX)){
               return super.updatePassword(user, request);
        }
        // 新密码格式不符
        return PASSWORD_FORMAT_ERROR;
    }

}
