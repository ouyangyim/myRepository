package com.xinmeng.admin.controller;

import com.xinmeng.admin.dto.MenuDTO;
import com.xinmeng.admin.service.IMenuService;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Api(tags = "菜单管理接口")
@RestController
@RequestMapping("/menu")
public class MenuController {

    @Autowired
    private IMenuService menuService;


    @ApiOperation("查询所有菜单")
    @GetMapping
    public Result<?> getAllMenu(){
        List<MenuDTO> menuDTOList = menuService.getAllMenu();
        if(menuDTOList != null){
            return Result.ok(menuDTOList);
        }
        return Result.fail();
    }


}
