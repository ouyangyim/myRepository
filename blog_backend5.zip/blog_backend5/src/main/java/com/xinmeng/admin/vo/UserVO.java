package com.xinmeng.admin.vo;

import com.xinmeng.admin.dto.RoleDTO;
import com.xinmeng.entity.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserVO {

    private Integer id;

    /**
     * 用户名
     */
    private String username;
    /**
     * 邮箱号
     */
    private String mail;
    /**
     * 电话号码
     */
    private String tel;
    /**
     * 头像
     */
    private String avatar;

    /**
     * 用户状态(是否禁用 禁用1 不禁用0)
     */
    private Integer status;
    /**
     * 账号创建时间
     */
    private String createTime;
    /**
     * 账号信息修改时间
     */
    private String updateTime;
    /**
     * 账户最近登录时间
     */
    private String loginTime;

    /**
     * 用户的角色名集合
     */
    private List<String> roleNameList;
    /**
     * 用户登录ip
     */
    private String userLoginIp;
    /**
     * 用户描述
     */
    private String description;



}
