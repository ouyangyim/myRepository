package com.xinmeng.admin.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;


/**
 *  角色管理列表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleVO {

    /**
     * id
     */
    private Integer id;
    /**
     * 角色名
     */
    private String roleName;
    /**
     * 角色描述
     */
    private String roleDesc;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 修改时间
     */
    private String updateTime;
    /**
     * 角色状态 禁用1 不禁用0
     */
    private Integer status;




}
