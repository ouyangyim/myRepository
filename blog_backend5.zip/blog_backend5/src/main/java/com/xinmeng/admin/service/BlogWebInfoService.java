package com.xinmeng.admin.service;

public interface BlogWebInfoService {
    Integer getBlogCount();
}
