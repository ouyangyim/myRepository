package com.xinmeng.admin.service;

import com.xinmeng.admin.vo.TagVO;
import com.xinmeng.entity.Tag;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
public interface ITagService extends IService<Tag> {


    List<String> getTagNameByArticleId(Integer id);

    List<TagVO> getAllTagList();

    void addTag(Tag tag);

    void deleteTagById(Integer id);
}
