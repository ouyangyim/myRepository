package com.xinmeng.admin.controller;

import com.xinmeng.admin.service.ICategoryService;
import com.xinmeng.admin.service.ITagService;
import com.xinmeng.admin.vo.TagVO;
import com.xinmeng.entity.Category;
import com.xinmeng.entity.Message;
import com.xinmeng.entity.Tag;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import sun.security.mscapi.CPublicKey;

import java.util.List;

import static com.xinmeng.constant.CategoryConstant.ADD_CATEGORY_SUCCESS;
import static com.xinmeng.constant.CategoryConstant.DELETE_CATEGORY_SUCCESS;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Api(tags = "标签管理接口")
@RestController
@RequestMapping("/tag")
public class TagController {

    @Autowired
    private ITagService tagService;


    @ApiOperation(value = "查询所有标签")
    @GetMapping("/all")
    public Result<?> getAllTagList(){
        List<TagVO> tagListVO = tagService.getAllTagList();
        return Result.ok(tagListVO);
    }

    @ApiOperation(value = "新增分类")
    @PostMapping
    public Result<?> addTaf(@RequestBody Tag tag){
        tagService.addTag(tag);
        return Result.ok(ADD_CATEGORY_SUCCESS);
    }

    @ApiOperation(value = "删除分类")
    @DeleteMapping("/{id}")
    public Result<?> deleteTagById(@PathVariable("id") Integer id){
        tagService.deleteTagById(id);
        return Result.ok(DELETE_CATEGORY_SUCCESS);
    }

    @ApiOperation(value = "查询标签总量")
    @GetMapping("/count")
    public Result<?> getTagCount(){
        List<Tag> tagList = tagService.list();
        Integer data = tagList.size();
        return Result.ok(data);
    }


}
