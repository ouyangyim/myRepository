package com.xinmeng.admin.service;

import com.xinmeng.admin.vo.CategoryVO;
import com.xinmeng.entity.Category;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
public interface ICategoryService extends IService<Category> {


    String getCategoryNameByArticleId(Integer id);

    void addCategory(Category category);

    void deleteCategoryById(Integer id);

    List<CategoryVO> getAllCategoryList();
}
