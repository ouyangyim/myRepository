package com.xinmeng.admin.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xinmeng.admin.dto.TagDTO;
import com.xinmeng.admin.mapper.ArticleTagMapper;
import com.xinmeng.admin.vo.TagVO;
import com.xinmeng.entity.ArticleTag;
import com.xinmeng.entity.Tag;
import com.xinmeng.admin.mapper.TagMapper;
import com.xinmeng.admin.service.ITagService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.util.List;


/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Service
public class TagServiceImpl extends ServiceImpl<TagMapper, Tag> implements ITagService {

    @Resource
    private ArticleTagMapper articleTagMapper;

    @Override
    public List<String> getTagNameByArticleId(Integer id) {
        List<String> tagNameList = this.baseMapper.getTagNameByArticleId(id);
        return tagNameList;
    }

    @Override
    public List<TagVO> getAllTagList() {
        List<Tag> tagList = this.list();
        List<TagDTO> tagDTOList = BeanCopyUtils.copyList(tagList, TagDTO.class);
        for (TagDTO tagDTO : tagDTOList) {
            tagDTO.setArticleList(this.baseMapper.getArticleListByTagId(tagDTO.getId()));
        }
        List<TagVO> tagVOList = BeanCopyUtils.copyList(tagDTOList, TagVO.class);
        return tagVOList;
    }

    @Override
    public void addTag(Tag tag) {
        // 创建日期
        tag.setCreateTime(DateUtil.now());
        // 添加到用户表中
        this.baseMapper.insert(tag);
    }

    @Override
    @Transactional
    public void deleteTagById(Integer id) {
        // 根据id删除 用户表信息
        this.baseMapper.deleteById(id);
        // 删除文章分类表信息
        LambdaQueryWrapper<ArticleTag> lqw = new LambdaQueryWrapper<>();
        lqw.eq(ArticleTag::getTagId, id);
        articleTagMapper.delete(lqw);
    }


}
