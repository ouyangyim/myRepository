package com.xinmeng.admin.service.decorator.AddUserConcreteDecorator;

import cn.hutool.core.convert.Convert;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xinmeng.admin.service.decorator.AddUserComponent;
import com.xinmeng.admin.service.decorator.AddUserDecorator;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.BeanCopyUtils;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.ResultConstant.USERNAME_EXIST;

/**
 *  新增用户 具体装饰类 (判断该用户名是否唯一)
 */
@Component
public class JudgeUserIfExitConcreteDecorator extends AddUserDecorator {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Override
    public void addUserDecorator(AddUserComponent component) {
        super.addUserDecorator(component);
    }

    @Override
    public String addUser(UserDTO userDTO) {
        User user = Convert.convert(User.class, userDTO);
        // 查询用户名是否唯一(通过用户名查询用户，看数据库中是否存在该用户名的用户)
        LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
        lqw.eq(User::getUsername, user.getUsername());
        User user1 = userMapper.selectOne(lqw);
        exceptionUtils.exceptionDeal(user1!=null, ResultEnum.USERNAME_EXIST);
        return super.addUser(userDTO);
    }

}
