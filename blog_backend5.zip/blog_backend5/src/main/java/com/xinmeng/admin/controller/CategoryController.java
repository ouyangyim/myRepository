package com.xinmeng.admin.controller;

import com.xinmeng.admin.service.ICategoryService;
import com.xinmeng.admin.vo.CategoryVO;
import com.xinmeng.entity.Category;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.xinmeng.constant.CategoryConstant.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Api(tags = "分类管理接口")
@RestController
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    private ICategoryService categoryService;


    @ApiOperation(value = "查询所有分类")
    @GetMapping("/all")
    public Result<?> getAllCategoryList(){
        List<CategoryVO> categoryVOList = categoryService.getAllCategoryList();
        return Result.ok(categoryVOList);
    }


    @ApiOperation(value = "新增分类")
    @PostMapping
    public Result<?> addCategory(@RequestBody Category category){
        categoryService.addCategory(category);
        return Result.ok(ADD_CATEGORY_SUCCESS);
    }

    @ApiOperation(value = "删除分类")
    @DeleteMapping("/{id}")
    public Result<?> deleteCategoryById(@PathVariable("id") Integer id){
        categoryService.deleteCategoryById(id);
        return Result.ok(DELETE_CATEGORY_SUCCESS);
    }

    @ApiOperation(value = "查询分类总量")
    @GetMapping("/count")
    public Result<?> getCategoryCount(){
        List<Category> categoryList = categoryService.list();
        Integer data = categoryList.size();
        return Result.ok(data);
    }


}
