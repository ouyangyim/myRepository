package com.xinmeng.admin.service.impl;

import com.xinmeng.entity.RoleMenu;
import com.xinmeng.admin.mapper.RoleMenuMapper;
import com.xinmeng.admin.service.IRoleMenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Service
public class RoleMenuServiceImpl extends ServiceImpl<RoleMenuMapper, RoleMenu> implements IRoleMenuService {

}
