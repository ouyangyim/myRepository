package com.xinmeng.admin.service;

import com.xinmeng.admin.dto.MenuDTO;
import com.xinmeng.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
public interface IMenuService extends IService<Menu> {

    List<MenuDTO> getAllMenu();

    List<MenuDTO> getMenuListByUserId(Integer userId);
}
