package com.xinmeng.admin.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.DesensitizedUtil;
import cn.hutool.core.util.ObjUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xinmeng.admin.service.decorator.AddUserComponent;
import com.xinmeng.admin.service.decorator.AddUserConcreteDecorator.JudgeUserEmailOrTelIfRegisteredConcreteDecorator;
import com.xinmeng.admin.service.decorator.AddUserConcreteDecorator.JudgeUserIfExitConcreteDecorator;
import com.xinmeng.admin.dto.MenuDTO;
import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.admin.mapper.UserRoleMapper;
import com.xinmeng.admin.service.IMenuService;
import com.xinmeng.admin.vo.UserVO;
import com.xinmeng.dto.AuthenDTO;
import com.xinmeng.dto.InfoByTokenDTO;
import com.xinmeng.dto.TokenDTO;
import com.xinmeng.vo.PageVO;
import com.xinmeng.entity.User;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.admin.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.entity.UserRole;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.templateMethod.PageConcrete.PageUserConcrete;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.util.JwtUtils;
import com.xinmeng.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;

import static com.xinmeng.constant.RegexConstant.*;
import static com.xinmeng.constant.ResultConstant.*;
import static com.xinmeng.enums.ResultEnum.AUTHEN_FAILURE;
import static com.xinmeng.enums.ResultEnum.CURRENT_PASSWORD_ERROR;


/**
 * <p>
 *  用户 业务层
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Service
@Import(PageUserConcrete.class)
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {


    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Resource
    private UserRoleMapper userRoleMapper;

    @Autowired
    private IMenuService menuService;

    @Autowired
    private AddUserComponent addUserComponent;

    @Autowired
    private JudgeUserIfExitConcreteDecorator judgeUserIfExitDecorator;

    @Autowired
    private JudgeUserEmailOrTelIfRegisteredConcreteDecorator judgeEmailOrTelIfRegisteredDecorator;

    @Autowired
    private PageUserConcrete pageUserConcrete;

    @Autowired
    private ExceptionUtils exceptionUtils;


    /**
     * 用户登录
     * @param user
     * @return
     */
    @Override
    public TokenDTO login(UserDTO user) {
        // 判断用户是否已经注册 (这里是根据user进行数据查询操作, 数据查询不适合aop)
        LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
        lqw.eq(User::getUsername, user.getUsername());
        User loginUser = this.baseMapper.selectOne(lqw);
        if(!ObjUtil.isNull(loginUser) && passwordEncoder.matches(user.getPassword(), loginUser.getPassword())){
            // jwt 生成token
            loginUser.setPassword(null);    // 设置为null 表示不作修改
            String token = jwtUtils.createToken(loginUser);
            // 返回数据
            return new TokenDTO(token);
        }
        return null;
    }


    /**
     * 通过token 获取用户信息
     * @param token
     * @return
     */
    @Override
    public InfoByTokenDTO getUserInfo(String token) {
        User user = null;
        try {
            // 反序列化
            user = jwtUtils.parseToken(token, User.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
       if(!ObjUtil.isNull(user)){
           // 角色
           List<String> roleNameList = this.baseMapper.getRoleNameByUserId(user.getId());
           // 菜单(登录的用户可访问的菜单)
           List<MenuDTO> menuList = menuService.getMenuListByUserId(user.getId());
           return new InfoByTokenDTO(user.getUsername(), user.getAvatar(), roleNameList, menuList);
       }
        return null;
    }


    /**
     * 分页条件查询 （模板方法模式）
     * @return
     */
    @Override
    public PageVO<UserVO> getUserList(Integer pageSize, Integer currentPage,
                                      String username, String tel, String mail, String roleName) {

        return pageUserConcrete.pageTemplate(pageSize, currentPage, username, tel, mail, roleName);

    }


    /**
     * 新增用户 （装饰模式）
     * @param userDTO
     */
    @Override
    @Transactional
    public String addUser(UserDTO userDTO){

        // 判断用户名是否已经被注册 —— 判断邮箱号码是否已经被注册
        judgeEmailOrTelIfRegisteredDecorator.addUserDecorator(addUserComponent);
        judgeUserIfExitDecorator.addUserDecorator(judgeEmailOrTelIfRegisteredDecorator);
        return judgeUserIfExitDecorator.addUser(userDTO);

    }


    /**
     * 修改用户信息(需要判断用户名是否存在)
     * @param userDTO
     */
    @Override
    @Transactional
    public void updateUser(UserDTO userDTO) {
        // 转为User对象
        User user = Convert.convert(User.class, userDTO);
        // 查询用户名是否存在(数据库中是否存在该用户名的用户)
        LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
        lqw.eq(User::getUsername, user.getUsername());
        User user1 = this.baseMapper.selectOne(lqw);     // 每个用户名唯一,所以这里查一个即可
        // 如果存在用户名为此时输入用户名的用户, 且根据id判断该用户不是本人
        exceptionUtils.exceptionDeal(user1!=null && user1.getId()!=user.getId(), ResultEnum.USERNAME_EXIST);
        // 最近修改日期
        user.setUpdateTime(DateUtil.now());
        // 修改 用户表
        this.baseMapper.updateById(user);
        // 修改 用户角色表
        // 删除原有信息
        LambdaQueryWrapper<UserRole> lqw1 = new LambdaQueryWrapper<>();
        lqw1.eq(UserRole::getUserId, userDTO.getId());
        userRoleMapper.delete(lqw1);
        // 设置新的信息
        List<Integer> roleIdList = userDTO.getRoleIdList();
        for (Integer roleId : roleIdList) {
            userRoleMapper.insert(new UserRole(null, user.getId(), roleId));
        }
    }


    /**
     * 通过id得到用户信息（得到前端页面中要编辑的行 对应的 用户信息，用于表单信息回填）
     * @param id
     * @return
     */
    @Override
    public UserDTO getUserById(Integer id) {
        // 得到要修改的该列用户 的 基本信息
        User user = this.baseMapper.selectById(id);
        // 转为DTO对象
        UserDTO userDTO = Convert.convert(UserDTO.class, user);
        // 得到 用户对象 对应的 角色id集合
        // 用户 -> 用户角色表 -> 角色id
        List<Integer> roleIdList = userRoleMapper.getRoleIdListByUserId(id);
        userDTO.setRoleIdList(roleIdList);
        return userDTO;
    }


    /**
     * 删除用户
     * @param id
     */
    @Override
    @Transactional
    public void deleteUserById(Integer id) {
        // 根据id删除 用户表信息
        this.baseMapper.deleteById(id);
        // 删除用户角色表信息
        LambdaQueryWrapper<UserRole> lqw = new LambdaQueryWrapper<>();
        lqw.eq(UserRole::getUserId, id);
        userRoleMapper.delete(lqw);
    }


    /**
     * 根据用户名查询用户信息
     * @param name
     * @return
     */
    @Override
    public UserDTO getUserInfoByName(String name, boolean flag) {
        User user = this.baseMapper.getUserByName(name);
        UserDTO userDTO = Convert.convert(UserDTO.class, user);
        List<Integer> roleIdList = userRoleMapper.getRoleIdListByUserId(userDTO.getId());
        userDTO.setRoleIdList(roleIdList);
        if (flag){
            // 手机号码、邮箱进行信息脱敏处理
            userDTO.setTel(DesensitizedUtil.mobilePhone(userDTO.getTel()));
            userDTO.setMail(DesensitizedUtil.email(userDTO.getMail()));
        }
        return userDTO;
    }


    /**
     * 修改密码 （装饰模式）
     * @param user
     * @param request
     */
    @Override
    public String updatePassword(User user, PasswordChangeDTO request) {

        // 比较原密码是否正确
        exceptionUtils.exceptionDeal(passwordEncoder.matches(request.getCurrentPassword(), user.getPassword()), CURRENT_PASSWORD_ERROR);    // 比较原密码是否正确
        exceptionUtils.exceptionDeal(request.getNewPassword().matches(PASSWORDREGEX), ResultEnum.PASSWORD_FORMAT_ERROR);                    // 校验新密码是否符合要求
        exceptionUtils.exceptionDeal(request.getNewPassword().equals(request.getConfirmPassword()), ResultEnum.DIFFERENT_PASSWORD_ERROR);   // 比较两次密码是否相同
        // 密码符合，可以修改
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        this.baseMapper.updateById(user);
        return UPDATE_PASSWORD_SUCCESS;

    }


    /**
     * 修改头像
     * @param name
     * @param imageUrl
     */
    @Override
    public void updateAvatar(String name, String imageUrl) {
        User user = this.baseMapper.getUserByName(name);
        user.setAvatar(imageUrl);
        this.baseMapper.updateById(user);
    }


    /**
     * 用户身份认证
     * @param authenDTO
     * @return
     */
    @Override
    public Result<?> haveAuthenticated(AuthenDTO authenDTO, String name) {
        User user = this.baseMapper.getUserByName(name);
        exceptionUtils.exceptionDeal(!passwordEncoder.matches(authenDTO.getPassword(), user.getPassword()), AUTHEN_FAILURE);
        return Result.ok(true, AUTHEN_SUCCESS);
    }


}
