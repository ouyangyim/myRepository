package com.xinmeng.admin.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.BoundedPriorityQueue;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xinmeng.admin.dto.ArticleDTO;
import com.xinmeng.admin.mapper.*;
import com.xinmeng.admin.service.IArticleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.admin.service.ICategoryService;
import com.xinmeng.admin.service.ITagService;
import com.xinmeng.admin.vo.ArticleVO;
import com.xinmeng.blog.vo.ArticleLatestVO;
import com.xinmeng.entity.*;
import com.xinmeng.templateMethod.PageConcrete.PageArticleConcrete;
import com.xinmeng.util.BeanCopyUtils;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.vo.PageVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.util.*;
import static com.xinmeng.constant.ArticleConstant.LATEST_ARTICLE;


/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Slf4j
@Service
@Import(PageArticleConcrete.class)
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, Article> implements IArticleService {

    @Autowired
    private ITagService tagService;

    @Autowired
    private ICategoryService categoryService;

    @Resource
    private ArticleTagMapper articleTagMapper;

    @Resource
    private ArticleCategoryMapper articleCategoryMapper;

    @Autowired
    private PageArticleConcrete pageArticleConcrete;

    @Autowired
    private CommonUtils commonUtils;


    /**
     * 搜索栏查询 （模板方法模式）
     * @param pageSize
     * @param currentPage
     * @param articleName
     * @param author
     * @return
     */
    @Override
    public PageVO<ArticleVO> getArticleList(Integer pageSize, Integer currentPage,
                                 String articleName, String author,
                                 String tagName, String categoryName) {

        return pageArticleConcrete.pageTemplate(pageSize, currentPage, articleName, author, tagName, categoryName);

    }


    /**
     *  根据id查询 文章信息  (用于表单的回填)
     * @param id
     * @return
     */
    @Override
    public ArticleDTO getArticleById(Integer id) {
        // 得到要修改的该列用户 的 基本信息
        Article article = this.baseMapper.selectById(id);
        // 转为DTO对象
        ArticleDTO articleDTO = new ArticleDTO();
        BeanUtil.copyProperties(article, articleDTO);
        // 得到 文章对象 对应的 标签id集合
        // 文章 -> 文章标签表 -> 标签id
        List<Integer> tagIdList = articleTagMapper.getTagIdListByArticleId(id);
        articleDTO.setTagIdList(tagIdList);
        // 得到 分类集合
        Integer categoryId = articleCategoryMapper.getCategoryIdByArticleId(id);
        articleDTO.setCategoryId(categoryId);
        return articleDTO;
    }


    /**
     * 编辑文章信息
     * @param articleDTO
     */
    @Override
    @Transactional
    public void updateArticle(ArticleDTO articleDTO) {
        // 转为Article对象
        Article article = Convert.convert(Article.class, articleDTO);
        // 最近修改日期 yyyy-MM-dd HH-mm-ss
        article.setUpdateTime(DateUtil.now());
        // 修改 文章表
        this.baseMapper.updateById(article);
        // 修改 文章标签表
        // 删除原有信息
        LambdaQueryWrapper<ArticleTag> lqw1 = new LambdaQueryWrapper<>();
        lqw1.eq(ArticleTag::getArticleId, articleDTO.getId());
        articleTagMapper.delete(lqw1);
        // 设置新的信息
        List<Integer> tagIdList = articleDTO.getTagIdList();
        for (Integer tagId : tagIdList) {
            articleTagMapper.insert(new ArticleTag(null, article.getId(), tagId));
        }
        // 修改 文章分类表
        // 删除原有信息
        LambdaQueryWrapper<ArticleCategory> lqw2 = new LambdaQueryWrapper<>();
        lqw2.eq(ArticleCategory::getArticleId, articleDTO.getId());
        articleCategoryMapper.delete(lqw2);
        // 设置新的信息
        Integer categoryId = articleDTO.getCategoryId();
        articleCategoryMapper.insert(new ArticleCategory(null, article.getId(), categoryId));
    }

    /**
     * 删除文章
     * @param id
     */
    @Override
    @Transactional
    public void deleteArticleById(Integer id) {
        // 根据id删除 文章表信息
        this.baseMapper.deleteById(id);
        // 删除文章标签表信息
        LambdaQueryWrapper<ArticleTag> lqw = new LambdaQueryWrapper<>();
        lqw.eq(ArticleTag::getArticleId, id);
        articleTagMapper.delete(lqw);
        // 删除文章分类表信息
        LambdaQueryWrapper<ArticleCategory> lqw2 = new LambdaQueryWrapper<>();
        lqw2.eq(ArticleCategory::getArticleId, id);
        articleCategoryMapper.delete(lqw2);
    }


    /**
     * 获取最新文章
     * @return
     */
    @Override
    public List<ArticleVO> getLatestArticle() {
        LambdaQueryWrapper<Article> lqw = new LambdaQueryWrapper<>();
    //  lqw.orderByDesc(Article::getCreateTime);
        List<Article> articleList = this.baseMapper.selectList(lqw);
        List<ArticleVO> articleVOList = BeanCopyUtils.copyList(articleList, ArticleVO.class);  // 这里VO只有时间倒序和文章名
        // 获取 标签 和 分类
        for (ArticleVO articleVO : articleVOList) {
            articleVO.setTagNameList(tagService.getTagNameByArticleId(articleVO.getId()));
            articleVO.setCategoryName(categoryService.getCategoryNameByArticleId(articleVO.getId()));
        }
        // 获取最新的五篇文章
    //  return ListUtil.sub(articleVOList, 0, 5);
        // 初始化队列，使用自定义的比较器
        BoundedPriorityQueue<ArticleVO> queue = new BoundedPriorityQueue<>(5, (o1, o2) -> o2.getCreateTime().compareTo(o1.getCreateTime()));
        // 遍历集合，把前五个存入队列
        for (ArticleVO articleVO : articleVOList) {
            queue.offer(articleVO);
        }
        return queue.toList();
    }

    /**
     * 新增文章
     * @param articleDTO
     */
    @Override
    @Transactional
    public void addArticle(ArticleDTO articleDTO){
        // 创建时间
        articleDTO.setCreateTime(DateUtil.now());
        // 敏感词过滤
        String content = commonUtils.sensitiveWordFilter(articleDTO.getContent());
        articleDTO.setContent(content);
        Article article = Convert.convert(Article.class, articleDTO);
        // 添加到文章表
        this.baseMapper.insert(article);
        // 添加到文章标签表
        List<Integer> tagIdList = articleDTO.getTagIdList();
        for (Integer tagId : tagIdList) {
            articleTagMapper.insert(new ArticleTag(null, article.getId(), tagId));
        }
        // 添加到文章分类表
        Integer categoryId = articleDTO.getCategoryId();
        articleCategoryMapper.insert(new ArticleCategory(null, article.getId(), categoryId));
    }



}



