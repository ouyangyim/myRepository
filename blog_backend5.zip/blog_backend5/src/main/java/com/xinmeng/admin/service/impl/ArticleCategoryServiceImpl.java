package com.xinmeng.admin.service.impl;

import com.xinmeng.entity.ArticleCategory;
import com.xinmeng.admin.mapper.ArticleCategoryMapper;
import com.xinmeng.admin.service.IArticleCategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Service
public class ArticleCategoryServiceImpl extends ServiceImpl<ArticleCategoryMapper, ArticleCategory> implements IArticleCategoryService {




}
