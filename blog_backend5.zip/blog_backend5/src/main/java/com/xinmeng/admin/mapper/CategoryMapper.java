package com.xinmeng.admin.mapper;

import com.xinmeng.entity.Article;
import com.xinmeng.entity.Category;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Repository
public interface CategoryMapper extends BaseMapper<Category> {


    String getCategoryNameByArticleId(Integer id);

    List<Article> getArticleListByCategoryId(Integer id);

    List<Category> getTopCategories();

    Integer getCategoryIdByName(String categoryName);
}
