package com.xinmeng.admin.controller;

import cn.hutool.core.util.StrUtil;
import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.admin.service.IUserService;
import com.xinmeng.annotation.ParameterValidation;
import com.xinmeng.dto.AuthenDTO;
import com.xinmeng.dto.InfoByTokenDTO;
import com.xinmeng.dto.TokenDTO;
import com.xinmeng.vo.PageVO;
import com.xinmeng.entity.User;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.xinmeng.constant.JwtConstant.TOKEN;
import static com.xinmeng.constant.RegexConstant.*;
import static com.xinmeng.constant.RegexConstant.TELREGEX;
import static com.xinmeng.constant.ResultConstant.*;
import static com.xinmeng.constant.ResultConstant.LOGIN_SUCCESS;
import static com.xinmeng.enums.ResultEnum.*;


/**
 * <p>
 *  用户管理
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Api(tags = "用户管理接口")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private IUserService userService;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ExceptionUtils exceptionUtils;


    @ApiOperation(value = "查询所有用户")
    @GetMapping("/all")
    public Result<List<User>> getAllUser(){
        List<User> list = userService.list();
        return Result.ok(list);
    }


    @ApiOperation(value = "用户登录")
    @PostMapping("/login")
    public Result<?> login(@RequestBody UserDTO user){
        TokenDTO data = userService.login(user);
        exceptionUtils.exceptionDeal(data==null, LOGIN_FAILURE);
        return Result.ok(data, LOGIN_SUCCESS);
    }


    @ApiOperation(value = "由前端传来的token获取用户信息")
    @GetMapping("/info")
    public Result<?> getUserInfo(@RequestParam("token") String token){
        InfoByTokenDTO data = userService.getUserInfo(token);
        exceptionUtils.exceptionDeal(data==null, FAIL);
        return Result.ok(data);
    }


    @ApiOperation(value = "注销")
    @PostMapping("/logout")
    public Result<?> logout(@RequestHeader(TOKEN) String token){
        return Result.ok(LOGOUT_SUCCESS);
    }



    @ApiOperation(value = "搜索栏查询")
    @GetMapping("/list")
    public Result<PageVO> getUserList(@RequestParam(value = "pageSize") Integer pageSize,
                                      @RequestParam(value = "currentPage") Integer currentPage,
                                      @RequestParam(value = "username", required = false) String username,
                                      @RequestParam(value = "tel", required = false) String tel,
                                      @RequestParam(value = "mail", required = false) String mail,
                                      @RequestParam(value = "roleName", required = false) String roleName){
        PageVO data = userService.getUserList(pageSize, currentPage, username, tel, mail, roleName);
        return Result.ok(data);
    }


    @ApiOperation(value = "新增用户")
    @PostMapping
    @ParameterValidation()        // 使用AOP判断用户名、密码、邮箱、手机号码格式是否正确（参数校验）
    public Result<?> addUser(@RequestBody UserDTO userDTO){
        String message = userService.addUser(userDTO);
        return Result.ok(message);
    }


    @ApiOperation(value = "通过id得到用户信息")
    @GetMapping("/{id}")
    public Result<?> getUserById(@PathVariable Integer id){
        UserDTO userDTO = userService.getUserById(id);
        return Result.ok(userDTO);
    }



    @ApiOperation(value = "编辑用户")
    @PutMapping
    @ParameterValidation(format = {USERNAMEREGEX, EMAILREGEX, TELREGEX})
    public Result<?> updateUser(@RequestBody UserDTO userDTO){
        userService.updateUser(userDTO);
        return Result.ok(UPDATE_USER_SUCCESS);
    }


    @ApiOperation(value = "删除用户")
    @DeleteMapping("/{id}")
    public Result<?> deleteUserIById(@PathVariable("id") Integer id){
        userService.deleteUserById(id);
        return Result.ok(DELETE_USER_SUCCESS);
    }


    @ApiOperation(value = "通过用户名查询用户信息")
    @GetMapping("/personalInfo")
    public Result<?> getUserInfoByName(@RequestParam String name, @RequestParam boolean flag){
        UserDTO userDTO = userService.getUserInfoByName(name, flag);
        return Result.ok(userDTO);
    }


    @ApiOperation(value = "根据用户名修改密码")
    @PutMapping("/password")
    public Result<?> updatePassword( @RequestParam String name, @RequestBody PasswordChangeDTO request){
        User user = userMapper.getUserByName(name);
        String message = userService.updatePassword(user, request);
        return Result.ok(message);
    }


    @ApiOperation(value = "修改头像")
    @PutMapping("/avatar")
    public Result<?> updateAvatar(@RequestParam(value = "name") String name, @RequestParam(value = "imageUrl") String imageUrl){
        userService.updateAvatar(name, imageUrl);
        return Result.ok(UPLOAD_SUCCESS);
    }

    @ApiOperation(value = "根据用户名用户身份验证")
    @PostMapping("/authen")
    public Result<?> haveAuthenticated(@RequestBody AuthenDTO authenDTO, @RequestParam String name){
        exceptionUtils.exceptionDeal(StrUtil.hasBlank(authenDTO.getPassword()), PASSWORD_IS_NULL);
        return userService.haveAuthenticated(authenDTO, name);
    }



}
