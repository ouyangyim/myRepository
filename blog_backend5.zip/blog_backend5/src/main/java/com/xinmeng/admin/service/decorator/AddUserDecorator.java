package com.xinmeng.admin.service.decorator;

import cn.hutool.core.util.ObjUtil;
import com.xinmeng.admin.dto.UserDTO;
import org.springframework.stereotype.Component;


/**
 *  新增用户装饰类
 */
@Component
public class AddUserDecorator extends AddUserComponent{

    private AddUserComponent component;

    public void addUserDecorator(AddUserComponent component){
        this.component = component;
    }


    /**
     *  重写要装饰的方法
     */
    @Override
    public String addUser(UserDTO userDTO) {
        if(!ObjUtil.isNull(component)){
            return component.addUser(userDTO);
        }
        return null;
    }



}
