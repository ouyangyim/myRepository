package com.xinmeng.admin.mapper;

import com.xinmeng.entity.User;
import com.xinmeng.entity.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Repository
public interface UserRoleMapper extends BaseMapper<UserRole> {

    List<Integer> getRoleIdListByUserId(Integer id);

    List<User> getUserListByRoleId(Integer roleId);

}
