package com.xinmeng.admin.mapper;

import com.xinmeng.entity.ArticleTag;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xinmeng.entity.Tag;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Repository
public interface ArticleTagMapper extends BaseMapper<ArticleTag> {

    List<Integer> getTagIdListByArticleId(Integer id);

    List<Tag> getTagListByArticleId(Integer id);
}
