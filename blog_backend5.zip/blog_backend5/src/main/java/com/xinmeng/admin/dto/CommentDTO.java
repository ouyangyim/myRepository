package com.xinmeng.admin.dto;

import com.xinmeng.entity.Article;
import com.xinmeng.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentDTO {

    private Integer id;

    /**
     * 评论人
     */
    private User user;

    /**
     * 评论文章
     */
    private Article article;

    /**
     * 评论内容
     */
    private String content;


    /**
     * 评论状态 已审核1 待审核0
     */
    private Integer status;

    /**
     * 评论时间
     */
    private String commentTime;

}
