package com.xinmeng.admin.service;

import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.admin.vo.UserVO;
import com.xinmeng.dto.AuthenDTO;
import com.xinmeng.dto.InfoByTokenDTO;
import com.xinmeng.dto.TokenDTO;
import com.xinmeng.vo.PageVO;
import com.xinmeng.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.vo.Result;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
public interface IUserService extends IService<User> {

    TokenDTO login(UserDTO user);

    InfoByTokenDTO getUserInfo(String token);


    PageVO<UserVO> getUserList(Integer pageSize, Integer currentPage, String username, String tel, String mail, String roleName);

    String addUser(UserDTO userDTO);

    void updateUser(UserDTO userDTO);

    UserDTO getUserById(Integer id);

    void deleteUserById(Integer id);

    UserDTO getUserInfoByName(String name, boolean flag);

    String updatePassword(User user, PasswordChangeDTO request);

    void updateAvatar(String name, String imageUrl);

    Result<?> haveAuthenticated(AuthenDTO authenDTO, String name);
}
