package com.xinmeng.admin.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xinmeng.admin.dto.RoleDTO;
import com.xinmeng.admin.mapper.RoleMenuMapper;
import com.xinmeng.admin.vo.RoleVO;
import com.xinmeng.entity.Role;
import com.xinmeng.admin.mapper.RoleMapper;
import com.xinmeng.admin.service.IRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.entity.RoleMenu;
import com.xinmeng.templateMethod.PageConcrete.PageRoleConcrete;
import com.xinmeng.util.BeanCopyUtils;
import com.xinmeng.vo.PageVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.util.*;


/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Service
@Import(PageRoleConcrete.class)
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements IRoleService {

    @Resource
    private RoleMenuMapper roleMenuMapper;

    @Autowired
    private PageRoleConcrete rolePage;

    /**
     * 分页条件查询  （模板方法模式）
     * @param pageSize
     * @param currentPage
     * @param roleName
     * @param roleDesc
     * @return
     */
    @Override
    public PageVO<RoleVO> getRoleList(Integer pageSize, Integer currentPage, String roleName, String roleDesc) {

        return rolePage.pageTemplate(pageSize, currentPage, roleName, roleDesc);

    }


    /**
     * 新增角色
     * @param roleDTO
     */
    @Override
    @Transactional
    public void addRole(RoleDTO roleDTO) {
        // 创建日期
        roleDTO.setCreateTime(DateUtil.now());
        // 添加到角色表中
        Role role = Convert.convert(Role.class, roleDTO);
        this.baseMapper.insert(role);
        // 添加到角色菜单关联表中
        if(roleDTO.getMenuIdList() != null){
            for (Integer menuId : roleDTO.getMenuIdList()) {
                roleMenuMapper.insert(new RoleMenu(null, role.getId() , menuId));
            }
        }
    }


    /**
     *  根据id获得角色信息  // 得到要修改的该列用户 的信息
     * @param id
     * @return
     */
    @Override
    public RoleDTO getRoleById(Integer id) {
        // 查询role表，得到 基本信息
        Role role = this.baseMapper.selectById(id);
        RoleDTO roleDTO = Convert.convert(RoleDTO.class, role);
        // 查询role_menu表，得到 该角色对应的 菜单id集合(菜单应该是叶子节点)
        List<Integer> menuIdList = roleMenuMapper.getMenuIdListByRoleId(id);
        // 设置 角色对象 对应的菜单id集合
        roleDTO.setMenuIdList(menuIdList);
        return roleDTO;
    }


    /**
     * 编辑角色信息
     * @param roleDTO
     */
    @Override
    @Transactional   // 同时处理两张表，事务处理
    public void updateRole(RoleDTO roleDTO) {
        // 最近修改日期
        roleDTO.setUpdateTime(DateUtil.now());
        Role role = Convert.convert(Role.class, roleDTO);
        // 修改 角色表信息
        this.baseMapper.updateById(role);
        // 修改 角色菜单关联表信息
        // 删除原有的信息
        LambdaQueryWrapper<RoleMenu> lqw = new LambdaQueryWrapper<>();
        lqw.eq(RoleMenu::getRoleId, roleDTO.getId());
        roleMenuMapper.delete(lqw);
        // 新增 新的信息
        if(roleDTO.getMenuIdList() != null){
            for (Integer menuId : roleDTO.getMenuIdList()) {
                roleMenuMapper.insert(new RoleMenu(null, role.getId() , menuId));
            }
        }
    }

    /**
     * 删除角色
     * @param id
     */
    @Override
    @Transactional
    public void deleteRoleById(Integer id) {
        // 根据id删除 角色表信息
        this.baseMapper.deleteById(id);
        // 删除 角色菜单关联表信息
        LambdaQueryWrapper<RoleMenu> lqw = new LambdaQueryWrapper<>();
        lqw.eq(RoleMenu::getRoleId, id);
        roleMenuMapper.delete(lqw);
    }


    /**
     * 根据用户id得到角色名
     * @param id
     * @return
     */
    @Override
    public List<String> getRoleNameByUserId(Integer id) {
        List<String> roleNameList = this.baseMapper.getRoleNameByUserId(id);
        return roleNameList;
    }
}
