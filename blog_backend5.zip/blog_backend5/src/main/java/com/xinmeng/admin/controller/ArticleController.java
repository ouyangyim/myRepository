package com.xinmeng.admin.controller;

import com.xinmeng.admin.dto.ArticleDTO;
import com.xinmeng.admin.service.IArticleService;
import com.xinmeng.admin.vo.ArticleVO;
import com.xinmeng.entity.Article;
import com.xinmeng.vo.PageVO;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

import static com.xinmeng.constant.ArticleConstant.*;
import static com.xinmeng.constant.ResultConstant.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Api(tags = "博客文章管理接口")
@RestController
@RequestMapping("/article")
public class ArticleController {

    @Autowired
    private IArticleService articleService;

    @ApiOperation(value = "搜索栏查询")
    @GetMapping("/list")
    public Result<PageVO<ArticleVO>> getArticleList(@RequestParam(value = "pageSize") Integer pageSize,
                                                    @RequestParam(value = "currentPage") Integer currentPage,
                                                    @RequestParam(value = "articleName", required = false) String articleName,
                                                    @RequestParam(value = "author", required = false) String author,
                                                    @RequestParam(value = "tagName", required = false) String tagName,
                                                    @RequestParam(value = "categoryName", required = false) String categoryName){
        PageVO<ArticleVO> data = articleService.getArticleList(pageSize, currentPage, articleName, author, tagName, categoryName);
        return Result.ok(data);
    }


    @ApiOperation(value = "通过id得到文章信息")
    @GetMapping("/{id}")
    public Result<?> getArticleById(@PathVariable Integer id){
        ArticleDTO articleDTO = articleService.getArticleById(id);
        return Result.ok(articleDTO);
    }


    @ApiOperation(value = "编辑文章")
    @PutMapping
    public Result<?> updateArticle(@RequestBody ArticleDTO articleDTO){
        articleService.updateArticle(articleDTO);
        return Result.ok(UPDATE_ARTICLE_SUCCESS);
    }

    @ApiOperation(value = "删除文章")
    @DeleteMapping("/{id}")
    public Result<?> deleteArticleById(@PathVariable("id") Integer id){
        articleService.deleteArticleById(id);
        return Result.ok(DELETE_ARTICLE_SUCCESS);
    }

    @ApiOperation(value = "查询文章总量")
    @GetMapping("/count")
    public Result<?> getArticleCount(){
        List<Article> articleList = articleService.list();
        Integer data = articleList.size();
        return Result.ok(data);
    }


    @ApiOperation(value = "查询最新文章")
    @GetMapping("/latestArticle")
    public Result<?> getLatestArticle(){
        List<ArticleVO> articleVOList = articleService.getLatestArticle();
        return Result.ok(articleVOList);
    }

    @ApiOperation(value = "新增文章")
    @PostMapping("/add")
    public Result<?> addArticle(@RequestBody ArticleDTO articleDTO){
        try {
            articleService.addArticle(articleDTO);
            return Result.ok(ADD_ARTICLE_SUCCESS);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return Result.fail();
        }
    }




}
