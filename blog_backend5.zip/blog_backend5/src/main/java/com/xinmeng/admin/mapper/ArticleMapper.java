package com.xinmeng.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xinmeng.entity.Article;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Repository
public interface ArticleMapper extends BaseMapper<Article> {

    Article selectByName(String articleName);

    List<Integer> getAllId();
}
