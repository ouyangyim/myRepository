package com.xinmeng.admin.service.decorator;

import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.ResultConstant.UPDATE_PASSWORD_SUCCESS;

/**
 *  修改密码
 */
//@Component
public class UpdatePasswordComponent {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserMapper userMapper;

    public String updatePassword(User user, PasswordChangeDTO request) {
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userMapper.updateById(user);
        return UPDATE_PASSWORD_SUCCESS;
    }

}
