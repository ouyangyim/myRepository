package com.xinmeng.admin.vo;

import lombok.Data;
import lombok.Getter;

@Data
public class CommentVO {

    private Integer id;

    /**
     * 评论人
     */
    private UserVO user;

    /**
     * 评论文章
     */
    private ArticleVO article;

    /**
     * 评论内容
     */
    private String content;


    /**
     * 评论状态 已审核1 待审核0
     */
    private Integer status;

    /**
     * 评论时间
     */
    private String commentTime;

}
