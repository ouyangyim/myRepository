package com.xinmeng.admin.service.decorator.AddUserConcreteDecorator;

import cn.hutool.core.util.StrUtil;
import com.xinmeng.admin.service.decorator.AddUserComponent;
import com.xinmeng.admin.service.decorator.AddUserDecorator;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.ResultConstant.MAIL_EXIT;
import static com.xinmeng.constant.ResultConstant.TEL_EXIT;

/**
 *  新增用户 具体装饰类 (判断 手机号码或邮箱是否被注册)
 */
@Component
public class JudgeUserEmailOrTelIfRegisteredConcreteDecorator extends AddUserDecorator {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Override
    public void addUserDecorator(AddUserComponent component) {
        super.addUserDecorator(component);
    }


    @Override
    public String addUser(UserDTO userDTO) {
        String mail = userDTO.getMail();
        String tel = userDTO.getTel();
        if(!StrUtil.hasBlank(mail)){
            User user = userMapper.checkUserByEmail(mail);
            exceptionUtils.exceptionDeal(user!=null, ResultEnum.MAIL_EXIT);
        }
        if(!StrUtil.hasBlank(tel)){
            User user = userMapper.checkUserByTel(tel);
            exceptionUtils.exceptionDeal(user!=null, ResultEnum.TEL_EXIT);
        }
        return super.addUser(userDTO);
    }

}
