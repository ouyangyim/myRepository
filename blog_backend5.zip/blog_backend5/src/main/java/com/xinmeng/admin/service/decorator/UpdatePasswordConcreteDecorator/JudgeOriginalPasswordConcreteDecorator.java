package com.xinmeng.admin.service.decorator.UpdatePasswordConcreteDecorator;

import com.xinmeng.admin.service.decorator.UpdatePasswordComponent;
import com.xinmeng.admin.service.decorator.UpdatePasswordDecorator;
import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.ResultConstant.CURRENT_PASSWORD_ERROR;

/**
 *  具体装饰类 (判断原密码是否正确)
 */
//@Component
public class JudgeOriginalPasswordConcreteDecorator extends UpdatePasswordDecorator {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void updatePasswordDecorator(UpdatePasswordComponent component) {
        super.updatePasswordDecorator(component);
    }

    @Override
    public String updatePassword(User user, PasswordChangeDTO request) {
        if(passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            return super.updatePassword(user, request);
        }
        // 原密码不正确
        return CURRENT_PASSWORD_ERROR;
    }

}
