package com.xinmeng.admin.service;

import com.xinmeng.entity.UserRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
public interface IUserRoleService extends IService<UserRole> {

}
