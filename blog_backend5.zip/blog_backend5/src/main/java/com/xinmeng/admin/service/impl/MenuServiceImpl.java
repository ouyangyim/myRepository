package com.xinmeng.admin.service.impl;

import cn.hutool.core.lang.tree.Tree;
import cn.hutool.core.lang.tree.TreeNodeConfig;
import cn.hutool.core.lang.tree.TreeUtil;
import com.xinmeng.admin.dto.MenuDTO;
import com.xinmeng.entity.Menu;
import com.xinmeng.admin.mapper.MenuMapper;
import com.xinmeng.admin.service.IMenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.util.BeanCopyUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Service
@Slf4j
public class MenuServiceImpl extends ServiceImpl<MenuMapper, Menu> implements IMenuService {


    /**
     * 形成树结构
     * @param menuList
     * @return
     */
    public List<MenuDTO> getTree(List<Menu> menuList) {
        // 自定义配置树形结构类字段名
        TreeNodeConfig treeNodeConfig = new TreeNodeConfig();
        treeNodeConfig.setNameKey("menuName");
        // 转换器
        List<Tree<String>> treeNodes = TreeUtil.build(menuList, "0", treeNodeConfig,
                (menu, tree) -> {
                    tree.setId(menu.getId().toString());
                    tree.setParentId(menu.getParentId().toString());
                    tree.setName(menu.getMenuName());
                    // 扩展属性
                    tree.putExtra("path", menu.getPath());
                    tree.putExtra("component", menu.getComponent());
                    tree.putExtra("redirect", menu.getRedirect());
                    tree.putExtra("title", menu.getTitle());
                    tree.putExtra("icon", menu.getIcon());
                    tree.putExtra("isLeaf", menu.getIsLeaf());
                });
        List<MenuDTO> menuDTOList = BeanCopyUtils.copyList(treeNodes, MenuDTO.class);
        return menuDTOList;
    }

    @Override
    public List<MenuDTO> getAllMenu() {
        // 查询所有的菜单
        List<Menu> menuList = this.list();
        return getTree(menuList);
    }

    @Override
    public List<MenuDTO> getMenuListByUserId(Integer userId) {
        // 根据userId查询菜单
        List<Menu> menuList = this.baseMapper.getMenuListByUserId(userId);
        return getTree(menuList);
    }


}