package com.xinmeng.admin.service.impl;

import com.xinmeng.admin.dto.CommentDTO;
import com.xinmeng.entity.Comment;
import com.xinmeng.admin.mapper.CommentMapper;
import com.xinmeng.admin.service.ICommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.templateMethod.PageConcrete.PageCommentConcrete;
import com.xinmeng.vo.PageVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.xinmeng.constant.CommentConstant.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-09
 */
@Service
@Import(PageCommentConcrete.class)
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements ICommentService {

    @Autowired
    private PageCommentConcrete pageCommentConcrete;


    /**
     * 分页查询  （模板方法模式）
     * @param pageSize
     * @param currentPage
     * @param articleName
     * @param status
     * @return
     */
    @Override
    public PageVO<CommentDTO> getCommentList(Integer pageSize, Integer currentPage, String articleName, String status) {

        return pageCommentConcrete.pageTemplate(pageSize, currentPage, articleName, status);

    }


    /**
     * 删除评论
     * @param id
     */
    @Override
    public void deleteCommentById(Integer id) {
        this.baseMapper.deleteById(id);
    }


    /**
     * 审核单个评论
     * @param id
     */
    @Override
    public void checkOneComment(Integer id) {
        Comment comment = this.baseMapper.selectById(id);
        comment.setStatus(APPROVED);
        this.baseMapper.updateById(comment);
    }


    /**
     * 一键审核
     */
    @Override
    public void checkAllComment() {
        List<Comment> commentList = this.list();
        for (Comment comment : commentList) {
            comment.setStatus(APPROVED);
            this.baseMapper.updateById(comment);
        }
    }

}
