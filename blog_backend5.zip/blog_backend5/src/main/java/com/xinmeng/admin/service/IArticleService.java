package com.xinmeng.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.admin.dto.ArticleDTO;
import com.xinmeng.admin.vo.ArticleVO;
import com.xinmeng.entity.Article;
import com.xinmeng.vo.PageVO;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
public interface IArticleService extends IService<Article> {

    PageVO<ArticleVO> getArticleList(Integer pageSize, Integer currentPage, String articleName, String author, String tagName, String categoryName);


    ArticleDTO getArticleById(Integer id);

    void updateArticle(ArticleDTO articleDTO);

    void deleteArticleById(Integer id);

    List<ArticleVO> getLatestArticle();

    void addArticle(ArticleDTO articleDTO) throws FileNotFoundException;
}
