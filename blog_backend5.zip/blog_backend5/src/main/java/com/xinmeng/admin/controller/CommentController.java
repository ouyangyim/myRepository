package com.xinmeng.admin.controller;

import com.xinmeng.admin.dto.CommentDTO;
import com.xinmeng.admin.service.ICommentService;
import com.xinmeng.entity.Comment;
import com.xinmeng.entity.Tag;
import com.xinmeng.vo.PageVO;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static com.xinmeng.constant.CommentConstant.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-09
 */
@Api(tags = "评论管理接口")
@RestController
@RequestMapping("/comment")
public class CommentController {

    @Autowired
    ICommentService commentService;

    @ApiOperation(value = "搜索栏查询")
    @GetMapping("/list")
    public Result<PageVO<CommentDTO>> getCommentList(@RequestParam(value = "pageSize") Integer pageSize,
                                                   @RequestParam(value = "currentPage") Integer currentPage,
                                                   @RequestParam(value = "articleName", required = false) String articleName,
                                                   @RequestParam(value = "status", required = false) String status){
        PageVO<CommentDTO> data = commentService.getCommentList(pageSize, currentPage, articleName, status);
        return Result.ok(data);
    }

    @ApiOperation(value = "删除评论")
    @DeleteMapping("/{id}")
    public Result<?> deleteCommentIById(@PathVariable("id") Integer id){
        commentService.deleteCommentById(id);
        return Result.ok(DELETE_COMMENT_SUCCESS);
    }


    @ApiOperation(value = "审核单个评论")
    @PutMapping("/{id}")
    public Result<?> checkOneComment(@PathVariable("id") Integer id){
        commentService.checkOneComment(id);
        return Result.ok(REVIEW_COMMENT_SUCCESS);
    }

    @ApiOperation(value = "一键审核")
    @PutMapping
    public Result<?> checkAllComment(){
        commentService.checkAllComment();
        return Result.ok(REVIEW_COMMENT_SUCCESS);
    }

    @ApiOperation(value = "查询评论总量")
    @GetMapping("/count")
    public Result<?> getCommentCount(){
        List<Comment> commentList = commentService.list();
        Integer data = commentList.size();
        return Result.ok(data);
    }

}
