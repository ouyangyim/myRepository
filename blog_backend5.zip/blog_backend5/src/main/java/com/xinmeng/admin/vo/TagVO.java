package com.xinmeng.admin.vo;

import com.xinmeng.entity.Article;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TagVO {

    private Integer id;

    /**
     * 标签名
     */
    private String tagName;


    /**
     * 标签对应的文章集合
     */
    private List<Article> articleList;


}
