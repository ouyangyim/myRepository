package com.xinmeng.admin.mapper;

import com.xinmeng.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Primary
@Repository
public interface UserMapper extends BaseMapper<User> {

    List<String> getRoleNameByUserId(Integer userId);

    User getById(Integer userId);

    User getUserByName(String name);

    User checkUserByEmail(String account);

    User checkUserByTel(String account);

    User getUserById(Integer userId);

    List<User> selectByIpAddress(String ipAddress);

}
