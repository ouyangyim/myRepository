package com.xinmeng.admin.service.decorator.UpdatePasswordConcreteDecorator;

import com.xinmeng.admin.service.decorator.UpdatePasswordComponent;
import com.xinmeng.admin.service.decorator.UpdatePasswordDecorator;
import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.entity.User;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.ResultConstant.DIFFERENT_PASSWORD_ERROR;

/**
 *  具体装饰类 (判断两次密码输入是否一致)
 */
//@Component
public class JudgeIfSamePasswordConcreteDecorator1 extends UpdatePasswordDecorator {

    @Override
    public void updatePasswordDecorator(UpdatePasswordComponent component) {
        super.updatePasswordDecorator(component);
    }

    @Override
    public String updatePassword(User user, PasswordChangeDTO request) {
        if (request.getNewPassword().equals(request.getConfirmPassword())){
            return super.updatePassword(user, request);
        }else{
            // 两次密码不同
            return DIFFERENT_PASSWORD_ERROR;
        }
    }

}
