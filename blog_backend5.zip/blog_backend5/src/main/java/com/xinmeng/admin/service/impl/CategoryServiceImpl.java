package com.xinmeng.admin.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xinmeng.admin.dto.CategoryDTO;
import com.xinmeng.admin.mapper.ArticleCategoryMapper;
import com.xinmeng.admin.vo.CategoryVO;
import com.xinmeng.entity.ArticleCategory;
import com.xinmeng.entity.Category;
import com.xinmeng.admin.mapper.CategoryMapper;
import com.xinmeng.admin.service.ICategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Service
public class CategoryServiceImpl extends ServiceImpl<CategoryMapper, Category> implements ICategoryService {

    @Resource
    private ArticleCategoryMapper articleCategoryMapper;

    /**
     * 根据 文章id 查询 分类id
     * @param id
     * @return
     */
    @Override
    public String getCategoryNameByArticleId(Integer id) {
        String categoryName = this.baseMapper.getCategoryNameByArticleId(id);
        return categoryName;
    }


    /**
     * 新增分类
     * @param category
     */
    @Override
    public void addCategory(Category category) {
        // 创建日期
        category.setCreateTime(DateUtil.now());
        // 添加到用户表中
        this.baseMapper.insert(category);
    }


    /**
     * 删除分类
     * @param id
     */
    @Override
    @Transactional
    public void deleteCategoryById(Integer id) {
        // 根据id删除 用户表信息
        this.baseMapper.deleteById(id);
        // 删除文章分类表信息
        LambdaQueryWrapper<ArticleCategory> lqw = new LambdaQueryWrapper<>();
        lqw.eq(ArticleCategory::getCategoryId, id);
        articleCategoryMapper.delete(lqw);
    }


    /**
     * 查询所有分类（包括分类对应的文章集合）
     * @return
     */
    @Override
    public List<CategoryVO> getAllCategoryList() {
        List<Category> categoryList = this.list();
        List<CategoryDTO> categoryDTOList = BeanCopyUtils.copyList(categoryList, CategoryDTO.class);
        for (CategoryDTO categoryDTO : categoryDTOList) {
            categoryDTO.setArticleList(this.baseMapper.getArticleListByCategoryId(categoryDTO.getId()));
        }
        List<CategoryVO> categoryVOList = BeanCopyUtils.copyList(categoryDTOList, CategoryVO.class);
        return categoryVOList;
    }


}
