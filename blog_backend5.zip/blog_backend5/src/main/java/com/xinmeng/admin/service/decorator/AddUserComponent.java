package com.xinmeng.admin.service.decorator;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.admin.mapper.UserRoleMapper;
import com.xinmeng.constant.UserInfoConstant;
import com.xinmeng.entity.User;
import com.xinmeng.entity.UserRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import java.util.List;
import static com.xinmeng.constant.ResultConstant.ADD_USER_SUCCESS;
import static com.xinmeng.constant.UserInfoConstant.INIT_AVATAR;


/**
 *  新增用户
 */
@Component
public class AddUserComponent {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private UserRoleMapper userRoleMapper;


    public String addUser(UserDTO userDTO){
        User user = Convert.convert(User.class, userDTO);
        // 编辑其他信息(除了前端传来信息之外的其他信息)
        // 加密密码
        if (!StrUtil.hasBlank(userDTO.getPassword())){
            user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        }
        user.setAvatar(INIT_AVATAR);   // 初始头像
        user.setDescription(UserInfoConstant.USER);  // 用户描述 游客还是用户
        // 创建日期
        user.setCreateTime(DateUtil.now());
        // 添加到用户表中
        userMapper.insert(user);
        // 添加到 用户角色表中
        List<Integer> roleIdList = userDTO.getRoleIdList();
        for (Integer roleId : roleIdList) {
            userRoleMapper.insert(new UserRole(null, user.getId(), roleId));
        }
        return ADD_USER_SUCCESS;
    }


}
