package com.xinmeng.admin.controller;

import com.xinmeng.admin.service.BlogWebInfoService;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "博客网站信息接口")
@RestController
@RequestMapping("/blog")
public class BlogWebInfoController {


    @Autowired
    private BlogWebInfoService blogWebInfoService;


    @ApiOperation("查询博客访问量")
    @GetMapping("/count")
    public Result<?> getBlogCount(){
        Integer count = blogWebInfoService.getBlogCount();
        return Result.ok(count);
    }

}
