package com.xinmeng.admin.mapper;

import com.xinmeng.entity.Comment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-09
 */
@Repository
public interface CommentMapper extends BaseMapper<Comment> {


    double getCount(Integer articleId);
}
