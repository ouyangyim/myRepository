package com.xinmeng.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;



@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleDTO {

    /**
     * id
     */
    private Integer id;
    /**
     * 角色名
     */
    private String roleName;
    /**
     * 角色描述
     */
    private String roleDesc;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 修改时间
     */
    private String updateTime;
    /**
     * 角色状态 禁用1 不禁用0
     */
    private Integer status;


    /**
     * 角色 对应 菜单 的id 集合
     */
    private List<Integer> MenuIdList;

}
