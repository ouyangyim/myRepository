package com.xinmeng.admin.controller;

import com.xinmeng.admin.dto.MessageDTO;
import com.xinmeng.admin.service.ICommentService;
import com.xinmeng.admin.service.IMessageService;
import com.xinmeng.entity.Message;
import com.xinmeng.vo.PageVO;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static com.xinmeng.constant.ResultConstant.DELETE_MESSAGE_SUCCESS;


/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-09
 */
@Api(tags = "留言管理接口")
@RestController
@RequestMapping("/message")
public class MessageController {

    @Autowired
    IMessageService messageService;

    @ApiOperation(value = "搜索栏查询")
    @GetMapping("/list")
    public Result<PageVO<MessageDTO>> getMessageList(@RequestParam(value = "pageSize") Integer pageSize,
                                                      @RequestParam(value = "currentPage") Integer currentPage,
                                                      @RequestParam(value = "username", required = false) String username,
                                                      @RequestParam(value = "content", required = false) String content){
        PageVO<MessageDTO> data = messageService.getMessageList(pageSize, currentPage, username, content);
        return Result.ok(data);
    }


    @ApiOperation(value = "删除留言")
    @DeleteMapping("/{id}")
    public Result<?> deleteMessageIById(@PathVariable("id") Integer id){
        messageService.deleteMessageById(id);
        return Result.ok(DELETE_MESSAGE_SUCCESS);
    }


    @ApiOperation(value = "查询留言总量")
    @GetMapping("/count")
    public Result<?> getMessageCount(){
        List<Message> messageList = messageService.list();
        Integer data = messageList.size();
        return Result.ok(data);
    }

}
