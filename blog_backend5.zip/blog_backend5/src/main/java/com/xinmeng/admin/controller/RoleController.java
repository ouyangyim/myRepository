package com.xinmeng.admin.controller;

import com.xinmeng.admin.dto.RoleDTO;
import com.xinmeng.admin.service.IRoleService;
import com.xinmeng.admin.vo.RoleVO;
import com.xinmeng.entity.Role;
import com.xinmeng.vo.PageVO;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static com.xinmeng.constant.ResultConstant.*;


/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@Api(tags = "角色管理接口")
@RestController
@RequestMapping("/role")
public class RoleController {

    @Autowired
    private IRoleService roleService;


    @ApiOperation(value = "搜索栏查询")
    @GetMapping("/list")
    public Result<PageVO<RoleVO>> getUserList(@RequestParam(value = "pageSize") Integer pageSize,
                                              @RequestParam(value = "currentPage") Integer currentPage,
                                              @RequestParam(value = "roleName", required = false) String roleName,
                                              @RequestParam(value = "roleDesc", required = false) String roleDesc){
        PageVO<RoleVO> data = roleService.getRoleList(pageSize, currentPage, roleName, roleDesc);
        return Result.ok(data);
    }


    @ApiOperation(value = "新增角色")
    @PostMapping
    public Result<?> addRole(@RequestBody RoleDTO roleDTO){
        roleService.addRole(roleDTO);
        return Result.ok(ADD_ROLE_SUCCESS);
    }


    @ApiOperation(value = "通过id得到角色信息")
    @GetMapping("/{id}")
    public Result<?> getRoleById(@PathVariable Integer id){
        RoleDTO roleDTO = roleService.getRoleById(id);
        return Result.ok(roleDTO);
    }


    @ApiOperation(value = "编辑角色")
    @PutMapping
    public Result<?> updateRole(@RequestBody RoleDTO roleDTO){
        roleService.updateRole(roleDTO);
        return Result.ok(UPDATE_ROLE_SUCCESS);
    }


    @ApiOperation(value = "删除角色")
    @DeleteMapping("/{id}")
    public Result<?> deleteRoleById(@PathVariable("id") Integer id){
        roleService.deleteRoleById(id);
        return Result.ok(DELETE_ROLE_SUCCESS);
    }


    @ApiOperation(value = "查询所有角色")
    @GetMapping("/all")
    public Result<?> getAllRoleList(){
        List<Role> roleList = roleService.list();
        return Result.ok(roleList);
    }


}
