package com.xinmeng.admin.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-05
 */
@RestController
@RequestMapping("/userRole")
public class UserRoleController {

}
