package com.xinmeng.admin.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Controller
@RequestMapping("/admin/articleTag")
public class ArticleTagController {

}
