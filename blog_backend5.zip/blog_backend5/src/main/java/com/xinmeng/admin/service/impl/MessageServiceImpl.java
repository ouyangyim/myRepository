package com.xinmeng.admin.service.impl;

import com.xinmeng.admin.dto.MessageDTO;
import com.xinmeng.entity.Message;
import com.xinmeng.admin.mapper.MessageMapper;
import com.xinmeng.admin.service.IMessageService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.templateMethod.PageConcrete.PageMessageConcrete;
import com.xinmeng.vo.PageVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-09
 */
@Import(PageMessageConcrete.class)
@Service
public class MessageServiceImpl extends ServiceImpl<MessageMapper, Message> implements IMessageService {

    @Autowired
    private PageMessageConcrete pageMessageConcrete;

    /**
     * 分页查询  （模板方法模式）
     * @param pageSize
     * @param currentPage
     * @param username
     * @param content
     * @return
     */
    @Override
    public PageVO<MessageDTO> getMessageList(Integer pageSize, Integer currentPage, String username, String content) {

        return pageMessageConcrete.pageTemplate(pageSize, currentPage, username, content);

    }


    /**
     * 删除留言
     * @param id
     */
    @Override
    public void deleteMessageById(Integer id) {
        this.baseMapper.deleteById(id);
    }
}
