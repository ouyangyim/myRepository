package com.xinmeng.admin.service;

import com.xinmeng.admin.dto.CommentDTO;
import com.xinmeng.entity.Comment;
import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.vo.PageVO;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-09
 */
public interface ICommentService extends IService<Comment> {

    PageVO<CommentDTO> getCommentList(Integer pageSize, Integer currentPage, String articleName, String status);

    void deleteCommentById(Integer id);

    void checkOneComment(Integer id);

    void checkAllComment();
}
