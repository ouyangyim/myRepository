package com.xinmeng.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ResultEnum {

    /**
     * 操作成功
     */
    SUCCESS(20000, "success"),

    /**
     * 注册成功
     */
    REGISTER_SUCCESS(20001, "注册成功"),
    LOGIN_SUCCESS(20002, "登录成功"),


    /**
     * 操作失败
     */
    FAIL(50000, "fail"),

    LOGIN_FAILURE(50017, "登录失败"),

    EMAIL_FORMAT_ERROR(50018, "邮箱格式错误"),

    TEL_FORMAT_ERROR(50019, "手机号码格式错误"),

    ACCOUNT_FORMAT_ERROR(50021, "账号格式错误"),

    PASSWORD_IS_NULL(50022, "请输入密码"),

    COMMENT_AFTER_LOGIN(50023, "请先登录后评论"),

    MESSAGE_AFTER_LOGIN(50024, "请先登录后留言"),

    PLEASE_LOGIN(50030, "请先登录~~"),

    AUTHEN_FAILURE(50025, "密码错误,身份验证失败"),

    COMMENT_EXIST_SENSITIVE_WORD(50026, "您的评论存在敏感词汇, 请检查~"),

    MESSAGE_EXIST_SENSITIVE_WORD(50027, "您的留言存在敏感词汇, 请检查~"),

    SYSTEM_ERROR(50028, "系统异常~"),

    IMAGE_CODE_ERROR(50029, "图形验证码错误, 请检查~~"),

    USERNAME_FORMAT_ERROR(50020, "用户名格式错误"),

    FAIL_TYPE_ERROR(50001, "文件类型错误, 请上传png文件"),

    EMAIL_NOT_REGISTER(50002, "该邮箱未被注册"),

    Tel_NOT_REGISTER(50003, "该手机号未被注册"),

    PASSWORD_ERROR(50004, "密码错误"),

    FILE_CREATE_ERROR(50016, "文件创建失败"),

    ACCOUNT_NOT_REGISTER(50005, "该账户还未被注册"),

    DIFFERENT_PASSWORD_ERROR(50007, "两次密码不一致"),

    USER_IS_DISABLE(50008, "该用户已被禁用"),

    USERNAME_EXIST(50009, "该用户名已存在"),

    MAIL_EXIT(50010, "该邮箱已被注册"),

    TEL_EXIT(50011, "该手机号码已被注册"),

    CURRENT_PASSWORD_ERROR(50012, "原密码错误"),

    PASSWORD_FORMAT_ERROR(50013, "密码格式错误"),

    INVALID(50014, "jwt令牌无效，请重新登录"),

    ACCOUNT_EXIT(50016, "该账号已被注册"),

    VERIFICATION_CODE_ERROR(50015, "验证码错误"),

    SAME_PASSWORD(50006, "重置密码不能与新密码相同");



    /**
     * 状态码
     */
    private final Integer code;
    /**
     *  信息
     */
    private final String message;

}
