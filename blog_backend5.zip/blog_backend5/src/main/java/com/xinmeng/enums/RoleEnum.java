package com.xinmeng.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor
public enum RoleEnum {

    /**
     * 普通用户
     */
    USER(2,"user", "普通用户"),

    /**
     * 管理员
     */
    ADMIN(1,"admin", "管理员");


    /**
     * 角色id
     */
    private final Integer roleId;

    /**
     * 角色名
     */
    private final String roleName;

    /**
     *  角色描述
     */
    private final String roleDesc;


}

