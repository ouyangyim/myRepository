package com.xinmeng.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>
 *   博客文章类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-08
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Article implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 作者=
     */
    private String author;

    /**
     * 文章名=
     */
    private String articleName;

    /**
     * 文章缩略图=
     */
    private String thumbnail;

    /**
     * 浏览量
     */
    private Integer pageview;

    /**
     * 内容=
     */
    private String content;

    /**
     * 是否置顶 是1 否0=
     */
    private Integer isTop;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 修改时间
     */
    private String updateTime;

    /**
     * 文章状态=
     */
    private String status;

    /**
     * 逻辑删除 删除1 不删0
     */
    private Integer deleted;

    /**
     * 文章评分
     */
    private Double articleRate;


}
