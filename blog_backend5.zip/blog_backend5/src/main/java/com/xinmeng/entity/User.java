package com.xinmeng.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * (User)实体类
 *
 * @author makejava
 * @since 2023-08-05 16:23:14
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private String password;
    /**
     * 邮箱号
     */
    private String mail;
    /**
     * 电话号码
     */
    private String tel;
    /**
     * 头像
     */
    private String avatar;
    /**
     * 用户描述
     */
    private String description;
    /**
     * 用户是否登录 登录1 未登录0
     */
    private Integer isLogin;
    /**
     * 用户登录ip
     */
    private String userLoginIp;
    /**
     * ip来源
     */
    private String userIp;
    /**
     * 用户状态(是否禁用 禁用1 不禁用0)
     */
    private Integer status;
    /**
     * 账号创建时间
     */
    private String createTime;
    /**
     * 账号信息修改时间
     */
    private String updateTime;
    /**
     * 账户最近登录时间
     */
    private String loginTime;
    /**
     * 逻辑删除 删除1 不删除0
     */
    private Integer deleted;



}

