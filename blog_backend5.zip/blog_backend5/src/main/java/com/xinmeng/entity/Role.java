package com.xinmeng.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * (Role)实体类
 *
 * @author makejava
 * @since 2023-08-05 16:22:41
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Role  {
   
    /**
     * 角色主键id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 角色名
     */
    private String roleName;
    /**
     * 角色描述
     */
    private String roleDesc;
    /**
     * 创建时间
     */
    private String createTime;
    /**
     * 修改时间
     */
    private String updateTime;
    /**
     * 角色状态 禁用1 不禁用0
     */
    private Integer status;
    /**
     * 逻辑删除 删除1 不删除0
     */
    private Integer deleted;



}

