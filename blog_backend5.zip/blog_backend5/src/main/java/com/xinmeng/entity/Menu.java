package com.xinmeng.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * (Menu)实体类
 *
 * @author makejava
 * @since 2023-08-05 16:22:18
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Menu  {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;
    /**
     * 菜单名
     */
    private String menuName;
    /**
     * 路径
     */
    private String path;
    /**
     * 组件
     */
    private String component;
    /**
     * 重定向
     */
    private String redirect;
    /**
     * 展示的标题
     */
    private String title;
    /**
     * 菜单需要的字体图标
     */
    private String icon;
    /**
     * 父id
     */
    private Integer parentId;
    /**
     * 是否是叶子节点
     */
    private String isLeaf;
    /**
     * 是否隐藏, 隐藏1, 不隐藏0
     */
    private Integer hidden;
    /**
     * 逻辑删除 删除1 不删除0
     */
    private Integer deleted;

}

