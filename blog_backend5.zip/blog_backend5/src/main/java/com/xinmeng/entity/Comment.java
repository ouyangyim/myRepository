package com.xinmeng.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-09
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Comment implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 评论用户账号id
     */
    private Integer userId;

    /**
     * 评论内容
     */
    private String content;

    /**
     * 评论文章
     */
    private String articleName;

    /**
     * 评论状态 已审核1 待审核0
     */
    private Integer status;

    /**
     * 评论时间
     */
    private String commentTime;

    /**
     * 逻辑删除
     */
    private Integer deleted;

}
