package com.xinmeng.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-19
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Page implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 访问页面的url
     */
    private String pageUrl;

    /**
     * 访问页面的类型
     */
    private String pageType;

    /**
     * 浏览量
     */
    private Integer viewCount;


}
