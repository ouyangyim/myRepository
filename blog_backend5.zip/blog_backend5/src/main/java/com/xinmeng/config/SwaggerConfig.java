package com.xinmeng.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;

import java.util.Collections;
import java.util.List;

import static com.xinmeng.constant.CommonConstant.*;
import static com.xinmeng.constant.RegexConstant.*;
import static com.xinmeng.constant.JwtConstant.*;
import static com.xinmeng.constant.SwaggerConstant.*;

@Configuration
@EnableOpenApi
@EnableWebMvc
public class SwaggerConfig {


    @Bean
    public Docket api(){
        return new Docket(DocumentationType.OAS_30)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage(PACKAGENAME))
                .paths(PathSelectors.any())
                .build()
                .securitySchemes(Collections.singletonList(securityScheme()))
                .securityContexts(Collections.singletonList(securityContext()));
    }

    private ApiInfo apiInfo(){
        return new ApiInfoBuilder()
                .title(TITLE)
                .description(DESC)
                .version(VERSION)
                .contact(new Contact(PACKAGENAME, ADDRESS, EMAIL))
                .build();
    }



    private SecurityScheme securityScheme() {
        return new ApiKey(TOKEN, TOKEN, HEADER);
    }

    private SecurityContext securityContext() {
        return SecurityContext.builder()
                .securityReferences(defaultAuth())
                .forPaths(PathSelectors.regex(PATHREGEX))
                .build();
    }

    /**
     * 配置默认认证方式
     * @return
     */
    private List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope = new AuthorizationScope(AUTH_SCOPE, AUTH_CONTENT);
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        return Collections.singletonList(
                new SecurityReference(TOKEN, authorizationScopes));
    }


}
