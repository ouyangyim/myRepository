package com.xinmeng.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

/**
 * 解决跨域问题
 */
@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter(){
        // 添加CORS配置信息
        CorsConfiguration config = new CorsConfiguration();
        // 允许的域，即 要请求后端的前端服务器的域名
        config.addAllowedOrigin("http://localhost:5555");
        config.addAllowedOrigin("http://localhost:5656");
        // 是否发送cookie
        config.setAllowCredentials(true);
        // 允许请求的方式
        config.addAllowedMethod("*");
        // 允许的头信息
        config.addAllowedHeader("*");

        // 添加映射路径拦截请求
        UrlBasedCorsConfigurationSource urlBasedCorsConfigurationSource = new UrlBasedCorsConfigurationSource();
        urlBasedCorsConfigurationSource.registerCorsConfiguration("/**", config);

        // 返回CorsFilter
        return new CorsFilter(urlBasedCorsConfigurationSource);

    }

}
