package com.xinmeng.config;


import com.xinmeng.interceptor.CustomInterceptor;
import com.xinmeng.interceptor.JwtInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MyWebConfig implements WebMvcConfigurer {

    @Autowired
    private JwtInterceptor jwtInterceptor;

    @Autowired
    private CustomInterceptor customInterceptor;



    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        /**
         * 使用JWT拦截器
         */
        InterceptorRegistration registration = registry.addInterceptor(jwtInterceptor);
        registration.addPathPatterns("/**")
                .excludePathPatterns(
                        "/user/login",
                        "/user/info",
                        "/user/logout",
                        "/error",
                        "/swagger-ui/**",
                        "/swagger-resources/**",
                        "/v3/**",
                        "/api/**");

        /**
         * 页面访问拦截器
         */
        InterceptorRegistration registration1 = registry.addInterceptor(customInterceptor);
        registration1.addPathPatterns("/api/**"); // 拦截所有api开头的请求



    }

}
