package com.xinmeng.config;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.text.csv.CsvUtil;
import cn.hutool.core.text.csv.CsvWriter;
import cn.hutool.core.util.CharsetUtil;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.xinmeng.admin.mapper.*;
import com.xinmeng.blog.mapper.PageMapper;
import com.xinmeng.entity.*;
import com.xinmeng.util.PathUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.List;

@Slf4j
@Configuration
@EnableScheduling
public class SchedulerConfig {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ArticleMapper articleMapper;
    @Autowired
    private RoleMapper roleMapper;
    @Autowired
    private MessageMapper messageMapper;
    @Autowired
    private TagMapper tagMapper;
    @Autowired
    private ArticleCategoryMapper articleCategoryMapper;
    @Autowired
    private ArticleTagMapper articleTagMapper;
    @Autowired
    private CommentMapper commentMapper;
    @Autowired
    private CategoryMapper categoryMapper;
    @Autowired
    private RoleMenuMapper roleMenuMapper;
    @Autowired
    private UserRoleMapper userRoleMapper;
    @Autowired
    private PageMapper pageMapper;


    /**
     *  开启定时任务,每月1号将数据表进行备份
     */
    @Scheduled(cron = "0 0 0 1 * *")
    public void scheduledTask(){
        // 获取数据表
        List<User> userList = userMapper.selectList(null);
        List<Article> articleList = articleMapper.selectList(null);
        List<Role> roleList = roleMapper.selectList(null);
        List<Message> messageList = messageMapper.selectList(null);
        List<Tag> tagList = tagMapper.selectList(null);
        List<ArticleCategory> articleCategoryList = articleCategoryMapper.selectList(null);
        List<ArticleTag> articleTagList = articleTagMapper.selectList(null);
        List<Comment> commentList = commentMapper.selectList(null);
        List<Category> categoryList = categoryMapper.selectList(null);
        List<RoleMenu> roleMenuList = roleMenuMapper.selectList(null);
        List<UserRole> userRoleList = userRoleMapper.selectList(null);
        List<Page> pageList = this.pageMapper.selectList(null);
        // 创建CSV文件
        String fileName = "blogData.csv";
        String generateFilePath = PathUtils.generateFilePath(fileName);
        CsvWriter userWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\user\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter articleWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\article\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter roleWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\role\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter messageWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\message\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter tagWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\tag\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter articleCategoryWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\articleCategory\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter articleTagWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\articleTag\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter commentWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\comment\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter categoryWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\category\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter roleMenuWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\roleMenu\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter userRoleWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\userRole\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        CsvWriter pageWriter = CsvUtil.getWriter("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\data_log\\page\\"+generateFilePath, CharsetUtil.CHARSET_UTF_8);
        // 把数据写入文件
        userWriter.write(userList);
        articleWriter.write(articleList);
        roleWriter.write(roleList);
        messageWriter.write(messageList);
        tagWriter.write(tagList);
        articleCategoryWriter.write(articleCategoryList);
        articleTagWriter.write(articleTagList);
        commentWriter.write(commentList);
        categoryWriter.write(categoryList);
        roleMenuWriter.write(roleMenuList);
        userRoleWriter.write(userRoleList);
        pageWriter.write(pageList);
        log.info("定时任务执行时间" + DateUtil.now());
    }


}
