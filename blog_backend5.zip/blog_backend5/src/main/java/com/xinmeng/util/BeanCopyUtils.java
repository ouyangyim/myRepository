package com.xinmeng.util;

import cn.hutool.core.convert.Convert;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class BeanCopyUtils {



    /**
     * 拷贝List集合
     * @param source
     * @param target
     * @param <T>
     * @return
     */
    public static <S, T> List<T> copyList(List<S> source, Class<T> target){
        List<T> list = new ArrayList<>();
        if (source != null && source.size() > 0){
            for (S s : source) {
                list.add(Convert.convert(target, s));
            }
        }
        return list;
    }

}
