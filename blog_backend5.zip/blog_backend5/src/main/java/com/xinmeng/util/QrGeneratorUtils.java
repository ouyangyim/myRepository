package com.xinmeng.util;

import cn.hutool.core.io.FileUtil;
import cn.hutool.extra.qrcode.QrCodeUtil;
import cn.hutool.extra.qrcode.QrConfig;

/**
 *  二维码生成器
 */
public class QrGeneratorUtils {
//    public static void main(String[] args) {
//        QrCodeUtil.generate(
//                "http://39.107.158.44:5555/#/login",
//                QrConfig.create().setImg("https://personalblog-img-store.oss-cn-beijing.aliyuncs.com/2023/09/13/e0ec019a6b6e49dcac60136c5109a86e.png"),
//                FileUtil.file("D:\\Java_Project\\MyBlog_localhost\\myBlog_modify\\qr.png")
//        );
//    }
}
