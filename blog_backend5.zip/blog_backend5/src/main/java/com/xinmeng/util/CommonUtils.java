package com.xinmeng.util;

import cn.hutool.captcha.LineCaptcha;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.ReUtil;
import cn.hutool.dfa.WordTree;
import com.xinmeng.entity.User;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;

import static com.xinmeng.constant.ResultConstant.USER_IS_ABLE;
import static com.xinmeng.constant.ResultConstant.USER_IS_DISABLE;

@Component
public class CommonUtils {

    /**
     * 生成6位随机验证码
     * @return 验证码
     */
    public String getRandomCode() {
        StringBuilder str = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 6; i++) {
//            str.append(random.nextInt(10));
            str.append(RandomUtil.randomInt(0,10));
        }
        return str.toString();
    }



    /**
     * 得到缓存里的 邮箱验证码
     * @param email
     * @return
     */
    @Cacheable(value = "code", key = "#email")
    public String getCode(String email){
        return null;
    }


    /**
     * 得到缓存里的 短信验证码
     * @param tel
     * @return
     */
    @Cacheable(value = "code", key = "#tel")
    public String getTelCode(String tel){
        return null;
    }


    /**
     *  得到缓存里的图片二维码
     */
    @Cacheable(value = "lineCaptcha", key = "#ipAddress")
    public LineCaptcha getImgCode(String ipAddress){
        return null;
    }



    /**
     * 随机用户名
     */
    public String getRandomUsername(){
        StringBuilder str = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 9; i++) {
            str.append(random.nextInt(10));
        }
        String username = "用户-" + str;
        return username;
    }


    /**
     *  判断用户是否可用
     */
    public String checkUser(User user){
        return user.getStatus()==1 ? USER_IS_DISABLE : USER_IS_ABLE;
    }


    /**
     *  敏感词过滤
     * @param content
     * @return
     */
    public String sensitiveWordFilter(String content){
        WordTree tree = new WordTree();
        tree.addWord("垃圾");
        tree.addWord("傻子");
        List<String> matchAll = tree.matchAll(content, -1, true, true);
        for (String s : matchAll) {
            String re = "";
            for (int i = 0; i < s.length(); i++){
                re += "×";
            }
            content = ReUtil.replaceAll(content, s, re);
        }
        return content;
    }


    /**
     *  敏感词检查 --- 有敏感词返回true
     * @param content
     * @return
     */
    public boolean sensitiveWordCheck(String content){
        WordTree tree = new WordTree();
        tree.addWord("垃圾");
        tree.addWord("傻子");
        List<String> matchAll = tree.matchAll(content, -1, true, true);
        return matchAll.size()==0 ? false : true;
    }


}
