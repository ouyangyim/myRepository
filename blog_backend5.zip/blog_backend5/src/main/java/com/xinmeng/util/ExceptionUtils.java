package com.xinmeng.util;

import com.xinmeng.enums.ResultEnum;
import com.xinmeng.exception.MyException;
import org.springframework.stereotype.Component;

/**
 *  异常处理工具类
 */
@Component
public class ExceptionUtils {

    /**
     *  异常处理
     * @param flag
     * @param resultEnum
     */
    public void exceptionDeal(Boolean flag, ResultEnum resultEnum){
        if (flag){
            throw new MyException(resultEnum);
        }
    }

}
