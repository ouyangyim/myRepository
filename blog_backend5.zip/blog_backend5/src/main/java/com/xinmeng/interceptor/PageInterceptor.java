package com.xinmeng.interceptor;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PageInterceptor {

    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor(){
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();              // 拦截器链的容器
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));  // 向MP中添加一个内部拦截器
        return interceptor;
    }

}

// 分页拦截器是MP的一个拦截器组件，可以在执行SQL语句时对其进行拦截和修改，以实现分页功能; 会拦截所有执行的SQL语句