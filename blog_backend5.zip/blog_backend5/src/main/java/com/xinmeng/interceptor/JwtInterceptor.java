package com.xinmeng.interceptor;


import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson2.JSON;
import com.xinmeng.util.JwtUtils;
import com.xinmeng.vo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.xinmeng.enums.ResultEnum.INVALID;
import static com.xinmeng.constant.JwtConstant.*;


/**
 *  定义 JWT验证拦截器
 */
@Component
@Slf4j
public class JwtInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtUtils jwtUtils;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = request.getHeader(TOKEN);
        System.out.println(request.getRequestURI() + WAIT_FOR_VERIFICATION +token);
        if (!StrUtil.hasBlank(token)){
            try {
                jwtUtils.parseToken(token);
                log.debug(request.getRequestURI() + ALLOWPASS);
                return true;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        log.debug(request.getRequestURI() + STOPVIEW);
        response.setContentType(DATATYPE);
        response.getWriter().write(JSON.toJSONString(Result.fail(INVALID.getCode(),INVALID.getMessage())));
        return false;
    }


}
