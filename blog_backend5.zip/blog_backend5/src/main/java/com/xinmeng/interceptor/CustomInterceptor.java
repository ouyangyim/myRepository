package com.xinmeng.interceptor;

import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.URLUtil;
import com.xinmeng.admin.mapper.ArticleMapper;
import com.xinmeng.blog.mapper.PageMapper;
import com.xinmeng.entity.Article;
import com.xinmeng.entity.Page;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;


/**
 * 用户访问拦截器
 */
@Slf4j
@Component
public class CustomInterceptor implements HandlerInterceptor {


    @Autowired
    private ArticleMapper articleMapper;

    @Autowired
    private PageMapper pageMapper;



    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler){


        String ipAddress = request.getRemoteAddr();  // 得到ip地址
        log.info("访问用户的ip地址: " + ipAddress);

        // 创建用户 - 游客
//        List<User> userList = userMapper.selectByIpAddress(ipAddress);
//        if (userList.size() == 0){
//            // 创建 用户对象
//            User user = new User();
//            // 设置 用户身份
//            user.setDescription(VISITOR);
//           // 设置 用户随机用户名
//            user.setUsername(commonUtils.getRandomUsername());
//            userMapper.insert(user);
//       }


        // 获取请求的URL
        String url = request.getRequestURL().toString();
        // 获取请求的URL路径，这里不再包括http://localhost:80部分，可以避免更换端口号带来的耦合
        String urlPath = URLUtil.getPath(url);
        // 根据url查询page，查看该页面是否被访问过
        Page page = pageMapper.selectByUrl(url);
        String regex = "/api/article/(\\d+)$";
        if(ObjUtil.isNull(page) && urlPath.matches(regex)){
            // 页面还没访问过，创建页面对象
            page = new Page();
            page.setPageUrl(url);
            page.setViewCount(0);
            pageMapper.insert(page);
        }
        // 得到全部文章的id集合
        List<Integer> ids = articleMapper.getAllId();
        // 根据URL判断不同文章的访问
        for (Integer id : ids) {
            if(urlPath.equals("/api/article/" + id)){
                page.setPageType("文章");
                page.setViewCount(page.getViewCount()+1);
                pageMapper.updateById(page);   // 修改页面访问量
                // 修改文章的浏览量
                // 根据id得到 此时访问的文章对象
                Article article = articleMapper.selectById(id);
                article.setPageview(page.getViewCount());  // 此篇文章的浏览量就是这个页面的访问量
                articleMapper.updateById(article);
                break;
            }
        }
        return true;
    }


}


