package com.xinmeng.annotation;

import java.lang.annotation.*;

/**
 *  是否登录校验注解
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface LoginValidation {

}
