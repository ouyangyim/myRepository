package com.xinmeng.annotation;


import java.lang.annotation.*;

import static com.xinmeng.constant.RegexConstant.*;
import static com.xinmeng.constant.RegexConstant.TELREGEX;

/**
 *  参数格式校验注解
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ParameterValidation {

    String[] format() default {USERNAMEREGEX, PASSWORDREGEX, EMAILREGEX, TELREGEX};

}
