package com.xinmeng.templateMethod.PageConcrete;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.xinmeng.admin.mapper.RoleMapper;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.admin.service.IRoleService;
import com.xinmeng.admin.vo.UserVO;
import com.xinmeng.entity.User;
import com.xinmeng.templateMethod.PageTemplate;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 *  分页查询 用户评论
 */
public class PageUserConcrete<T extends User> extends PageTemplate<T> {

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private IRoleService roleService;


    @Override
    public void checkByCondition(IPage<T> page, LambdaQueryWrapper<T> lqw, String... parameters) {
        lqw.like(StringUtils.hasLength(parameters[0]), User::getUsername, parameters[0]);   // 用户名
        lqw.like(StringUtils.hasLength(parameters[1]), User::getTel, parameters[1]);      // 手机号码
        lqw.like(StringUtils.hasLength(parameters[2]), User::getMail, parameters[2]);   // 邮箱
        // 设定查询顺序
        lqw.orderByDesc(User::getId);
        // 角色名查询
        Integer roleId = roleMapper.getRoleIdByName(parameters[3]);
        if(StringUtils.hasLength(parameters[3])) {
            lqw.inSql(User::getId, String.format("SELECT user_id FROM user_role WHERE role_id = '%s'", roleId));
        }
        userMapper.selectPage((IPage<User>)page, (LambdaQueryWrapper<User>)lqw);
    }

    @Override
    public List encapsulationVO(List<T> list) {
        // 封装为 VO类型
        List<UserVO> userVOList = BeanCopyUtils.copyList(list, UserVO.class);
        // 查询每个用户 的角色
        for (UserVO userVO : userVOList) {
            userVO.setRoleNameList(roleService.getRoleNameByUserId(userVO.getId()));
        }
        return userVOList;
    }

}
