package com.xinmeng.templateMethod.PageConcrete;

import cn.hutool.core.convert.Convert;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.xinmeng.admin.dto.CommentDTO;
import com.xinmeng.admin.mapper.ArticleMapper;
import com.xinmeng.admin.mapper.CommentMapper;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.admin.vo.CommentVO;
import com.xinmeng.entity.Article;
import com.xinmeng.entity.Comment;
import com.xinmeng.entity.User;
import com.xinmeng.templateMethod.PageTemplate;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

import static com.xinmeng.constant.CommentConstant.*;

/**
 *  分页查询 用户评论
 */
public class PageCommentConcrete<T extends Comment> extends PageTemplate<T> {

    @Autowired
    private CommentMapper commentMapper;

    @Autowired
    private ArticleMapper articleMapper;

    @Autowired
    private UserMapper userMapper;


    @Override
    public void checkByCondition(IPage<T> page, LambdaQueryWrapper<T> lqw, String... parameters) {
        // 前端传来的字符串status整理一下
        Integer status1 = null;
        if (parameters[1] != null){
            status1 = parameters[1].equals(STATUS_APPROVED) ? APPROVED : PENDING;
        }
        lqw.like(StringUtils.hasLength(parameters[1]), Comment::getStatus, status1);
        lqw.like(StringUtils.hasLength(parameters[0]), Comment::getArticleName, parameters[0]);
        // 设定查询顺序
        lqw.orderByDesc(Comment::getId);
        commentMapper.selectPage((IPage<Comment>)page, (LambdaQueryWrapper<Comment>)lqw);
    }

    @Override
    public List encapsulationVO(List list) {
        List<Comment> commentList = BeanCopyUtils.copyList(list, Comment.class);
        List<CommentDTO> commentDTOList = new ArrayList<>();
        for (Comment comment : commentList) {
            CommentDTO commentDTO = Convert.convert(CommentDTO.class, comment);
            Article article = articleMapper.selectByName(comment.getArticleName());
            commentDTO.setArticle(article);
            User user = userMapper.getUserById(comment.getUserId());
            commentDTO.setUser(user);
            commentDTOList.add(commentDTO);
        }
        return commentDTOList;
    }

}
