package com.xinmeng.templateMethod.PageConcrete;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.xinmeng.admin.mapper.ArticleMapper;
import com.xinmeng.admin.mapper.RoleMapper;
import com.xinmeng.admin.vo.RoleVO;
import com.xinmeng.blog.vo.ArchiveVO;
import com.xinmeng.entity.Article;
import com.xinmeng.entity.Role;
import com.xinmeng.templateMethod.PageTemplate;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;

import static com.xinmeng.constant.ArticleConstant.SUBMIT;

/**
 *  分页查询 文章归档信息
 */
public class PageArchiveConcrete<T extends Article> extends PageTemplate<T> {

    @Autowired
    private ArticleMapper articleMapper;

    @Override
    public void checkByCondition(IPage<T> page, LambdaQueryWrapper<T> lqw, String... parameters) {
        lqw.eq(Article::getStatus, SUBMIT);
        lqw.orderByDesc(Article::getCreateTime);
        articleMapper.selectPage((IPage<Article>)page, (LambdaQueryWrapper<Article>)lqw);
    }

    @Override
    public List encapsulationVO(List list) {
        List<ArchiveVO> archiveVOList = BeanCopyUtils.copyList(list, ArchiveVO.class);
        for (ArchiveVO archiveVO : archiveVOList) {
            Integer spaceIndex = archiveVO.getCreateTime().indexOf(' ');
            String createTime1 = archiveVO.getCreateTime().substring(0, spaceIndex);
            archiveVO.setCreateTime1(createTime1);
        }
        return archiveVOList;
    }

}

