package com.xinmeng.templateMethod;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.xinmeng.vo.PageVO;

import java.util.List;

/**
 *  分页查询抽象模板 (查询字段为该数据表内字段)
 */
public abstract class PageTemplate<T> {  // 泛型类

    public abstract void checkByCondition(IPage<T> page, LambdaQueryWrapper<T> lqw, String... parameters);
    public abstract List encapsulationVO(List<T> list);

    public PageVO<T> pageTemplate(Integer pageSize, Integer currentPage, String... parameters){
        // 定义分页对象
        IPage<T> page = new Page<>(currentPage, pageSize);
        // 设置查询条件和查询顺序进行查询
        LambdaQueryWrapper<T> lqw = new LambdaQueryWrapper<>();
        checkByCondition(page, lqw, parameters);
        // 封装为VO
        List<T> list = page.getRecords();
        List voList = encapsulationVO(list);
        // 封装返回值
        return new PageVO<T>(page.getTotal(), voList);
    }

}
