package com.xinmeng.templateMethod.PageConcrete;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.xinmeng.admin.mapper.ArticleMapper;
import com.xinmeng.admin.mapper.CategoryMapper;
import com.xinmeng.admin.mapper.TagMapper;
import com.xinmeng.admin.service.ICategoryService;
import com.xinmeng.admin.service.ICommentService;
import com.xinmeng.admin.service.ITagService;
import com.xinmeng.admin.vo.ArticleVO;
import com.xinmeng.entity.Article;
import com.xinmeng.templateMethod.PageTemplate;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.util.List;

public class PageArticleConcrete<T extends Article> extends PageTemplate<T> {

    @Autowired
    private TagMapper tagMapper;

    @Autowired
    private CategoryMapper categoryMapper;

    @Autowired
    private ArticleMapper articleMapper;

    @Autowired
    private ITagService tagService;

    @Autowired
    private ICategoryService categoryService;

    @Override
    public void checkByCondition(IPage<T> page, LambdaQueryWrapper<T> lqw, String... parameters) {
        lqw.like(StringUtils.hasLength(parameters[0]), Article::getArticleName, parameters[0]);
        lqw.like(StringUtils.hasLength(parameters[1]), Article::getAuthor, parameters[1]);
        // 设定查询顺序
        lqw.orderByDesc(Article::getId);
        // 分类和标签条件查询
        Integer tagId = tagMapper.getTagIdByName(parameters[2]);
        Integer categoryId = categoryMapper.getCategoryIdByName(parameters[3]);
        if(StringUtils.hasLength(parameters[2])) {
            lqw.inSql(Article::getId, String.format("SELECT article_id FROM article_tag WHERE tag_id = '%s'", tagId));
        }
        if(StringUtils.hasLength(parameters[3])) {
            lqw.inSql(Article::getId, String.format("SELECT article_id FROM article_category WHERE category_id = '%s'", categoryId));
        }
        articleMapper.selectPage((IPage<Article>)page, (LambdaQueryWrapper<Article>)lqw);
    }

    @Override
    public List encapsulationVO(List<T> list) {
        // 封装为VO
        List<ArticleVO> articleVOList = BeanCopyUtils.copyList(list, ArticleVO.class);
        // 查询每个文章对象 对应的 标签和分类 （根据文章id得到标签id, 文章表->文章标签表->标签表）
        for (ArticleVO articleVO : articleVOList) {
            articleVO.setTagNameList(tagService.getTagNameByArticleId(articleVO.getId()));
            articleVO.setCategoryName(categoryService.getCategoryNameByArticleId(articleVO.getId()));
        }
        return articleVOList;
    }

}
