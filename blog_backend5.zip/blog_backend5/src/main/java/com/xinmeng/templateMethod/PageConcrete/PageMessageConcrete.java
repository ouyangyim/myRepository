package com.xinmeng.templateMethod.PageConcrete;


import cn.hutool.core.convert.Convert;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.xinmeng.admin.dto.MessageDTO;
import com.xinmeng.admin.mapper.ArticleMapper;
import com.xinmeng.admin.mapper.MessageMapper;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.blog.vo.ArchiveVO;
import com.xinmeng.entity.Article;
import com.xinmeng.entity.Message;
import com.xinmeng.entity.User;
import com.xinmeng.templateMethod.PageTemplate;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;


/**
 *  分页查询 用户留言
 */
public class PageMessageConcrete<T extends Message> extends PageTemplate<T> {

    @Autowired
    private MessageMapper messageMapper;

    @Autowired
    private UserMapper userMapper;

    @Override
    public void checkByCondition(IPage<T> page, LambdaQueryWrapper<T> lqw, String... parameters) {
        User user = userMapper.getUserByName(parameters[0]);
        if(user != null){
            lqw.eq(Message::getUserId, user.getId());
        }
        lqw.like(StringUtils.hasLength(parameters[1]), Message::getContent, parameters[1]);
        // 设定查询顺序
        lqw.orderByDesc(Message::getId);
        messageMapper.selectPage((IPage<Message>)page, (LambdaQueryWrapper<Message>)lqw);
    }

    @Override
    public List encapsulationVO(List list) {
        List<Message> messageList = BeanCopyUtils.copyList(list, Message.class);
        List<MessageDTO> messageDTOList = new ArrayList<>();
        for (Message message : messageList) {
            MessageDTO messageDTO = Convert.convert(MessageDTO.class, message);
            User user1 = userMapper.getUserById(message.getUserId());
            messageDTO.setUser(user1);
            messageDTOList.add(messageDTO);
        }
        return messageDTOList;
    }

}
