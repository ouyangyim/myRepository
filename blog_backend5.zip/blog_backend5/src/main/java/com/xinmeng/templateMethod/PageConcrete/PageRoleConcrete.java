package com.xinmeng.templateMethod.PageConcrete;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.xinmeng.admin.mapper.RoleMapper;
import com.xinmeng.admin.vo.RoleVO;
import com.xinmeng.entity.Role;
import com.xinmeng.templateMethod.PageTemplate;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 *  分页查询角色
 */
public class PageRoleConcrete<T extends Role> extends PageTemplate<T> {

    @Autowired
    private RoleMapper roleMapper;

    @Override
    public void checkByCondition(IPage<T> page, LambdaQueryWrapper<T> lqw, String... parameters) {
        lqw.like(StringUtils.hasLength(parameters[0]), Role::getRoleName, parameters[0]);
        lqw.like(StringUtils.hasLength(parameters[1]), Role::getRoleDesc, parameters[1]);
        lqw.orderByDesc(Role::getId);
        roleMapper.selectPage((IPage<Role>)page, (LambdaQueryWrapper<Role>)lqw);
    }

    @Override
    public List encapsulationVO(List list) {
        return BeanCopyUtils.copyList(list, RoleVO.class);
    }
}
