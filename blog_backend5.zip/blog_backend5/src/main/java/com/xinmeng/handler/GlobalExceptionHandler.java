package com.xinmeng.handler;

import com.xinmeng.exception.MyException;
import com.xinmeng.vo.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import static com.xinmeng.enums.ResultEnum.SYSTEM_ERROR;


/**
 *  异常处理器
 */
@RestControllerAdvice     // 用于定义全局异常处理器, 结合了 @ControllerAdvice 和 @ResponseBody 两个注解的功能
public class GlobalExceptionHandler {

    @ExceptionHandler(value = MyException.class)
    public Result<?> errorHandler(MyException e) {
        e.printStackTrace();
        return Result.fail(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(value = Exception.class)
    public Result<?> errorHandler(Exception e){
        e.printStackTrace();
        return Result.fail(SYSTEM_ERROR.getCode(), SYSTEM_ERROR.getMessage());
    }

}
