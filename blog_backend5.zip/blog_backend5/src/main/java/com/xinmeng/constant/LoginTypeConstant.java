package com.xinmeng.constant;

/**
 *  登录方式常量类
 */
public class LoginTypeConstant {

    public static final String PASSWORD_LOGIN = "账号登录";

    public static final String EMAIL_LOGIN = "邮箱登录";

    public static final String TEXT_LOGIN = "短信登录";

}
