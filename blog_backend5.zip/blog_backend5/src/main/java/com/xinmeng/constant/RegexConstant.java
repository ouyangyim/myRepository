package com.xinmeng.constant;


public class RegexConstant {

    /**
     * Swagger配置类中的路径匹配规则
     */
    public static final String PATHREGEX = "^(?!auth).*$";


    /**
     * 邮箱正则
     */
    public static final String EMAILREGEX = "^[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*\\.[a-z]{2,}$";


    /**
     *  密码格式正则
     */
    public static final String PASSWORDREGEX = "^.{6,10}$";


    /**
     * 手机号码正则
     */
    public static final String TELREGEX = "^1[3-9]\\d{9}$";


    /**
     *  用户名正则
     */
    public static final String USERNAMEREGEX = "^.{3,30}$";

}
