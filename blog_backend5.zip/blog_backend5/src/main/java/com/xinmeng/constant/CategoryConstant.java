package com.xinmeng.constant;

public class CategoryConstant {


    public static final String UPDATE_CATEGORY_SUCCESS = "修改分类成功";

    public static final String DELETE_CATEGORY_SUCCESS = "删除分类成功";

    public static final String ADD_CATEGORY_SUCCESS = "新增分类成功";


}
