package com.xinmeng.constant;

/**
 * Swagger文档相关常量
 */
public class SwaggerConstant {

    /**
     *  Swagger文档中的标题
     */
    public static final String TITLE = "个人博客后台管理系统接口文档";

    /**
     *  Swagger文档中的描述
     */
    public static final String DESC = "SpringBoot+Vue前后端分离项目";

    /**
     * Swagger版本
     */
    public static final String VERSION = "1.0";


    /**
     * 博主地址
     */
    public static final String ADDRESS = "http://www.qqcn.cn";

    /**
     * 博主邮箱
     */
    public static final String EMAIL = "3541404059@qq.com";


    public static final String HEADER = "header";

    /**
     * 权限范围
     */
    public static final String AUTH_SCOPE = "global";
    /**
     * 权限内容
     */
    public static final String AUTH_CONTENT = "accessEverything";


}
