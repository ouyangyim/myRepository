package com.xinmeng.constant;

public class BlogInfoConstant {

    /**
     * 网站头像
     */
    public static final String AVATAR = "https://personalblog-img-store.oss-cn-beijing.aliyuncs.com/2023/10/07/839d9179511a42eb8480d94e60635037.png";

    /**
     * 网站作者
     */
    public static final String AUTHOR = "逸 & 梦";

    /**
     * 网站名称
     */
    public static final String BLOG_NAME = "个人博客网站";

    /**
     * 网站介绍
     */
    public static final String INTRODUCTION = "基于SpringBoot+Vue的前后端分离项目";

    /**
     * 博主邮箱
     */
    public static final String EMAIL = "3541404059@qq.com";

    /**
     *  邮件标题
     */
    public static final String SUBJECT = "邮件验证码";




}
