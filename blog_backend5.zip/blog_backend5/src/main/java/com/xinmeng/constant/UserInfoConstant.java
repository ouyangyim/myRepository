package com.xinmeng.constant;

public class UserInfoConstant {

    public static final String USER = "用户";

    public static final String VISITOR = "游客";

    /** 初始化头像 */
    public static final String INIT_AVATAR = "https://personalblog-img-store.oss-cn-beijing.aliyuncs.com/2023/10/01/f68ec3dd8930454ab249c62d29e94e2d.png";


}
