package com.xinmeng.constant;


/**
 * 公关常量类
 */
public class CommonConstant {

    /**
     * 包名
     */
    public static final String PACKAGENAME = "com.xinmeng";


    /**
     * 高亮标签
     */
    public static final String PRE_TAG = "<span style='color:#f47466'>";

    /**
     * 高亮标签
     */
    public static final String POST_TAG = "</span>";



    /**
     *  得分格式
     */
    public static final String RATEFORMAT = "#.0";




    /**
     *  图片后缀
     */
    public static final String IMG_POST = "png";


    /**
     *  图片上传域名
     */
    public static final String DomainName = "http://rz69tewnj.bkt.clouddn.com/";



}
