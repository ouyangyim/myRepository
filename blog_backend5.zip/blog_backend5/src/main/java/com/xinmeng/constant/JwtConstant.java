package com.xinmeng.constant;


/**
 * JWT常量类
 */
public class JwtConstant {

    public static final String DATATYPE = "application/json;charset=utf-8";

    public static final String STOPVIEW = "禁止访问";

    public static final String ALLOWPASS = "放行...";

    public static final String WAIT_FOR_VERIFICATION = "待验证:";


    /**
     * token头
     */
    public static final String TOKEN = "X-Token";


}
