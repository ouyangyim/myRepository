package com.xinmeng.constant;


public class CommentConstant {

    public static final Integer APPROVED = 1;

    public static final Integer PENDING = 0;

    public static final String STATUS_APPROVED = "已审核";

    public static final String STATUS_PENDING = "待审核";

    public static final String DELETE_COMMENT_SUCCESS = "评论删除成功";

    public static final String REVIEW_COMMENT_SUCCESS = "评论审核成功";

}
