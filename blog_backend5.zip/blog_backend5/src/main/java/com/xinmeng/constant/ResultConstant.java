package com.xinmeng.constant;

import com.xinmeng.enums.ResultEnum;
import org.omg.CORBA.PUBLIC_MEMBER;

/**
 *  返回信息 常量类
 */
public class ResultConstant {

    /**
     *  文章常量类
     */
    public static final String UPDATE_ARTICLE_SUCCESS = "修改文章成功";

    public static final String DELETE_ARTICLE_SUCCESS = "删除文章成功";

    public static final String ADD_ARTICLE_SUCCESS = "添加文章成功";


    /**
     *  用户常量类
     */
    public static final String LOGIN_SUCCESS = "登录成功";

    public static final String LOGOUT_SUCCESS = "登出成功";

    public static final String UPDATE_USER_SUCCESS = "修改用户成功";

    public static final String DELETE_USER_SUCCESS = "删除用户成功";

    public static final String ADD_USER_SUCCESS = "新增用户成功";

    public static final String USERNAME_EXIST = "该用户名已存在";

    public static final String UPDATE_PASSWORD_SUCCESS = "修改密码成功";

    public static final String UPDATE_AVATAR_SUCCESS = "修改头像成功";

    public static final String CURRENT_PASSWORD_ERROR = "原密码错误";

    public static final String PASSWORD_FORMAT_ERROR = "密码格式错误";

    public static final String DIFFERENT_PASSWORD_ERROR = "两次密码不一致";

    public static final String ACCOUNT_EXIT = "该账号已被注册";

    public static final String VERIFICATION_CODE_ERROR = "验证码错误";

    public static final String RESET_PASSWORD_SUCCESS = "重置密码成功";

    public static final String ACCOUNT_NOT_REGISTER = "该账户还未被注册";

    public static final String SAME_PASSWORD = "重置密码不能与新密码相同";

    public static final String SET_PASSWORD_SUCCESS = "设置密码成功";

    public static final String VERIFICATION_CODE_RIGHT = "验证成功";

    public static final String USER_IS_DISABLE = "该用户已被禁用";

    public static final String USER_IS_ABLE = "该用户未被禁用";

    public static final String MAIL_EXIT = "该邮箱已被注册";

    public static final String TEL_EXIT = "该手机号码已被注册";

    public static final String AUTHEN_SUCCESS = "身份验证通过,请修改您的信息~";

    public static final String EMAIL_FORMAT_ERROR = "邮箱格式错误";


    /**
     *  角色常量类
     */
    public static final String UPDATE_ROLE_SUCCESS = "修改角色成功";

    public static final String DELETE_ROLE_SUCCESS = "删除角色成功";

    public static final String ADD_ROLE_SUCCESS = "新增角色成功";


    /**
     *  留言常量类
     */
    public static final String DELETE_MESSAGE_SUCCESS = "留言删除成功";

    public static final String MESSAGE_SUCCESS = "留言成功";

    public static final String COMMENT_SUCCESS = "评论成功";


    /**
     *  发送邮箱常量类
     */
    public static final String SEND_SUCCESS = "发送成功";

    public static final String MAIL_NOT_EXIT = "该邮箱不存在";

    public static final String MAIL_SEND_SUCCESS = "邮箱验证码发送成功";

    public static final String MAIL_SEND_FAILURE = "邮箱验证码发送失败,请重试~~";

    public static final String TEL_SEND_FAILURE = "短信验证码发送失败,请重试~~";

    public static final String TEXT_SEND_SUCCESS = "短信验证码发送成功";


    /**
     *  上传图片常量类
     */
    public static final String UPLOAD_SUCCESS = "上传成功";

    public static final String UPLOAD_ERROR = "上传失败";

    public static final String IMGCODE_GET_SUCCESS = "图形验证码获取成功";

    public static final String IMGCODE_GET_FAILURE = "图形验证码获取失败";



}
