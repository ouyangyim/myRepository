package com.xinmeng.constant;


/**
 *  文章相关常量类
 */
public class ArticleConstant {

    public static final Integer DELETED = 1;

    public static final Integer NO_DELETED = 0;

    public static final String DRAFT = "草稿";

    public static final String SUBMIT = "已发布";

    public static final Integer LATEST_ARTICLE = 10;

}
