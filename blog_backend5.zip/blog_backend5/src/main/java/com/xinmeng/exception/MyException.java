package com.xinmeng.exception;

import com.xinmeng.enums.ResultEnum;
import lombok.Data;

/**
 *  自定义异常
 */
@Data
public class MyException extends RuntimeException{

    private int code;
    private String msg;


    public MyException(ResultEnum resultEnum){
        super(resultEnum.getMessage());
        this.code = resultEnum.getCode();
        this.msg = resultEnum.getMessage();
    }

    public MyException(Exception e){
        super(e.getMessage());
        this.msg = e.getMessage();
    }

}
