package com.xinmeng.blog.controller;


import com.xinmeng.admin.dto.ArticleDTO;
import com.xinmeng.blog.dto.ArticleInfoDTO;
import com.xinmeng.blog.service.ArticleInfoService;
import com.xinmeng.blog.vo.*;
import com.xinmeng.vo.PageVO;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Api(tags = "前台文章接口")
@RestController
@RequestMapping("/api")
public class ArticleInfoController {

    @Autowired
    private ArticleInfoService articleInfoService;


    @ApiOperation("查询首页文章")
    @GetMapping("/article")
    public Result<?> getArticleInfo(){
        List<ArticleInfoDTO> articleDTOLIST = articleInfoService.getArticleInfo();
        return Result.ok(articleDTOLIST);
    }

    @ApiOperation("查询最新文章")
    @GetMapping("/latestArticle")
    public Result<?> getLatestArticles(){
        List<ArticleLatestVO> latestArticleList = articleInfoService.getLatestArticles();
        return Result.ok(latestArticleList);
    }


    @ApiOperation("前台归档信息")
    @GetMapping("/archive")
    public Result<?> getAllArchive(@RequestParam(value = "pageSize") Integer pageSize,
                                   @RequestParam(value = "currentPage") Integer currentPage){
        PageVO<ArchiveVO> data = articleInfoService.getAllArchive(pageSize, currentPage);
        return Result.ok(data);
    }


    @ApiOperation("根据关键字搜素文章")
    @GetMapping("/keywords")
    public Result<?> selectKeywords(@RequestParam String keywords){
        List<SearchResultVO> articleList = articleInfoService.selectKeywords(keywords);
        return Result.ok(articleList);
    }


    @ApiOperation("根据条件查询")
    @GetMapping("/article/condition")
    public Result<?> getArticleByCondition(@RequestParam(value = "tagId", required = false) Integer tagId,
                                           @RequestParam(value = "categoryId", required = false) Integer categoryId){
        ArticleListVO articleListVO = articleInfoService.getArticleByCondition(tagId, categoryId);
        return Result.ok(articleListVO);
    }

    @ApiOperation("文章详情")
    @GetMapping("/article/{id}")
    public Result<?> getArticleDetail(@PathVariable Integer id){
        ArticleDetailVO articleDetailVO = articleInfoService.getArticleDetail(id);
        return Result.ok(articleDetailVO);
    }


}
