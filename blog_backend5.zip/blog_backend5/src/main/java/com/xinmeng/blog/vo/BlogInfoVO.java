package com.xinmeng.blog.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BlogInfoVO {

    /**
     * 网站头像
     */
    private String avatar;

    /**
     * 网站作者
     */
    private String author;

    /**
     * 网站名称
     */
    private String blogName;

    /**
     * 网站介绍
     */
    private String introduction;

    /**
     * 网站文章总数
     */
    private Integer articleCount;

    /**
     * 网站用户总数
     */
    private Integer userCount;

    /**
     * 网站标签总数
     */
    private Integer tagCount;

    /**
     * 网站分类总数
     */
    private Integer categoryCount;

    /**
     * 网站创建时间
     */
    private String createTime;

}
