package com.xinmeng.blog.service.impl;

import com.xinmeng.entity.Page;
import com.xinmeng.blog.mapper.PageMapper;
import com.xinmeng.blog.service.IPageService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-19
 */
@Service
public class PageServiceImpl extends ServiceImpl<PageMapper, Page> implements IPageService {

}
