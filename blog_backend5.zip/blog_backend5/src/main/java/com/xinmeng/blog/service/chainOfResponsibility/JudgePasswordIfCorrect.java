package com.xinmeng.blog.service.chainOfResponsibility;

import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;

import static com.xinmeng.constant.ResultConstant.SAME_PASSWORD;

/**
 *  判断密码和原密码是否相同
 */
public class JudgePasswordIfCorrect extends Handler{

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private ExceptionUtils exceptionUtils;


    @Override
    public String execute(User user, RegisterAndForgetDTO forgetDTO) {
        // 与原密码相同
        exceptionUtils.exceptionDeal(passwordEncoder.matches(forgetDTO.getPassword(), user.getPassword()), ResultEnum.SAME_PASSWORD);
        return getHandler().execute(user, forgetDTO);
    }

}
