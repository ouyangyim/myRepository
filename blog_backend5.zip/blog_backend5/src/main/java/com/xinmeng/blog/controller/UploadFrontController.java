package com.xinmeng.blog.controller;

import com.xinmeng.pubick.service.UploadService;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import static com.xinmeng.constant.ResultConstant.UPLOAD_SUCCESS;

@Api(tags = "前台上传接口")
@RestController
@RequestMapping("/api")
public class UploadFrontController {


    @Autowired
    private UploadService uploadService;

    @ApiOperation("上传图片")
    @PostMapping("/upload")
    public Result<?> uploadImg(@RequestParam("img") MultipartFile img){
        String url = uploadService.uploadImg(img);
        return Result.ok(url, UPLOAD_SUCCESS);
    }


}
