package com.xinmeng.blog.vo;

import com.xinmeng.blog.dto.TagDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArticleDetailVO {

    /**
     * 文章内容
     */
    private String content;

    /**
     * 作者
     */
    private String author;

    /**
     * 文章id
     */
    private Integer id;

    /**
     * 文章标题
     */
    private String articleName;

    /**
     * 创建时间
     */
    private String createTime1;
    private String createTime;

    /**
     * 更新时间
     */
    private String updateTime;
    private String updateTime1;

    /**
     * 分类名
     */
    private String categoryName;

    /**
     * 分类id
     */
    private Integer categoryId;


    /**
     *  标签集合
     */
    private List<TagDTO> tagDTOList;

    /**
     * 浏览量
     */
    private Integer pageview;



}
