package com.xinmeng.blog.service.strategy.impl;

import cn.hutool.core.date.DateUtil;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.admin.mapper.UserRoleMapper;
import com.xinmeng.blog.service.strategy.LoginStrategy;
import com.xinmeng.constant.UserInfoConstant;
import com.xinmeng.entity.User;
import com.xinmeng.entity.UserRole;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import static com.xinmeng.constant.ResultConstant.USER_IS_DISABLE;
import static com.xinmeng.constant.ResultConstant.VERIFICATION_CODE_ERROR;
import static com.xinmeng.constant.UserInfoConstant.*;
import static com.xinmeng.enums.RoleEnum.USER;

@Data
@Component
public class TextLogin implements LoginStrategy {

    private String tel = null;

    private String code = null;

    @Autowired
    private CommonUtils commonUtils;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Autowired
    private UserRoleMapper userRoleMapper;

    public TextLogin(){}

    public TextLogin(String tel, String code){
        this.tel = tel;
        this.code = code;
    }


    @Override
    public Result<?> login(HttpServletRequest request) {
        // 比对验证码是否正确
        exceptionUtils.exceptionDeal(!code.equals(commonUtils.getCode(tel)), ResultEnum.VERIFICATION_CODE_ERROR);
        // 该手机号码是否已经注册？
        User user = userMapper.checkUserByTel(tel);
        if(user != null){
            // 如果已经注册
            // 验证用户是否可用
            exceptionUtils.exceptionDeal(commonUtils.checkUser(user).equals(USER_IS_DISABLE),ResultEnum.USER_IS_DISABLE);
            // 用户可用，直接登录即可，修改登陆状态、登录时间
            user.setLoginTime(DateUtil.now());
            user.setIsLogin(1);
            userMapper.updateById(user);
            return Result.ok(ResultEnum.LOGIN_SUCCESS.getCode(), ResultEnum.LOGIN_SUCCESS.getMessage(), user);
        }else{
            // 如果还没注册，则直接注册登录，创建新用户，设置邮箱、登录状态（这种方式 密码为设置）、登录时间
            User user1 = new User();
            user1.setUsername(tel);
            user1.setIsLogin(1);
            user1.setTel(tel);
            user1.setLoginTime(DateUtil.now());
            user1.setCreateTime(DateUtil.now());
            // 设置 用户描述 游客还是用户
            user1.setDescription(UserInfoConstant.USER);
            user1.setAvatar(INIT_AVATAR);
            // 设置 登录的ip地址
            String loginIp = request.getRemoteAddr();
            user1.setUserLoginIp(loginIp);
            System.out.println(user1.getAvatar());   ////
            userMapper.insert(user1);
            // 用户角色表
            UserRole userRole = new UserRole();
            userRole.setUserId(user1.getId());
            userRole.setRoleId(USER.getRoleId());
            userRoleMapper.insert(userRole);       // 用户对象插入用户表
            return Result.ok(ResultEnum.LOGIN_SUCCESS.getCode(), ResultEnum.LOGIN_SUCCESS.getMessage(), user1);
        }
    }
}
