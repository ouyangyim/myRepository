package com.xinmeng.blog.service.impl;

import cn.hutool.captcha.CaptchaUtil;
import cn.hutool.captcha.LineCaptcha;
import com.xinmeng.blog.service.CodeService;
import com.xinmeng.util.CommonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import static com.xinmeng.constant.BlogInfoConstant.EMAIL;
import static com.xinmeng.constant.BlogInfoConstant.SUBJECT;

@Service
public class CodeServiceImpl implements CodeService {

    @Resource
    private JavaMailSender javaMailSender;

    @Autowired
    private CommonUtils commonUtils;

    @Override
    @CachePut(value = "code", key = "#email")
    public String sendCode(String email) {
        // 发送人
        String from = EMAIL;
        // 接收人
        String to = email;
        // 标题
        String subject = SUBJECT;
        // 生成六位随机验证码发送  正文
        String code = commonUtils.getRandomCode();
        // 发送验证码
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(from);
        message.setTo(to);
        message.setSubject(subject);
        message.setText(code);
        javaMailSender.send(message);
        return code;
    }


    @Override
    @CachePut(value = "code", key = "#tel")
    public String sendTextCode(String tel){
        // 生成六位随机验证码
        String code = commonUtils.getRandomCode();


        // -------------------------------------------------------------
//        // HttpClient Configuration
//        /*HttpClient httpClient = new ApacheAsyncHttpClientBuilder()
//                .connectionTimeout(Duration.ofSeconds(10)) // Set the connection timeout time, the default is 10 seconds
//                .responseTimeout(Duration.ofSeconds(10)) // Set the response timeout time, the default is 20 seconds
//                .maxConnections(128) // Set the connection pool size
//                .maxIdleTimeOut(Duration.ofSeconds(50)) // Set the connection pool timeout, the default is 30 seconds
//                // Configure the proxy
//                .proxy(new ProxyOptions(ProxyOptions.Type.HTTP, new InetSocketAddress("<your-proxy-hostname>", 9001))
//                        .setCredentials("<your-proxy-username>", "<your-proxy-password>"))
//                // If it is an https connection, you need to configure the certificate, or ignore the certificate(.ignoreSSL(true))
//                .x509TrustManagers(new X509TrustManager[]{})
//                .keyManagers(new KeyManager[]{})
//                .ignoreSSL(false)
//                .build();*/

//        // Configure Credentials authentication information, including ak, secret, token
//        StaticCredentialProvider provider = StaticCredentialProvider.create(Credential.builder()
//                // Please ensure that the environment variables ALIBABA_CLOUD_ACCESS_KEY_ID and ALIBABA_CLOUD_ACCESS_KEY_SECRET are set.
//                .accessKeyId(System.getenv("LTAI5t8f5Sy57o2pG5VQkKwK"))
//                .accessKeySecret(System.getenv("1Uto07OOB4SCYurxQgtXmiSYROxqaf"))
//                //.securityToken(System.getenv("ALIBABA_CLOUD_SECURITY_TOKEN")) // use STS token
//                .build());
//
//        // Configure the Client
//        AsyncClient client = AsyncClient.builder()
//                .region("cn-beijing") // Region ID
//                //.httpClient(httpClient) // Use the configured HttpClient, otherwise use the default HttpClient (Apache HttpClient)
//                .credentialsProvider(provider)
//                //.serviceConfiguration(Configuration.create()) // Service-level configuration
//                // Client-level configuration rewrite, can set Endpoint, Http request parameters, etc.
//                .overrideConfiguration(
//                        ClientOverrideConfiguration.create()
//                                // Endpoint 请参考 https://api.aliyun.com/product/Dysmsapi
//                                .setEndpointOverride("dysmsapi.aliyuncs.com")
//                        //.setConnectTimeout(Duration.ofSeconds(30))
//                )
//                .build();
//
//        // Parameter settings for API request
//        SendSmsRequest sendSmsRequest = SendSmsRequest.builder()
//                .signName("阿里云短信测试")
//                .templateCode("SMS_154950909")
//                .phoneNumbers("19373603855")
//                .templateParam("{\"code\":\""+ code +"\"}")
//                // Request-level configuration rewrite, can set Http request parameters, etc.
//                // .requestConfiguration(RequestConfiguration.create().setHttpHeaders(new HttpHeaders()))
//                .build();
//
//        // Asynchronously get the return value of the API request
//        CompletableFuture<SendSmsResponse> response = client.sendSms(sendSmsRequest);
//        // Synchronously get the return value of the API request
//        SendSmsResponse resp =  response.get();
//        System.out.println(new Gson().toJson(resp));
//        // Asynchronous processing of return values
//        /*response.thenAccept(resp -> {
//            System.out.println(new Gson().toJson(resp));
//        }).exceptionally(throwable -> { // Handling exceptions
//            System.out.println(throwable.getMessage());
//            return null;
//        });*/
//        // Finally, close the client
//        client.close();
        // ------------------------------------------------------
        return code;
    }


    //   @Override
    //    @CachePut(value = "code", key = "#email")
    //    public String sendCode(String email) {
    //        // 发送人
    //        String from = EMAIL;
    //        // 接收人
    //        String to = email;
    //        // 标题
    //        String subject = SUBJECT;
    //        // 生成六位随机验证码发送  正文
    //        String code = commonUtils.getRandomCode();
    //        // 发送验证码
    //        SimpleMailMessage message = new SimpleMailMessage();
    //        message.setFrom(from);
    //        message.setTo(to);
    //        message.setSubject(subject);
    //        message.setText(code);
    //        javaMailSender.send(message);
    //        return code;
    //    }


    /**
     *  生成图片验证码
     * @return
     */
    @Override
    @CachePut(value = "lineCaptcha", key = "#ipAddress")
    public LineCaptcha generateImgCode(String ipAddress) {
        // 定义图形验证码的长和宽
        LineCaptcha lineCaptcha = CaptchaUtil.createLineCaptcha(150, 100);
        return lineCaptcha;
    }


}
