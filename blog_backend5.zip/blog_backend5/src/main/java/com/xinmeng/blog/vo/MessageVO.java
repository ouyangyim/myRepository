package com.xinmeng.blog.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MessageVO {

    private Integer id;

    /**
     * 评论用户id
     */
    private Integer userId;


    /**
     * 评论用户头像
     */
    private String avatar;

    /**
     * 评论用户名
     */
    private String username;

    /**
     * 评论内容
     */
    private String content;

}
