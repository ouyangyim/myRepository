package com.xinmeng.blog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.admin.vo.TagVO;
import com.xinmeng.entity.Tag;

import java.util.List;

public interface TagInfoService extends IService<Tag> {
    List<Tag> getTopTags();

    List<TagVO> getAllTags();
}
