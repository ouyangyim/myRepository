package com.xinmeng.blog.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArticleListVO {

    /**
     * 标签名或分类名
     */
    private String name;

    /**
     * 文章信息集合
     */
    private List<ArticleVO> articleVOList;

}
