package com.xinmeng.blog.service.strategy;

import com.xinmeng.vo.Result;

import javax.servlet.http.HttpServletRequest;

/**
 *  登录策略类
 */
public interface LoginStrategy {

    Result<?> login(HttpServletRequest request);

}
