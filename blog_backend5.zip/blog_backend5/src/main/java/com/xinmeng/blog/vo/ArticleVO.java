package com.xinmeng.blog.vo;

import com.xinmeng.blog.dto.TagDTO;
import com.xinmeng.entity.Tag;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArticleVO {

    /**
     * 文章id
     */
    private Integer id;

    /**
     * 文章标题
     */
    private String articleName;

    /**
     * 创建时间
     */
    private String createTime1;

    private String createTime;

    /**
     * 分类名
     */
    private String categoryName;

    /**
     *  标签集合
     */
    private List<TagDTO> tagDTOList;

    /**
     * 文章缩略图
     */
    private String thumbnail;

    /**
     * 分类id
     */
    private Integer categoryId;





}
