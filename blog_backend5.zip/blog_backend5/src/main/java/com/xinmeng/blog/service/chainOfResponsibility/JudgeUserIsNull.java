package com.xinmeng.blog.service.chainOfResponsibility;

import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import static com.xinmeng.constant.ResultConstant.ACCOUNT_NOT_REGISTER;

/**
 *  判断用户是否存在
 */
public class JudgeUserIsNull extends Handler{

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Override
    public String execute(User user, RegisterAndForgetDTO forgetDTO) {
        // 如果没有注册，返回信息
        exceptionUtils.exceptionDeal(user == null, ResultEnum.ACCOUNT_NOT_REGISTER);
        return getHandler().execute(user, forgetDTO);
    }

}
