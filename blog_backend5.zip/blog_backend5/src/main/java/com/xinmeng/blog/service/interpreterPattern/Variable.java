package com.xinmeng.blog.service.interpreterPattern;

/**
 *  具体表达式类 —— 变量
 */
public class Variable extends AbstractExpression{

    private String variableName;  // 封装变量的变量名（在Context中可根据此变量名得到变量值）

    public String getVariableName() {
        return variableName;
    }

    public void setVariableName(String variableName) {
        this.variableName = variableName;
    }

    public Variable(String variableName) {
        this.variableName = variableName;
    }

    @Override
    public Double interpret(Context context) {
        return context.getValue(this);
    }

    @Override
    public String toString() {
        return  variableName;
    }


    @Override
    public Object clone() throws CloneNotSupportedException {
        Variable var = new Variable(this.variableName);
        return var;
    }

}
