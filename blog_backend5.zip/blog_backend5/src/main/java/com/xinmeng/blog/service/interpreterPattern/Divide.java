package com.xinmeng.blog.service.interpreterPattern;

public class Divide extends AbstractExpression{

    private AbstractExpression left;
    private AbstractExpression right;

    public Divide(AbstractExpression left, AbstractExpression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public Double interpret(Context context) {
        return left.interpret(context) / right.interpret(context);
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " / " + right.toString() + ")";
    }

}
