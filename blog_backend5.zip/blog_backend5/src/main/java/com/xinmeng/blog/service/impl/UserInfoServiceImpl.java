package com.xinmeng.blog.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.blog.dto.*;
import com.xinmeng.blog.service.UserInfoService;
import com.xinmeng.blog.service.decorator.registerConcreteDecorator.JudgeCodeIfRightConcreteDecorator;
import com.xinmeng.blog.service.decorator.registerConcreteDecorator.JudgeIfSamePasswordConcreteDecorator;
import com.xinmeng.blog.service.decorator.registerConcreteDecorator.JudgeImageCodeIfRightConcreteDecorator;
import com.xinmeng.blog.service.decorator.registerConcreteDecorator.JudgeUserIfExistConcreteDecorator;
import com.xinmeng.blog.service.decorator.RegisterComponent;
import com.xinmeng.blog.service.chainOfResponsibility.JudgeIfSamePassword;
import com.xinmeng.blog.service.chainOfResponsibility.JudgePasswordIfCorrect;
import com.xinmeng.blog.service.chainOfResponsibility.JudgeUserIsNull;
import com.xinmeng.blog.service.strategy.LoginContext;
import com.xinmeng.dto.AuthenDTO;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.servlet.http.HttpServletRequest;
import static com.xinmeng.constant.LoginTypeConstant.*;
import static com.xinmeng.constant.RegexConstant.*;
import static com.xinmeng.constant.ResultConstant.*;
import static com.xinmeng.enums.ResultEnum.AUTHEN_FAILURE;

@Primary
@Slf4j
@Service
@Import({JudgeUserIsNull.class, JudgePasswordIfCorrect.class, JudgeIfSamePassword.class})
public class UserInfoServiceImpl extends ServiceImpl<UserMapper, User> implements UserInfoService {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private LoginContext loginContext;

    @Autowired
    private RegisterComponent registerComponent;

    @Autowired
    private JudgeUserIfExistConcreteDecorator judgeUserIfExistConcreteDecorator;

    @Autowired
    private JudgeCodeIfRightConcreteDecorator judgeCodeIfRightConcreteDecorator;

    @Autowired
    private JudgeIfSamePasswordConcreteDecorator judgeIfSamePasswordConcreteDecorator;

    @Autowired
    private JudgeImageCodeIfRightConcreteDecorator judgeImageCodeIfRightConcreteDecorator;

    @Autowired
    private ExceptionUtils exceptionUtils;



    /**
     * 注册用户 （新增用户） （装饰模式）
     * @param registerAndForgetDTO
     * @return
     */
    @Override
    @Transactional
    public Result<?> registerUser(RegisterAndForgetDTO registerAndForgetDTO, HttpServletRequest request) {
        // 判断用户是否存在 —— 判断验证码是否正确 —— 判断图片验证码是否正确 —— 判断两次密码输入是否一致
        judgeIfSamePasswordConcreteDecorator.judgeUserIfExistDecorator(registerComponent);
        judgeImageCodeIfRightConcreteDecorator.judgeUserIfExistDecorator(judgeIfSamePasswordConcreteDecorator); //
        judgeCodeIfRightConcreteDecorator.judgeUserIfExistDecorator(judgeImageCodeIfRightConcreteDecorator);    //
//       // 判断用户是否存在 —— 判断验证码是否正确 —— 判断两次密码输入是否一致
//        judgeCodeIfRightConcreteDecorator.judgeUserIfExistDecorator(judgeIfSamePasswordConcreteDecorator);
        judgeUserIfExistConcreteDecorator.judgeUserIfExistDecorator(judgeCodeIfRightConcreteDecorator);
        return judgeUserIfExistConcreteDecorator.registerUser(registerAndForgetDTO, request);
    }



    /**
     * 用户账号登录 （策略模式）
     * @param accountLoginDTO
     * @return
     */
    @Override
    public Result<?> accountLogin(AccountLoginDTO accountLoginDTO, HttpServletRequest request) {
        JSONObject json = JSONUtil.parseObj(accountLoginDTO, false);
        loginContext.LoginContext(PASSWORD_LOGIN, json);
        return loginContext.getResult(request);
    }


    /**
     * 注销用户
     * @param userId
     */
    @Override
    public void logout(Integer userId) {
        // 根据id得到用户
        User user = this.baseMapper.getById(userId);
        // 修改用户的 登录状态
        user.setIsLogin(0);
        this.baseMapper.updateById(user);
    }


    /**
     * 邮箱登录 （策略模式）
     * @param emailLoginDTO
     * @return
     */
    @Override
    @Transactional
    public Result<?> emailLogin(EmailLoginDTO emailLoginDTO, HttpServletRequest request) {
        JSONObject json = JSONUtil.parseObj(emailLoginDTO, false);
        loginContext.LoginContext(EMAIL_LOGIN, json);
        return loginContext.getResult(request);
    }


    /**
     * 短信登录 （策略模式）
     * @param telLoginDTO
     * @return
     */
    @Override
    @Transactional
    public Result<?> textLogin(TelLoginDTO telLoginDTO, HttpServletRequest request) {
        JSONObject json = JSONUtil.parseObj(telLoginDTO);
        loginContext.LoginContext(TEXT_LOGIN, json);
        return loginContext.getResult(request);
    }



    /**
     *  用户信息修改身份验证
     * @param authenDTO
     * @param userId
     * @return
     */
    @Override
    public Result<?> haveAuthenticated(AuthenDTO authenDTO, Integer userId) {
        User user = this.baseMapper.getById(userId);
        exceptionUtils.exceptionDeal(!passwordEncoder.matches(authenDTO.getPassword(),user.getPassword()), AUTHEN_FAILURE);
        return Result.ok(true, AUTHEN_SUCCESS);
    }


    /**
     * 忘记密码
     * @param forgetDTO
     */
    @Override
    public String forget(RegisterAndForgetDTO forgetDTO) {
        User user = new User();
        // 验证 账号是否已经注册
        String account = forgetDTO.getUsername();
        if(account.matches(EMAILREGEX)){
            user = this.baseMapper.checkUserByEmail(account);
        }else{
            user = this.baseMapper.checkUserByTel(account);
        }

        // 异常处理
        exceptionUtils.exceptionDeal(user!=null, ResultEnum.ACCOUNT_NOT_REGISTER);
        exceptionUtils.exceptionDeal(!passwordEncoder.matches(forgetDTO.getPassword(), user.getPassword()), ResultEnum.SAME_PASSWORD);
        exceptionUtils.exceptionDeal(forgetDTO.getPassword().equals(forgetDTO.getConfirmPassword()), ResultEnum.SAME_PASSWORD);
        // 两次输入相同, 修改密码
        user.setPassword(passwordEncoder.encode(forgetDTO.getPassword()));
        this.baseMapper.updateById(user);
        return RESET_PASSWORD_SUCCESS;



//        // 职责链模式: 用户是否存在 —— 验证密码是否正确 —— 两次密码输入是否相同
//        // 构建职责链
//        judgeUserIsNull.setHandler(judgePasswordIfCorrect);
//        judgePasswordIfCorrect.setHandler(judgeIfSamePassword);
//        // 执行职责链
//        return judgeUserIsNull.execute(user, forgetDTO);


//        if(user != null){
//            // 如果已经注册，则修改密码
//            // 验证密码是否与原密码相同
//            if(!passwordEncoder.matches(forgetDTO.getPassword(), user.getPassword())){
//                // 与原密码不同，验证两次密码输入是否相同
//                if(forgetDTO.getPassword().equals(forgetDTO.getConfirmPassword())){
//                    // 两次输入相同, 修改密码
//                    user.setPassword(passwordEncoder.encode(forgetDTO.getPassword()));
//                    this.baseMapper.updateById(user);
//                    return RESET_PASSWORD_SUCCESS;
//                }else{
//                    // 两次输入不同
//                    return DIFFERENT_PASSWORD_ERROR;
//                }
//            }else{
//                // 与原密码相同
//                return SAME_PASSWORD;
//            }
//        }else{
//            // 如果没有注册，返回信息
//            return ACCOUNT_NOT_REGISTER;
//        }


    }


    /**
     * 修改头像
     * @param avatar
     * @param userId
     */
    @Override
    public void updateAvatar(String avatar, Integer userId) {
        // 根据id得到用户
        User user = this.baseMapper.selectById(userId);
        // 修改用户头像
        user.setAvatar(avatar);
        this.baseMapper.updateById(user);
    }


    /**
     *  修改用户信息(需要判断用户名是否存在)
     * @param userDTO
     */
    @Override
    public String updateUser(UserDTO userDTO) {
        // 转为User对象
        User user = Convert.convert(User.class, userDTO);
        // 查询用户名是否存在(数据库中是否存在该用户名的用户)
        LambdaQueryWrapper<User> lqw = new LambdaQueryWrapper<>();
        lqw.eq(User::getUsername, user.getUsername());
        User user1 = this.baseMapper.selectOne(lqw);     // 每个用户名唯一,所以这里查一个即可
        // 如果存在用户名为此时输入用户名的用户, 且根据id判断该用户不是本人
        exceptionUtils.exceptionDeal(user1!=null && user1.getId()!=user.getId(), ResultEnum.USERNAME_EXIST);
        // 修改用户表
        user.setUpdateTime(DateUtil.now());   // 修改时间
        this.baseMapper.updateById(user);
        return UPDATE_USER_SUCCESS;
    }


    /**
     * 设置密码
     * @param setPasswordForm
     * @param userId
     * @return
     */
    @Override
    public String setPassword(PasswordDTO setPasswordForm, Integer userId) {
        exceptionUtils.exceptionDeal(!setPasswordForm.getPassword().equals(setPasswordForm.getConfirmPassword()), ResultEnum.DIFFERENT_PASSWORD_ERROR);
        // 两次密码输入一致，存储密码
        User user = this.getById(userId);
        user.setPassword(passwordEncoder.encode(setPasswordForm.getPassword()));
        user.setUpdateTime(DateUtil.now());
        this.baseMapper.updateById(user);
        return SET_PASSWORD_SUCCESS;
    }



}
