package com.xinmeng.blog.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArchiveVO {

    /**
     * 文章id
     */
    private Integer id;

    /**
     * 作者
     */
    private String author;

    /**
     * 文章名
     */
    private String articleName;

    /**
     * 文章创建时间-年月日
     */
    private String createTime1;

    /**
     * 文章创建时间-详细时间
     */
    private String createTime;



}
