package com.xinmeng.blog.controller;

import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-19
 */
@Api(tags = "页面访问接口")
@RestController
@RequestMapping("/api/page")
public class PageController {



}
