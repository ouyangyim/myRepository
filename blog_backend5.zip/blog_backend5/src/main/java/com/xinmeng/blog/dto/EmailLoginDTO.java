package com.xinmeng.blog.dto;

import com.xinmeng.dto.ParameterDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailLoginDTO extends ParameterDTO {

    /**
     * 邮箱
     */
    private String mail;

    /**
     * 验证码
     */
    private String code;

}
