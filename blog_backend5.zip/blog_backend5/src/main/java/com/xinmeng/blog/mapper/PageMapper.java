package com.xinmeng.blog.mapper;

import com.xinmeng.entity.Page;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-19
 */
@Repository
public interface PageMapper extends BaseMapper<Page> {

    Page selectByUrl(String url);
}
