package com.xinmeng.blog.service.chainOfResponsibility;

import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.entity.User;

/**
 *  抽象职责类
 */
public abstract class Handler {

    // 此职责对象的下一位
    private Handler handler;


    // 设置职责对象的下一位
    public void setHandler(Handler handler){
        this.handler = handler;
    }

    public Handler getHandler() {
        return handler;
    }

    // 执行代码
    public abstract String execute(User user, RegisterAndForgetDTO forgetDTO);


}
