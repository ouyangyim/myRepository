package com.xinmeng.blog.controller;

import com.xinmeng.blog.service.BlogInfoService;
import com.xinmeng.blog.vo.BlogInfoVO;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "博客网站信息接口")
@RestController
@RequestMapping("/api")
public class BlogInfoController {

    @Autowired
    private BlogInfoService blogInfoService;

    @ApiOperation("查询网站信息")
    @GetMapping("/blog")
    public Result<?> getBlogInfo(){
        BlogInfoVO blogInfo = blogInfoService.getBlogInfo();
        return Result.ok(blogInfo);
    }

}
