package com.xinmeng.blog.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SearchResultVO {

    /**
     * 文章id
     */
    private Integer id;


    /**
     * 文章名
     */
    private String articleName;


    /**
     * 文章内容
     */
    private String content;


}
