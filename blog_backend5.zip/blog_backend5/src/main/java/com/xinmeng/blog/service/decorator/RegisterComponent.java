package com.xinmeng.blog.service.decorator;

import cn.hutool.core.date.DateUtil;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.admin.mapper.UserRoleMapper;
import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.constant.UserInfoConstant;
import com.xinmeng.entity.User;
import com.xinmeng.entity.UserRole;
import com.xinmeng.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import static com.xinmeng.constant.RegexConstant.EMAILREGEX;
import static com.xinmeng.constant.UserInfoConstant.*;
import static com.xinmeng.enums.ResultEnum.REGISTER_SUCCESS;
import static com.xinmeng.enums.RoleEnum.USER;

/**
 *  注册用户
 */
@Component
public class RegisterComponent {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private UserRoleMapper userRoleMapper;


    public Result<?> registerUser(RegisterAndForgetDTO registerAndForgetDTO, HttpServletRequest request){
        // 用户表
        // 创建 用户对象
        User user = new User();
        user.setPassword(passwordEncoder.encode(registerAndForgetDTO.getPassword()));  // 密码, 先加密后存储
        user.setUsername(registerAndForgetDTO.getUsername());   // 初始用户名
        user.setStatus(0);   // 用户状态 可用
        user.setAvatar(INIT_AVATAR);   // 初始头像
        user.setDescription(UserInfoConstant.USER);  // 用户描述 游客还是用户
        // 判断 用户输入账号是邮箱还是手机号码
        if (registerAndForgetDTO.getUsername().matches(EMAILREGEX)){
            user.setMail(registerAndForgetDTO.getUsername());
        }else{
            user.setTel(registerAndForgetDTO.getUsername());
        }
        // 创建日期
        user.setCreateTime(DateUtil.now());
        user.setAvatar(INIT_AVATAR);
        userMapper.insert(user);
        // 用户角色表
        UserRole userRole = new UserRole();
        userRole.setUserId(user.getId());
        userRole.setRoleId(USER.getRoleId());
        userRoleMapper.insert(userRole);       // 用户对象插入用户表
        return Result.ok(REGISTER_SUCCESS.getMessage());
    }

}
