package com.xinmeng.blog.service;

import com.xinmeng.entity.Page;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xinmeng
 * @since 2023-08-19
 */
public interface IPageService extends IService<Page> {

}
