package com.xinmeng.blog.service.strategy.impl;

import cn.hutool.core.date.DateUtil;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.blog.service.impl.UserInfoServiceImpl;
import com.xinmeng.blog.service.strategy.LoginStrategy;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import static com.xinmeng.constant.RegexConstant.EMAILREGEX;
import static com.xinmeng.constant.ResultConstant.USER_IS_DISABLE;
import static com.xinmeng.enums.ResultEnum.*;

@Data
@Component
public class PasswordLogin implements LoginStrategy {
    
    private String account = null;
    
    private String password = null;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private CommonUtils commonUtils;

    @Autowired
    private ExceptionUtils exceptionUtils;


    @Override
    public Result<?> login(HttpServletRequest request) {
        User user = new User();
        if (account.matches(EMAILREGEX)){
            // 根据 邮箱查询 用户
            user = userMapper.checkUserByEmail(account);
            exceptionUtils.exceptionDeal(user == null, EMAIL_NOT_REGISTER);
        }else{
            // 根据 手机号码查询 用户
            user = userMapper.checkUserByTel(account);
            exceptionUtils.exceptionDeal(user == null, Tel_NOT_REGISTER);
        }
        // 验证用户是否可用
        exceptionUtils.exceptionDeal(commonUtils.checkUser(user).equals(USER_IS_DISABLE),ResultEnum.USER_IS_DISABLE);
        // 验证密码是否正确
        exceptionUtils.exceptionDeal(!passwordEncoder.matches(password, user.getPassword()), PASSWORD_ERROR);
        // 正确，设置 登录时间
        user.setLoginTime(DateUtil.now());
        // 设置 登录状态
        user.setIsLogin(1);
        // 设置 登录的ip地址
        String loginIp = request.getRemoteAddr();
        user.setUserLoginIp(loginIp);
        userMapper.updateById(user);
        return Result.ok(ResultEnum.LOGIN_SUCCESS.getCode(), ResultEnum.LOGIN_SUCCESS.getMessage(), user);
    }

}
