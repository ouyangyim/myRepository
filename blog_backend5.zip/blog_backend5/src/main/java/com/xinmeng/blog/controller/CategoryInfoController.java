package com.xinmeng.blog.controller;


import com.xinmeng.admin.vo.CategoryVO;
import com.xinmeng.blog.service.CategoryInfoService;
import com.xinmeng.entity.Category;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(tags = "前台分类接口")
@RestController
@RequestMapping("/api")
public class CategoryInfoController {

    @Autowired
    private CategoryInfoService categoryInfoService;

    @ApiOperation("热门分类")
    @GetMapping("/topCategories")
    public Result<?> getTopCategory(){
        List<Category> categoryList = categoryInfoService.getTopCategory();
        return Result.ok(categoryList);
    }

    @ApiOperation("全部分类")
    @GetMapping("/allCategories")
    public Result<?> getAllCategory(){
        List<CategoryVO> categoryVOList = categoryInfoService.getAllCategory();
        return Result.ok(categoryVOList);
    }

}
