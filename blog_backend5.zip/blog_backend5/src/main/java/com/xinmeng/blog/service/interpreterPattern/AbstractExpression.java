package com.xinmeng.blog.service.interpreterPattern;

/**
 *  抽象表达式类
 */
public abstract class AbstractExpression {

    public abstract Double interpret(Context context);

}
