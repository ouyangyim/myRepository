package com.xinmeng.blog.dto;

import lombok.Data;

@Data
public class PasswordDTO {

    /**
     * 密码
     */
    private String password;

    /**
     * 确认密码
     */
    private String confirmPassword;

}
