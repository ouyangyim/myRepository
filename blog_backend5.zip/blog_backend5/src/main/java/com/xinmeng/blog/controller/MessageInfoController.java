package com.xinmeng.blog.controller;


import com.xinmeng.annotation.LoginValidation;
import com.xinmeng.blog.dto.MessageDTO;
import com.xinmeng.blog.service.MessageInfoService;
import com.xinmeng.blog.vo.MessageVO;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "前台留言接口")
@RestController
@RequestMapping("/api")
public class MessageInfoController {

    @Autowired
    private MessageInfoService messageInfoService;


    @ApiOperation("发送留言")
    @PutMapping("/message")
    @LoginValidation
    public Result<?> sendMessage(@RequestBody MessageDTO messageDTO){
        String message = messageInfoService.sendMessage(messageDTO);
        return Result.ok(message);
    }


    @ApiOperation("获取全部留言")
    @GetMapping("/message")
    public Result<?> getAllMessage(){
        List<MessageVO> messageDTOList = messageInfoService.getAllMessage();
        return Result.ok(messageDTOList);
    }


}
