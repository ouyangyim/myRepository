package com.xinmeng.blog.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.admin.mapper.CategoryMapper;
import com.xinmeng.admin.vo.CategoryVO;
import com.xinmeng.blog.service.CategoryInfoService;
import com.xinmeng.entity.Category;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryInfoServiceImpl extends ServiceImpl<CategoryMapper, Category> implements CategoryInfoService {

    /**
     * 热门分类
     * @return
     */
    @Override
    public List<Category> getTopCategory() {
        // 得到对应文章数最多的十个分类集合
        List<Category> categoryList = this.baseMapper.getTopCategories();
        return categoryList;
    }

    /**
     * 全部分类
     * @return
     */
    @Override
    public List<CategoryVO> getAllCategory() {
        // 得到全部分类
        List<Category> categoryList = this.baseMapper.selectList(null);
        // 转换为VO
        List<CategoryVO> categoryVOList = BeanCopyUtils.copyList(categoryList, CategoryVO.class);
        // 遍历全部分类，设置每个分类对应的文章数
        for (CategoryVO categoryVO : categoryVOList) {
            categoryVO.setArticleList(this.baseMapper.getArticleListByCategoryId(categoryVO.getId()));
        }
        return categoryVOList;
    }

}
