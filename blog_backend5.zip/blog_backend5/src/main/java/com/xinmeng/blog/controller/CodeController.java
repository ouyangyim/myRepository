package com.xinmeng.blog.controller;

import cn.hutool.captcha.LineCaptcha;
import com.xinmeng.pubick.service.UploadService;
import com.xinmeng.annotation.AccessLimit;
import com.xinmeng.annotation.ParameterValidation;
import com.xinmeng.blog.dto.EmailLoginDTO;
import com.xinmeng.blog.dto.TelLoginDTO;
import com.xinmeng.blog.service.CodeService;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import static com.xinmeng.constant.RegexConstant.EMAILREGEX;
import static com.xinmeng.constant.RegexConstant.TELREGEX;
import static com.xinmeng.constant.ResultConstant.*;

@Slf4j
@Api(tags = "发送验证码接口")
@RestController
@RequestMapping("/api")
public class CodeController {

    @Resource
    private CodeService codeService;

    @Autowired
    private UploadService uploadService;

    @Autowired
    private CommonUtils commonUtils;


    @AccessLimit(seconds = 60, maxCount = 1)
    @ApiOperation(value = "发送邮箱验证码")
    @PostMapping("/emailCode")
    @ParameterValidation(format = {EMAILREGEX})
    public Result<?> sendCode(@RequestBody EmailLoginDTO email) {         // 这里得改
        try {
            codeService.sendCode(email.getMail());
            return Result.ok(MAIL_SEND_SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail(MAIL_SEND_FAILURE);
        }
    }


    @AccessLimit(seconds = 60, maxCount = 1)
    @ApiOperation("发送短信验证码")
    @PostMapping("/telCode")
    @ParameterValidation(format = {TELREGEX})
    public Result<?> sendTextCode(@RequestBody TelLoginDTO tel){
        try {
            codeService.sendTextCode(tel.getTel());
            return Result.ok(TEXT_SEND_SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail(TEL_SEND_FAILURE);
        }
    }


    /**
     *  还有问题
     * @param request
     * @return
     */
    @ApiOperation("生成图片验证码")
    @PostMapping("/imgCode")
    public Result<?> sendImgCode(HttpServletRequest request){
        try {
            // 生成图片验证码 -  图片验证码存入缓存
            codeService.generateImgCode(request.getRemoteAddr());
            // 从缓存中获取图片
            LineCaptcha imgCode = commonUtils.getImgCode(request.getRemoteAddr());
            String code = imgCode.getCode();
            BufferedImage image = imgCode.getImage();
            // 图片转为MultipartFile类型
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ImageIO.write(image, "png", outputStream);
            InputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
            MultipartFile imageFile = new MockMultipartFile("imgCode.png", "imgCode.png","", inputStream);
            // 上传图片
            String url = uploadService.uploadImg(imageFile);
            // 返回图片的url
            return Result.ok(url, IMGCODE_GET_SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail(IMGCODE_GET_FAILURE);
        }
    }


}
