package com.xinmeng.blog.controller;

import com.xinmeng.annotation.LoginValidation;
import com.xinmeng.blog.dto.CommentDTO;
import com.xinmeng.blog.service.CommentInfoService;
import com.xinmeng.blog.vo.CommentVO;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "前台评论接口")
@RestController
@RequestMapping("/api")
public class CommentInfoController {

    @Autowired
    private CommentInfoService commentService;


    @ApiOperation("获得全部评论信息")
    @GetMapping("/allComment/{articleId}")
    public Result<?> getAllComment(@PathVariable Integer articleId){
        List<CommentVO> commentVOList = commentService.getAllComment(articleId);
        return Result.ok(commentVOList);
    }


    @ApiOperation("发送评论")
    @PutMapping("/sendComment")
    @LoginValidation
    public Result<?> sendComment(@RequestBody CommentDTO commentDTO){
        String message = commentService.sendComment(commentDTO);
        return Result.ok(message);
    }



}
