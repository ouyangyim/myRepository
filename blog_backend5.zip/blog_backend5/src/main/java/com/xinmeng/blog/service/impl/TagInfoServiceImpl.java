package com.xinmeng.blog.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.admin.mapper.TagMapper;
import com.xinmeng.admin.vo.TagVO;
import com.xinmeng.blog.service.TagInfoService;
import com.xinmeng.entity.Tag;
import com.xinmeng.util.BeanCopyUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TagInfoServiceImpl extends ServiceImpl<TagMapper, Tag> implements TagInfoService {

    /**
     * 得到热门标签（前十）
     * @return
     */
    @Override
    public List<Tag> getTopTags() {
        // 得到对应文章数最多的十个标签集合
        List<Tag> tagList = this.baseMapper.getTopTags();
        return tagList;
    }


    /**
     * 全部标签
     * @return
     */
    @Override
    public List<TagVO> getAllTags() {
        // 得到全部标签
        List<Tag> tagList = this.baseMapper.selectList(null);
        // 转换为VO
        List<TagVO> tagVOList = BeanCopyUtils.copyList(tagList, TagVO.class);
        // 遍历全部标签，设置每个标签对应的文章数
        for (TagVO tagVO : tagVOList) {
            tagVO.setArticleList(this.baseMapper.getArticleListByTagId(tagVO.getId()));
        }
        return tagVOList;
    }

}
