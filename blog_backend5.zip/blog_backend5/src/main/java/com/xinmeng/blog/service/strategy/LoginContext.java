package com.xinmeng.blog.service.strategy;

import cn.hutool.json.JSONObject;
import com.xinmeng.blog.service.strategy.impl.EmailLogin;
import com.xinmeng.blog.service.strategy.impl.PasswordLogin;
import com.xinmeng.blog.service.strategy.impl.TextLogin;
import com.xinmeng.vo.Result;
import lombok.Data;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import static com.xinmeng.constant.LoginTypeConstant.*;

/**
 *  环境类（上下文）
 */
@Data
@Component
public class LoginContext {

    private LoginStrategy strategy = null;

    @Resource
    private PasswordLogin passwordLogin;

    @Resource
    private EmailLogin emailLogin;

    @Resource
    private TextLogin textLogin;

    public LoginContext(){}





    public void LoginContext(String loginType, JSONObject json){
        switch (loginType){
            case PASSWORD_LOGIN:
                this.getPasswordLogin().setAccount(json.getStr("username"));
                this.getPasswordLogin().setPassword(json.getStr("password"));
                strategy = this.getPasswordLogin();
                break;
            case EMAIL_LOGIN:
                this.getEmailLogin().setEmail(json.getStr("mail"));
                this.getEmailLogin().setCode(json.getStr("code"));
                strategy = this.getEmailLogin();
                break;
            case TEXT_LOGIN:
                this.getTextLogin().setTel(json.getStr("tel"));
                this.getTextLogin().setCode(json.getStr("code"));
                strategy = this.getTextLogin();
                break;
        }
    }

    public Result<?> getResult(HttpServletRequest request){
        return strategy.login(request);
    }

}
