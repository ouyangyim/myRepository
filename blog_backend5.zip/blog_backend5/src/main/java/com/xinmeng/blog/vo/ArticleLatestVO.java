package com.xinmeng.blog.vo;

import lombok.Data;

@Data
public class ArticleLatestVO {

    private Integer id;

    private String articleName;

    private String createTime;

}
