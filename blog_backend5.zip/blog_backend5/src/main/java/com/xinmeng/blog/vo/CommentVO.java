package com.xinmeng.blog.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentVO {

    /**
     * 评论id
     */
    private Integer id;


    /**
     * 评论用户id
     */
    private Integer userId;


    /**
     * 评论用户名
     */
    private String username;


    /**
     * 评论用户头像
     */
    private String userAvatar;


    /**
     * 评论内容
     */
    private String content;


    /**
     *  评论时间
     */
    private String commentTime;
    private String commentTime1;


}
