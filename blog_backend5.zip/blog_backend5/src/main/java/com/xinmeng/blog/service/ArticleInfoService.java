package com.xinmeng.blog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.admin.dto.ArticleDTO;
import com.xinmeng.blog.dto.ArticleInfoDTO;
import com.xinmeng.blog.vo.*;
import com.xinmeng.entity.Article;
import com.xinmeng.entity.User;
import com.xinmeng.vo.PageVO;

import java.util.List;
import java.util.Map;

public interface ArticleInfoService  extends IService<Article> {
    List<ArticleInfoDTO> getArticleInfo();

    List<ArticleLatestVO> getLatestArticles();

    PageVO<ArchiveVO> getAllArchive(Integer pageSize, Integer currentPage);

    List<SearchResultVO> selectKeywords(String keywords);

    ArticleListVO getArticleByCondition(Integer tagId, Integer categoryId);

    ArticleDetailVO getArticleDetail(Integer id);
}
