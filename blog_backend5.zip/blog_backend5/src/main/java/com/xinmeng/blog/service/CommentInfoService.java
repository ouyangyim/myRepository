package com.xinmeng.blog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.blog.dto.CommentDTO;
import com.xinmeng.blog.vo.CommentVO;
import com.xinmeng.entity.Comment;

import java.util.List;


public interface CommentInfoService extends IService<Comment> {
    List<CommentVO> getAllComment(Integer articleId);

    String sendComment( CommentDTO commentDTO);
}
