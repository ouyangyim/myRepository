package com.xinmeng.blog.controller;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.DesensitizedUtil;
import cn.hutool.core.util.StrUtil;
import com.xinmeng.admin.dto.PasswordChangeDTO;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.admin.service.IUserService;
import com.xinmeng.annotation.ParameterValidation;
import com.xinmeng.blog.dto.*;
import com.xinmeng.blog.service.UserInfoService;
import com.xinmeng.dto.AuthenDTO;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

import static com.xinmeng.constant.RegexConstant.*;
import static com.xinmeng.constant.ResultConstant.*;
import static com.xinmeng.enums.ResultEnum.PASSWORD_IS_NULL;

@Api(tags = "前台用户接口")
@RestController
@RequestMapping("/api")
public class UserInfoController {

    @Autowired
    private UserInfoService userService;

    @Autowired
    private IUserService iUserService;

    @Autowired
    private CommonUtils commonUtils;

    @Autowired
    private ExceptionUtils exceptionUtils;


    @ApiOperation("注册用户")
    @PostMapping("/register")
    @ParameterValidation(format = {PASSWORDREGEX})
    public Result<?> registerUser(@RequestBody RegisterAndForgetDTO registerDTO, HttpServletRequest request){
        return userService.registerUser(registerDTO, request);
    }


    @ApiOperation("账号登录")
    @PostMapping("/accountLogin")
    public Result<?> accountLogin(@RequestBody AccountLoginDTO accountLoginDTO, HttpServletRequest request){
        return userService.accountLogin(accountLoginDTO, request);
    }


    @ApiOperation("邮箱登录")
    @PostMapping("/emailLogin")
    public Result<?> emailLogin(@RequestBody EmailLoginDTO emailLoginDTO, HttpServletRequest request){
        return userService.emailLogin(emailLoginDTO, request);
    }


    @ApiOperation("短信登录")
    @PostMapping("/textLogin")
    public Result<?> textLogin(@RequestBody TelLoginDTO telLoginDTO, HttpServletRequest request){
        return userService.textLogin(telLoginDTO, request);
    }



    @ApiOperation("注销用户-退出登录")
    @PostMapping("/logout")
    public Result<?> logout(@RequestParam Integer userId){
        userService.logout(userId);
        return Result.ok(LOGOUT_SUCCESS);
    }


    @ApiOperation("忘记密码 - 修改密码")
    @PutMapping("/forget")
    @ParameterValidation(format = {PASSWORDREGEX})
    public Result<?> forget(@RequestBody RegisterAndForgetDTO forgetDTO){
        String message = userService.forget(forgetDTO);
        return Result.ok(message);
    }

    @ApiOperation("修改头像")
    @PutMapping("/avatar")
    public Result<?> updateAvatar(@RequestParam String avatar, @RequestParam Integer userId){
        userService.updateAvatar(avatar, userId);
        return Result.ok(UPDATE_AVATAR_SUCCESS);
    }


    @ApiOperation("修改用户信息")
    @PutMapping("/userInfo")
    public Result<?> updateUser(@RequestBody UserDTO userDTO){
        String message = userService.updateUser(userDTO);
        return Result.ok(message);
    }


    @ApiOperation("根据id得到用户信息(根据 flag看是否脱敏)")
    @GetMapping("/userInfo/{userId}")
    public Result<?> getUser(@PathVariable Integer userId, @RequestParam boolean flag){
        User user = userService.getById(userId);
        UserDTO userDTO = Convert.convert(UserDTO.class, user);
        if (flag){
            // 手机号码、邮箱进行脱敏处理
            userDTO.setTel(DesensitizedUtil.mobilePhone(userDTO.getTel()));
            userDTO.setMail(DesensitizedUtil.email(userDTO.getMail()));
        }
        return Result.ok(userDTO);
    }


    @ApiOperation("修改密码")
    @PutMapping("/password/{userId}")
    public Result<?> updatePassword(@RequestBody PasswordChangeDTO passwordChangeDTO, @PathVariable Integer userId){
        User user = userService.getById(userId);
        String message = iUserService.updatePassword(user, passwordChangeDTO);
        return Result.ok(message);
    }


    @ApiOperation("设置密码前进行邮箱验证")
    @PostMapping("/validateMail")
    public Result<?> validateMailCode(@RequestBody VerificationDTO verificationForm){
        // 验证验证码是否正确
        exceptionUtils.exceptionDeal(!verificationForm.getCode().equals(commonUtils.getCode(verificationForm.getAccount())), ResultEnum.VERIFICATION_CODE_ERROR);
        return Result.ok(VERIFICATION_CODE_RIGHT);
    }


    @ApiOperation("设置密码")
    @PutMapping("/setPassword/{userId}")
    public Result<?> setPassword(@RequestBody PasswordDTO setPasswordForm, @PathVariable Integer userId){
        String message = userService.setPassword(setPasswordForm, userId);
        return Result.ok(message);
    }

    @ApiOperation(value = "根据用户id用户身份验证")
    @PostMapping("/authen/{userId}")
    public Result<?> haveAuthenticated(@RequestBody AuthenDTO authenDTO, @PathVariable Integer userId) {
        exceptionUtils.exceptionDeal(StrUtil.hasBlank(authenDTO.getPassword()), PASSWORD_IS_NULL);
        return userService.haveAuthenticated(authenDTO, userId);
    }


}
