package com.xinmeng.blog.dto;

import com.xinmeng.dto.ParameterDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegisterAndForgetDTO extends ParameterDTO {

    /**
     * 账号
     */
    private String username;

    /**
     * 验证码
     */
    private String code;


    /**
     * 密码
     */
    private String password;


    /**
     * 确认密码
     */
    private String confirmPassword;

    /**
     * 图片验证码
     */
    private String imgCode;

}
