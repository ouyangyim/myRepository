package com.xinmeng.blog.service.chainOfResponsibility;

import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;

import static com.xinmeng.constant.ResultConstant.DIFFERENT_PASSWORD_ERROR;
import static com.xinmeng.constant.ResultConstant.RESET_PASSWORD_SUCCESS;

/**
 *  判断两次密码是否相同
 */
public class JudgeIfSamePassword extends Handler{

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Override
    public String execute(User user, RegisterAndForgetDTO forgetDTO) {
        exceptionUtils.exceptionDeal(!forgetDTO.getPassword().equals(forgetDTO.getConfirmPassword()), ResultEnum.DIFFERENT_PASSWORD_ERROR);
        // 两次输入相同, 修改密码
        user.setPassword(passwordEncoder.encode(forgetDTO.getPassword()));
        userMapper.updateById(user);
        return RESET_PASSWORD_SUCCESS;
    }

}
