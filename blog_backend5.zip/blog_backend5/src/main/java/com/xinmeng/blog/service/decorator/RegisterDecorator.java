package com.xinmeng.blog.service.decorator;

import cn.hutool.core.util.ObjUtil;
import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.vo.Result;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

/**
 *  判断用户是否存在 装饰类
 */
@Component
public class RegisterDecorator extends RegisterComponent{

    private RegisterComponent component;

    public void judgeUserIfExistDecorator(RegisterComponent component){
        this.component = component;
    }

    /**
     *  重写要装饰的方法
     * @param registerAndForgetDTO
     * @param request
     * @return
     */
    @Override
    public Result<?> registerUser(RegisterAndForgetDTO registerAndForgetDTO, HttpServletRequest request) {
        Result<?> result = null;
        if(!ObjUtil.isNull(component)){
            result = component.registerUser(registerAndForgetDTO, request);
        }
        return result;
    }


}
