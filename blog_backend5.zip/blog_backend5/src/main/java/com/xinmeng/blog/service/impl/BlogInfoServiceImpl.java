package com.xinmeng.blog.service.impl;

import com.xinmeng.admin.mapper.ArticleMapper;
import com.xinmeng.admin.mapper.CategoryMapper;
import com.xinmeng.admin.mapper.TagMapper;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.blog.service.BlogInfoService;
import com.xinmeng.blog.vo.BlogInfoVO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import static com.xinmeng.constant.BlogInfoConstant.*;

@Service
public class BlogInfoServiceImpl implements BlogInfoService {

    @Resource
    private ArticleMapper articleMapper;
    @Resource
    private UserMapper userMapper;
    @Resource
    private CategoryMapper categoryMapper;
    @Resource
    private TagMapper tagMapper;

    /**
     * 得到博客网站信息
     * @return
     */
    @Override
    public BlogInfoVO getBlogInfo() {
        BlogInfoVO blogInfoVO = new BlogInfoVO();
        // 网站头像
        blogInfoVO.setAvatar(AVATAR);
        // 网站作者
        blogInfoVO.setAuthor(AUTHOR);
        // 网站名称
        blogInfoVO.setBlogName(BLOG_NAME);
        // 网站介绍
        blogInfoVO.setIntroduction(INTRODUCTION);
        // 网站文章总数
        blogInfoVO.setArticleCount(articleMapper.selectCount(null));
        // 网站用户总数
        blogInfoVO.setUserCount(userMapper.selectCount(null));
        // 网站标签总数
        blogInfoVO.setTagCount(tagMapper.selectCount(null));
        // 网站分类总数
        blogInfoVO.setCategoryCount(categoryMapper.selectCount(null));
        return blogInfoVO;
    }

}
