package com.xinmeng.blog.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.admin.mapper.MessageMapper;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.annotation.AccessLimit;
import com.xinmeng.blog.dto.MessageDTO;
import com.xinmeng.blog.service.MessageInfoService;
import com.xinmeng.blog.vo.MessageVO;
import com.xinmeng.entity.Message;
import com.xinmeng.entity.User;
import com.xinmeng.util.BeanCopyUtils;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import static com.xinmeng.constant.ResultConstant.MESSAGE_SUCCESS;
import static com.xinmeng.enums.ResultEnum.COMMENT_EXIST_SENSITIVE_WORD;
import static com.xinmeng.enums.ResultEnum.MESSAGE_EXIST_SENSITIVE_WORD;

@Service
public class MessageInfoServiceImpl  extends ServiceImpl<MessageMapper, Message> implements MessageInfoService {


    @Resource
    private UserMapper userMapper;

    @Autowired
    private CommonUtils commonUtils;

    @Autowired
    private ExceptionUtils exceptionUtils;


    /**
     * 发送评论
     * @param messageDTO
     * @return
     */
    @Override
    public String sendMessage(MessageDTO messageDTO) {
        Message message = Convert.convert(Message.class, messageDTO);
        message.setMessageTime(DateUtil.now());
        // 敏感词检查
        exceptionUtils.exceptionDeal(commonUtils.sensitiveWordCheck(message.getContent()), MESSAGE_EXIST_SENSITIVE_WORD);
        // 插入评论表
        this.baseMapper.insert(message);
        return MESSAGE_SUCCESS;
    }


    /**
     * 获取全部留言
     * @return
     */
    @Override
    public List<MessageVO> getAllMessage() {
        List<Message> messageList = this.baseMapper.selectList(null);
        List<MessageVO> messageDTOList = BeanCopyUtils.copyList(messageList, MessageVO.class);  // 留言内容, 用户id
        for (MessageVO messageVO : messageDTOList) {
            User user = userMapper.selectById(messageVO.getUserId());
            messageVO.setAvatar(user.getAvatar());
            messageVO.setUsername(user.getUsername());
        }
        return messageDTOList;
    }


}
