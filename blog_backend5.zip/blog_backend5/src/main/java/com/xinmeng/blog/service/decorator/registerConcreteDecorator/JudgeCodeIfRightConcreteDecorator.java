package com.xinmeng.blog.service.decorator.registerConcreteDecorator;

import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.blog.service.decorator.RegisterComponent;
import com.xinmeng.blog.service.decorator.RegisterDecorator;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import static com.xinmeng.constant.ResultConstant.VERIFICATION_CODE_ERROR;


/**
 *  注册逻辑中的 具体实现装饰类 （判断验证码是否正确）
 */
@Component
public class JudgeCodeIfRightConcreteDecorator extends RegisterDecorator {

    @Resource
    private CommonUtils commonUtils;

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Override
    public void judgeUserIfExistDecorator(RegisterComponent component) {
        super.judgeUserIfExistDecorator(component);
    }

    @Override
    public Result<?> registerUser(RegisterAndForgetDTO registerAndForgetDTO, HttpServletRequest request) {
        String code = registerAndForgetDTO.getCode();  // 得到用户输入的验证码
        String cacheCode = commonUtils.getCode(registerAndForgetDTO.getUsername());  // 得到缓存中的验证码
        exceptionUtils.exceptionDeal(!code.equals(cacheCode), ResultEnum.VERIFICATION_CODE_ERROR);
        return super.registerUser(registerAndForgetDTO, request);
    }

}
