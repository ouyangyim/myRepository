package com.xinmeng.blog.service;

import cn.hutool.captcha.LineCaptcha;


public interface CodeService {

    String sendCode(String email) throws Exception;

    String sendTextCode(String tel) throws Exception;

    LineCaptcha generateImgCode(String ipAddress);

}
