package com.xinmeng.blog.service.decorator.registerConcreteDecorator;

import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.blog.service.decorator.RegisterComponent;
import com.xinmeng.blog.service.decorator.RegisterDecorator;
import com.xinmeng.entity.User;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import static com.xinmeng.constant.RegexConstant.EMAILREGEX;
import static com.xinmeng.constant.ResultConstant.ACCOUNT_EXIT;


/**
 *  注册逻辑中的 具体实现装饰类 （判断用户是否存在）
 */
@Component
public class JudgeUserIfExistConcreteDecorator extends RegisterDecorator {

    @Resource
    private UserMapper userMapper;

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Override
    public void judgeUserIfExistDecorator(RegisterComponent component) {
        super.judgeUserIfExistDecorator(component);
    }

    @Override
    public Result<?> registerUser(RegisterAndForgetDTO registerAndForgetDTO, HttpServletRequest request) {
        User user = new User();
        // 验证 账号是否已经注册
        String account = registerAndForgetDTO.getUsername();
        if(account.matches(EMAILREGEX)){
            user = userMapper.checkUserByEmail(account);
        }else{
            user = userMapper.checkUserByTel(account);
        }
        exceptionUtils.exceptionDeal(user!=null, ResultEnum.ACCOUNT_EXIT);
        return super.registerUser(registerAndForgetDTO, request);
    }

}
