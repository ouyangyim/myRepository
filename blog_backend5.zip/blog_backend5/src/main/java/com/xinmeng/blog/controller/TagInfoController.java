package com.xinmeng.blog.controller;

import com.xinmeng.admin.vo.TagVO;
import com.xinmeng.blog.service.TagInfoService;
import com.xinmeng.entity.Tag;
import com.xinmeng.vo.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(tags = "前台标签接口")
@RestController
@RequestMapping("/api")
public class TagInfoController {

    @Autowired
    private TagInfoService tagInfoService;


    @ApiOperation("热门标签")
    @GetMapping("/topTags")
    public Result<?> getTopTags(){
        List<Tag> tagList = tagInfoService.getTopTags();
        return Result.ok(tagList);
    }

    @ApiOperation("全部标签")
    @GetMapping("/allTags")
    public Result<?> getAllTags(){
        List<TagVO> tagVOList = tagInfoService.getAllTags();
        return Result.ok(tagVOList);
    }



}
