package com.xinmeng.blog.service;

import com.xinmeng.blog.vo.BlogInfoVO;

public interface BlogInfoService {

    BlogInfoVO getBlogInfo();
}
