package com.xinmeng.blog.service.decorator.registerConcreteDecorator;

import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.blog.service.decorator.RegisterComponent;
import com.xinmeng.blog.service.decorator.RegisterDecorator;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;



/**
 *  注册逻辑中的 具体实现装饰类 （判断两次输入密码是否相同）
 */
@Component
public class JudgeIfSamePasswordConcreteDecorator extends RegisterDecorator {

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Override
    public void judgeUserIfExistDecorator(RegisterComponent component) {
        super.judgeUserIfExistDecorator(component);
    }

    @Override
    public Result<?> registerUser(RegisterAndForgetDTO registerAndForgetDTO, HttpServletRequest request) {
        exceptionUtils.exceptionDeal(!registerAndForgetDTO.getPassword().equals(registerAndForgetDTO.getConfirmPassword()), ResultEnum.DIFFERENT_PASSWORD_ERROR);
        return super.registerUser(registerAndForgetDTO, request);
    }
}
