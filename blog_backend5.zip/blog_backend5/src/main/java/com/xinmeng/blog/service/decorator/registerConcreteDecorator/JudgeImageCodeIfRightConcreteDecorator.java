package com.xinmeng.blog.service.decorator.registerConcreteDecorator;

import cn.hutool.captcha.LineCaptcha;
import com.xinmeng.blog.dto.RegisterAndForgetDTO;
import com.xinmeng.blog.service.decorator.RegisterComponent;
import com.xinmeng.blog.service.decorator.RegisterDecorator;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.vo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

import java.util.Locale;

import static com.xinmeng.enums.ResultEnum.IMAGE_CODE_ERROR;


/**
 *   验证图形验证码是否正确 装饰器
 */
@Slf4j
 @Component
public class JudgeImageCodeIfRightConcreteDecorator extends RegisterDecorator {

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Autowired
    private CommonUtils commonUtils;

    @Override
    public void judgeUserIfExistDecorator(RegisterComponent component) {
        super.judgeUserIfExistDecorator(component);
    }


    /**
     *  从缓存中得到的数据不是页面图片上的数据
     * @param registerAndForgetDTO
     * @param request
     * @return
     */
    @Override
    public Result<?> registerUser(RegisterAndForgetDTO registerAndForgetDTO, HttpServletRequest request) {
        LineCaptcha lineCaptcha = commonUtils.getImgCode(request.getRemoteAddr());
        String imgCode = lineCaptcha.getCode().toUpperCase();
        exceptionUtils.exceptionDeal(!imgCode.equals(registerAndForgetDTO.getImgCode().toUpperCase()), IMAGE_CODE_ERROR);    // 忽略大小写比较
        return super.registerUser(registerAndForgetDTO, request);
    }


}
