package com.xinmeng.blog.service.impl;

import cn.hutool.core.collection.BoundedPriorityQueue;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.ReUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.tokenizer.TokenizerEngine;
import cn.hutool.extra.tokenizer.TokenizerUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.admin.mapper.*;
import com.xinmeng.blog.dto.ArticleInfoDTO;
import com.xinmeng.blog.dto.TagDTO;
import com.xinmeng.blog.service.ArticleInfoService;
import com.xinmeng.blog.vo.*;
import com.xinmeng.entity.Article;
import com.xinmeng.entity.Category;
import com.xinmeng.entity.Tag;
import com.xinmeng.templateMethod.PageConcrete.PageArchiveConcrete;
import com.xinmeng.util.BeanCopyUtils;
import com.xinmeng.vo.PageVO;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

import static com.xinmeng.constant.ArticleConstant.*;
import static com.xinmeng.constant.CommonConstant.*;

@Service
@Import(PageArchiveConcrete.class)
public class ArticleInfoServiceImpl  extends ServiceImpl<ArticleMapper, Article> implements ArticleInfoService {

    @Resource
    private ArticleTagMapper articleTagMapper;

    @Resource
    private ArticleCategoryMapper articleCategoryMapper;

    @Resource
    private CategoryMapper categoryMapper;

    @Resource
    private TagMapper tagMapper;

    @Autowired
    private PageArchiveConcrete pageArchiveConcrete;


    /**
     * 文章封面
     * @return
     */
    @Override
    public List<ArticleInfoDTO> getArticleInfo() {
        // 得到文章信息
        LambdaQueryWrapper<Article> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Article::getStatus, SUBMIT);
        lqw.orderByDesc(Article::getIsTop);
        List<Article> articleList = this.baseMapper.selectList(lqw); // 缩略图、文章名、创建时间、是否置顶、内容、作者
        // 转为DTO
        List<ArticleInfoDTO> articleInfoDTOS = BeanCopyUtils.copyList(articleList, ArticleInfoDTO.class);
        for (ArticleInfoDTO articleInfoDTO : articleInfoDTOS) {
            List<Tag> tagList = articleTagMapper.getTagListByArticleId(articleInfoDTO.getId());
            Integer categoryId = articleCategoryMapper.getCategoryIdByArticleId(articleInfoDTO.getId());
            Category category = categoryMapper.selectById(categoryId);
            articleInfoDTO.setTagList(tagList);
            articleInfoDTO.setCategoryId(categoryId);
            articleInfoDTO.setCategoryName(category.getCategoryName());
        }
        return articleInfoDTOS;
    }


    /**
     * 最新文章
     * @return
     */
    @Override
    public List<ArticleLatestVO> getLatestArticles() {
        LambdaQueryWrapper<Article> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Article::getStatus, SUBMIT);
//        lqw.orderByDesc(Article::getCreateTime);
        List<Article> articleList = this.baseMapper.selectList(lqw);
        List<ArticleLatestVO> latestArticleList = BeanCopyUtils.copyList(articleList, ArticleLatestVO.class);
//        return ListUtil.sub(latestArticleList, 0, LATEST_ARTICLE);
        // 初始化队列，使用自定义的比较器
        BoundedPriorityQueue<ArticleLatestVO> queue = new BoundedPriorityQueue<>(LATEST_ARTICLE, (o1, o2) -> o2.getCreateTime().compareTo(o1.getCreateTime()));
        // 把数据放入队列
        for (ArticleLatestVO articleLatestVO : latestArticleList) {
            queue.offer(articleLatestVO);
        }
        // 队列转换为集合
        return queue.toList();
    }


    /**
     * 文章归档(分页查询) （模板方法模式）
     * @return
     */
    @Override
    public PageVO<ArchiveVO> getAllArchive(Integer pageSize, Integer currentPage) {

        return pageArchiveConcrete.pageTemplate(pageSize, currentPage);

    }


    /**
     * 根据关键字查询文章
     * @param keywords
     * @return
     */
    @Override
    public List<SearchResultVO> selectKeywords(String keywords) {
        // 判断用户是否输入
        if (StringUtils.isBlank(keywords)) {
            return new ArrayList<>();
        }
        // 关键字 是 标题或文章内容，文章已发布且未删除
        LambdaQueryWrapper<Article> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Article::getDeleted, NO_DELETED);  // 未删除
        lqw.eq(Article::getStatus, SUBMIT);       // 已发布
        lqw.and(wrapper -> wrapper
                .like(Article::getArticleName, keywords)   // 文章标题中有关键字
                .or()
                .like(Article::getContent, keywords));     // 文章内容中有关键字
        // 搜索
        List<Article> articleList = this.baseMapper.selectList(lqw);
        // 封装 VO
        List<SearchResultVO> articleVOList = BeanCopyUtils.copyList(articleList, SearchResultVO.class);
        // 关键字高亮
        for (SearchResultVO searchResultVO : articleVOList) {
            // 关键字第一次出现的索引位置
            String articleContent = searchResultVO.getContent();
            int index = articleContent.indexOf(keywords);
            if(index != -1){
                // 获取关键字前面的文字
                int preIndex = index > 25 ? index-25 : 0;  // 得到关键字前 小于25字处 的索引
                String preText = StrUtil.sub(articleContent,preIndex, index);
                // 获取关键字后的文字
                int last = index + keywords.length();  // 关键字最后一个字的索引
                int postLength = articleContent.length() - last;  // 关键字后面部分文章的长度
                int postIndex = postLength > 175 ? last + 175 : last + postLength;  // 得到关键字后面 小于175个字处 的索引
                String postText = StrUtil.sub(articleContent, index, postIndex);
                // 文章内容高亮 (把文章前后的字符串拼接，并替换其中的关键字为加上高亮的关键字)
//                articleContent = (preText + postText).replaceAll(keywords, PRE_TAG + keywords + POST_TAG);
                articleContent = ReUtil.replaceAll((preText+postText), keywords, PRE_TAG + keywords + POST_TAG);
                searchResultVO.setContent(articleContent);
            }
            // 文章标题高亮
//            String articleName = searchResultVO.getArticleName().replaceAll(keywords, PRE_TAG + keywords + POST_TAG);
            String articleName = ReUtil.replaceAll(searchResultVO.getArticleName(), keywords, PRE_TAG + keywords + POST_TAG);
            searchResultVO.setArticleName(articleName);
        }
        return articleVOList;
    }



    /**
     * 根据条件查询文章
     * @param tagId
     * @param categoryId
     * @return
     */
    @Override
    public ArticleListVO getArticleByCondition(Integer tagId, Integer categoryId) {
        List<Article> articleList = new ArrayList<>();
        String name = null;
        // 判断路径中是tagId还是categoryId
        // *** 可以根据 tagId 是否为空 来使用 状态模式, 但是感觉不太有必要 （只有两种状态）
        if(Objects.nonNull(tagId)){
            // tagId不为空，路径中是tagId
            // 根据标签id，得到标签名、文章信息
            Tag tag = tagMapper.selectById(tagId);
            name = tag.getTagName(); // 标签名
            articleList = tagMapper.getArticleListByTagId(tagId);
        }else{
            // tagId为空，路径中是categoryId
            // 根据分类id，得到文章信息、分类名
            Category category = categoryMapper.selectById(categoryId);
            name = category.getCategoryName(); // 分类名
            articleList = categoryMapper.getArticleListByCategoryId(categoryId);
        }

        List<ArticleVO> articleVOList = BeanCopyUtils.copyList(articleList, ArticleVO.class);
        // 得到文章对应的 分类名和分类id、标签集合、创建时间
        for (ArticleVO articleVO : articleVOList) {
            articleVO.setCategoryId(articleCategoryMapper.getCategoryIdByArticleId(articleVO.getId()));// 分类id
            articleVO.setCategoryName(categoryMapper.getCategoryNameByArticleId(articleVO.getId()));  // 分类名
            List<Tag> tagList = articleTagMapper.getTagListByArticleId(articleVO.getId());
            List<TagDTO> tagDTOList = BeanCopyUtils.copyList(tagList, TagDTO.class);
            articleVO.setTagDTOList(tagDTOList);  // 标签集合
            Integer spaceIndex = articleVO.getCreateTime().indexOf(' ');
            String createTime1 = articleVO.getCreateTime().substring(0, spaceIndex);
            articleVO.setCreateTime1(createTime1);
        }
        // 封装
        ArticleListVO articleListVO = new ArticleListVO();
        articleListVO.setArticleVOList(articleVOList);
        articleListVO.setName(name);
        return articleListVO;
    }



    /**
     * 获取文章详情
     * @param id
     * @return
     */
    @Override
    public ArticleDetailVO getArticleDetail(Integer id) {
        // 根据id得到文章对象
        Article article = this.baseMapper.selectById(id);
        // 转为VO对象
        // 文章id，文章名，文章内容，创建时间，更新时间，浏览量
        ArticleDetailVO articleVO = Convert.convert(ArticleDetailVO.class, article);
        // 发表时间整理
        String createTime1 = DateUtil.formatDate(DateUtil.parse(articleVO.getCreateTime()));
        articleVO.setCreateTime1(createTime1);
        // 更新时间整理
        if(!StrUtil.hasBlank(articleVO.getUpdateTime())){
            String updateTime1 = DateUtil.formatDate(DateUtil.parse(articleVO.getUpdateTime()));
            articleVO.setUpdateTime1(updateTime1);
        }else{
            articleVO.setUpdateTime1(null);
        }
        // 分类id
        articleVO.setCategoryId(articleCategoryMapper.getCategoryIdByArticleId(articleVO.getId()));
        // 分类名
        articleVO.setCategoryName(categoryMapper.getCategoryNameByArticleId(articleVO.getId()));
        // 标签集合
        List<Tag> tagList = articleTagMapper.getTagListByArticleId(articleVO.getId());
        List<TagDTO> tagDTOList = BeanCopyUtils.copyList(tagList, TagDTO.class);
        articleVO.setTagDTOList(tagDTOList);
        return articleVO;
    }


}
