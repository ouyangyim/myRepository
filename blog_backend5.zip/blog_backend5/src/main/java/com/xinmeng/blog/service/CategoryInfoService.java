package com.xinmeng.blog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.admin.vo.CategoryVO;
import com.xinmeng.entity.Category;

import java.util.List;

public interface CategoryInfoService extends IService<Category> {
    List<Category> getTopCategory();

    List<CategoryVO> getAllCategory();
}
