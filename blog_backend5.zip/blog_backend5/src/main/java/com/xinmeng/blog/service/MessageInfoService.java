package com.xinmeng.blog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.blog.dto.MessageDTO;
import com.xinmeng.blog.vo.MessageVO;
import com.xinmeng.entity.Message;

import java.util.List;

public interface MessageInfoService  extends IService<Message> {
    String sendMessage(MessageDTO messageDTO);

    List<MessageVO> getAllMessage();
}
