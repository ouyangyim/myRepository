package com.xinmeng.blog.service.interpreterPattern;



import java.util.HashMap;
import java.util.Map;

/**
 *  环境类（上下文，用于封装解释器之外的全局信息）
 */
public class Context {

    Map<Variable, Double> maps = new HashMap<>();


    /**
     *  增加
     */
    public void add(Variable var, Double value){
        maps.put(var, value);
    }


    /**
     *  获取
     */
    public Double getValue(Variable var){
        return maps.get(var);
    }


}
