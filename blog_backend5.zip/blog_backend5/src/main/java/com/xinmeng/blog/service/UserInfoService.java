package com.xinmeng.blog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xinmeng.admin.dto.UserDTO;
import com.xinmeng.blog.dto.*;
import com.xinmeng.dto.AuthenDTO;
import com.xinmeng.entity.User;
import com.xinmeng.vo.Result;

import javax.servlet.http.HttpServletRequest;

public interface UserInfoService extends IService<User> {
    Result<?> registerUser(RegisterAndForgetDTO registerAndForgetDTO, HttpServletRequest request);

    Result<?> accountLogin(AccountLoginDTO accountLoginDTO, HttpServletRequest request);

    void logout(Integer userId);

    Result<?> emailLogin(EmailLoginDTO emailLoginDTO, HttpServletRequest request);

    String forget(RegisterAndForgetDTO forgetDTO);

    void updateAvatar(String avatar, Integer userId);

    String updateUser(UserDTO userDTO);

    String setPassword(PasswordDTO passwordDTO, Integer userId);

    Result<?> textLogin(TelLoginDTO telLoginDTO, HttpServletRequest request);

    Result<?> haveAuthenticated(AuthenDTO authenDTO, Integer userId);
}
