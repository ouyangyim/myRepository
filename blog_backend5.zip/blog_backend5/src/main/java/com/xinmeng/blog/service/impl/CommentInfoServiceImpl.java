package com.xinmeng.blog.service.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.extra.expression.ExpressionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xinmeng.admin.mapper.ArticleMapper;
import com.xinmeng.admin.mapper.CommentMapper;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.blog.dto.CommentDTO;
import com.xinmeng.blog.service.CommentInfoService;
import com.xinmeng.blog.service.interpreterPattern.*;
import com.xinmeng.blog.vo.CommentVO;
import com.xinmeng.entity.Article;
import com.xinmeng.entity.Comment;
import com.xinmeng.entity.User;
import com.xinmeng.util.BeanCopyUtils;
import com.xinmeng.util.CommonUtils;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

import static com.xinmeng.constant.CommentConstant.APPROVED;
import static com.xinmeng.constant.CommonConstant.*;
import static com.xinmeng.constant.ResultConstant.COMMENT_SUCCESS;
import static com.xinmeng.constant.ResultConstant.SEND_SUCCESS;
import static com.xinmeng.enums.ResultEnum.COMMENT_EXIST_SENSITIVE_WORD;

@Service
public class CommentInfoServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentInfoService {

    @Resource
    private UserMapper userMapper;

    @Resource
    private ArticleMapper articleMapper;

    @Resource
    private CommentMapper commentMapper;

    @Autowired
    private CommonUtils commonUtils;

    @Autowired
    private ExceptionUtils exceptionUtils;


    /**
     * 得到全部评论
     * @return
     */
    @Override
    public List<CommentVO> getAllComment(Integer articleId) {
        LambdaQueryWrapper<Comment> lqw = new LambdaQueryWrapper<>();
        // 已审核通过
        lqw.eq(Comment::getStatus, APPROVED);
        // 对应文章
        Article article = articleMapper.selectById(articleId);
        lqw.eq(Comment::getArticleName, article.getArticleName());
        // 查询评论集合
        List<Comment> commentList = this.baseMapper.selectList(lqw);
        List<CommentVO> commentVOList = BeanCopyUtils.copyList(commentList, CommentVO.class);  // 得到评论id、评论内容、评论时间
        // 评论用户名、头像
        for (CommentVO commentVO : commentVOList) {
            User user = userMapper.selectById(commentVO.getUserId());
            commentVO.setUsername(user.getUsername());
            commentVO.setUserAvatar(user.getAvatar());
            Integer spaceIndex = commentVO.getCommentTime().indexOf(' ');
            String createTime1 = commentVO.getCommentTime().substring(0, spaceIndex);
            commentVO.setCommentTime1(createTime1);
        }
        return commentVOList;
    }


    /**
     * 发送评论
     * @param commentDTO
     * @return
     */
    @Override
    @Transactional
    public String sendComment( CommentDTO commentDTO){
        // 新增评论
        Comment comment = Convert.convert(Comment.class, commentDTO);
        Article article = articleMapper.selectById(commentDTO.getArticleId());
        comment.setArticleName(article.getArticleName());   // 评论文章名
        comment.setCommentTime(DateUtil.now());             // 评论时间
        // 敏感词查询
        exceptionUtils.exceptionDeal(commonUtils.sensitiveWordCheck(commentDTO.getContent()), COMMENT_EXIST_SENSITIVE_WORD);
        // 插入评论表
        this.baseMapper.insert(comment);
        // 修改文章得分
        Double rate = 0.0;
        if(article.getArticleRate() == 0){
            rate = commentDTO.getArticleRate();
        }else{
            // 解释器模式（数学表达式——简单文法）
//            Context context = new Context();
//            Variable currentRate = new Variable("currentRate");   // 当前得分
//            Variable r = null;
//            Variable preCount = null;
//            Variable currentCount = null;
//            try {
//                // 原型模式解决多个类创建问题
//                r = (Variable) currentRate.clone();
//                r.setVariableName("r");
//                preCount = (Variable) currentRate.clone();
//                preCount.setVariableName("preCount");
//                currentCount = (Variable) currentRate.clone();
//                currentCount.setVariableName("currentCount");
//            } catch (CloneNotSupportedException e) {
//                e.printStackTrace();
//            }
//            context.add(currentRate, article.getArticleRate());
//            context.add(r, commentDTO.getArticleRate());
//            context.add(preCount, commentMapper.getCount(commentDTO.getArticleId()) - 1);
//            context.add(currentCount, commentMapper.getCount(commentDTO.getArticleId()));
//            AbstractExpression expression = new Divide(new Plus(new Multiply(currentRate, preCount), r), currentCount);
//            rate = expression.interpret(context);
            // 表达式引擎封装
            final Dict dict = Dict.create()
                    .set("currentRate", article.getArticleRate())
                    .set("r", commentDTO.getArticleRate())
                    .set("preCount", commentMapper.getCount(commentDTO.getArticleId()) - 1)
                    .set("currentCount", commentMapper.getCount(commentDTO.getArticleId()));
            log.error(dict.toString());   // 输出正常
            rate = (Double) ExpressionUtil.eval("((currentRate * preCount) + r) / currentCount", dict);
        }
        article.setArticleRate(Double.valueOf(NumberUtil.decimalFormat(RATEFORMAT, rate)));
        articleMapper.updateById(article);
        return COMMENT_SUCCESS;
    }


}
