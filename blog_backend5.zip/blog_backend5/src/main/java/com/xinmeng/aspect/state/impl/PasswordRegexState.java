package com.xinmeng.aspect.state.impl;

import com.xinmeng.aspect.state.Context;
import com.xinmeng.aspect.state.FormatState;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.RegexConstant.PASSWORDREGEX;

/**
 *  密码格式状态类
 */
@Component
public class PasswordRegexState implements FormatState {

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Autowired
    private EmailRegexState emailRegexState;

    @Override
    public void handle(Context context) {
        if (context.getFormat().equals(PASSWORDREGEX)){
            if (context.getParameterDTO().getPassword() == null)return;
            exceptionUtils.exceptionDeal(!context.getParameterDTO().getPassword().matches(context.getFormat()), ResultEnum.PASSWORD_FORMAT_ERROR);
        }else{
            context.setFormatState(emailRegexState);
            context.request();
        }
    }

}
