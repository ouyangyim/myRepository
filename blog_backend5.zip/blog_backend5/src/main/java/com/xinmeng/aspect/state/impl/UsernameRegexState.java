package com.xinmeng.aspect.state.impl;

import com.xinmeng.aspect.state.Context;
import com.xinmeng.aspect.state.FormatState;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.RegexConstant.USERNAMEREGEX;

/**
 *  用户名格式状态类
 */
@Component
public class UsernameRegexState implements FormatState {

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Autowired
    private PasswordRegexState passwordRegexState;

    @Override
    public void handle(Context context) {
        if (context.getFormat().equals(USERNAMEREGEX)){
            if (context.getParameterDTO().getUsername() == null)return;
            exceptionUtils.exceptionDeal(!context.getParameterDTO().getUsername().matches(context.getFormat()), ResultEnum.USERNAME_FORMAT_ERROR);
        }else {
            context.setFormatState(passwordRegexState);
            context.request();
        }
    }

}
