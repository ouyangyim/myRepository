package com.xinmeng.aspect.state;


/**
 *  格式状态接口
 */
public interface FormatState {

    void handle(Context context);

}
