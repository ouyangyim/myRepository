package com.xinmeng.aspect.state.impl;

import com.xinmeng.aspect.state.Context;
import com.xinmeng.aspect.state.FormatState;
import com.xinmeng.enums.ResultEnum;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.RegexConstant.TELREGEX;

/**
 *  手机号码格式状态类
 */
@Component
public class TelRegexState implements FormatState {

    @Autowired
    private ExceptionUtils exceptionUtils;

    @Override
    public void handle(Context context) {
        if (context.getFormat().equals(TELREGEX)){
            if (context.getParameterDTO().getTel() == null) return;
            exceptionUtils.exceptionDeal(!context.getParameterDTO().getTel().matches(context.getFormat()), ResultEnum.TEL_FORMAT_ERROR);
        }
    }
}
