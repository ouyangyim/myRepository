package com.xinmeng.aspect;

import cn.hutool.core.annotation.AnnotationUtil;
import cn.hutool.core.convert.Convert;
import com.xinmeng.annotation.ParameterValidation;
import com.xinmeng.aspect.state.Context;
import com.xinmeng.aspect.state.impl.UsernameRegexState;
import com.xinmeng.dto.ParameterDTO;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;


/**
 *  参数格式校验切面
 */
@Aspect
@Component
@Slf4j
public class ParameterValidationAspect {

    @Autowired
    private Context context;

    @Autowired
    private UsernameRegexState usernameRegexState;

    /**
     *  定义切入点
     */
    @Pointcut("@annotation(com.xinmeng.annotation.ParameterValidation)")
    private void pt(){};



    /**
     *  定义通知
     */
    @Before("pt()")
    public void validate(JoinPoint jp){
        ParameterDTO parameterDTO = new ParameterDTO();
        // 获取切入点签名
        MethodSignature signature = (MethodSignature) jp.getSignature();
        // 获取切入点方法
        Method method = signature.getMethod();
        // ** 利用注解工具类AnnotationUtil获取切入点方法上的ParameterValidation注解的值
        ParameterValidation parameterValidation = AnnotationUtil.getAnnotation(method, ParameterValidation.class);
        String[] formats = parameterValidation.format();
        // 获取切入点方法的参数
        for (String format : formats) {
            Object[] args = jp.getArgs();
            for (Object arg : args) {
                if (arg instanceof ParameterDTO) parameterDTO = Convert.convert(ParameterDTO.class, arg);
                // 可以使用状态模式
                context.setParameterDTO(parameterDTO);
                context.setFormatState(usernameRegexState);
                context.setFormat(format);
                context.request();
            }
        }
    }


}
