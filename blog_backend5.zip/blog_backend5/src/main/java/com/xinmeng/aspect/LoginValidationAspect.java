package com.xinmeng.aspect;

import cn.hutool.core.convert.Convert;
import com.xinmeng.admin.mapper.UserMapper;
import com.xinmeng.dto.LoginValidationDTO;
import com.xinmeng.util.ExceptionUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.xinmeng.enums.ResultEnum.*;


/**
 *  是否登录校验切面
 */
@Aspect
@Component
public class LoginValidationAspect {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ExceptionUtils exceptionUtils;

    /**
     *  定义切入点
     */
    @Pointcut("@annotation(com.xinmeng.annotation.LoginValidation)")
    private void pt(){};

    /**
     *  定义通知方法
     */
    @Before("pt()")
    public void ifLogin(JoinPoint jp){
        // 获取切入点方法上的参数
        Object[] args = jp.getArgs();
        for (Object arg : args) {
            if (arg instanceof LoginValidationDTO){
                LoginValidationDTO loginValidationDTO = Convert.convert(LoginValidationDTO.class, arg);
                exceptionUtils.exceptionDeal(loginValidationDTO.getUserId()==null, PLEASE_LOGIN);
            }
        }
    }

}
