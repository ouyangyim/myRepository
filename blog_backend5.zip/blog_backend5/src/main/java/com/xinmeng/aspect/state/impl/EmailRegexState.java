package com.xinmeng.aspect.state.impl;

import cn.hutool.core.exceptions.ExceptionUtil;
import cn.hutool.core.exceptions.ValidateException;
import cn.hutool.core.lang.Validator;
import com.xinmeng.aspect.state.Context;
import com.xinmeng.aspect.state.FormatState;
import com.xinmeng.constant.ResultConstant;
import com.xinmeng.exception.MyException;
import com.xinmeng.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.xinmeng.constant.RegexConstant.EMAILREGEX;

/**
 *  邮箱格式状态类
 */
@Component
public class EmailRegexState implements FormatState {


    @Autowired
    private TelRegexState telRegexState;

    @Override
    public void handle(Context context) {
        if(context.getFormat().equals(EMAILREGEX)){
            if (context.getParameterDTO().getMail() == null) return;
//            exceptionUtils.exceptionDeal(!context.getParameterDTO().getMail().matches(context.getFormat()), EMAIL_FORMAT_ERROR);
            try {
                Validator.validateEmail(context.getParameterDTO().getMail(), ResultConstant.EMAIL_FORMAT_ERROR);
            } catch (ValidateException e) {
                throw ExceptionUtil.wrap(e, MyException.class);
            }
        }else{
            context.setFormatState(telRegexState);
            context.request();
        }
    }

}
