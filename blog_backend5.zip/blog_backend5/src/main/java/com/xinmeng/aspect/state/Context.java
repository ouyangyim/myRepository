package com.xinmeng.aspect.state;

import com.xinmeng.dto.ParameterDTO;
import lombok.Data;
import org.springframework.stereotype.Component;

/**
 *  维护一个ConcreteState子类的实例，这个实例定义当前的状态。
 */
@Data
@Component
public class Context {


    private ParameterDTO parameterDTO;

    private FormatState formatState;

    private String format;

    public void request(){
        formatState.handle(this);
    }

}
