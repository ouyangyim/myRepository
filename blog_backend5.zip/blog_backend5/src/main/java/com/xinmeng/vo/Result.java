package com.xinmeng.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import static com.xinmeng.enums.ResultEnum.FAIL;
import static com.xinmeng.enums.ResultEnum.SUCCESS;

/**
 * 公共响应类
 * @param <T>
 */

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class Result<T> {

    /**
     * 状态码
     */
    private Integer code;


    /**
     * 返回信息
     */
    private String message;


    /**
     * 返回数据
     */
    private T data;


    public static <T> Result<T> ok(){
        return new Result<T>(SUCCESS.getCode(), SUCCESS.getMessage(), null);
    }

    public static <T> Result<T> ok(Integer code, String message){
        return new Result<T>(code, message, null);
    }

    public static <T> Result<T> ok(T data){
        return new Result<T>(SUCCESS.getCode(), SUCCESS.getMessage(), data);
    }

    public static <T> Result<T> ok(T data, String message){
        return new Result<T>(SUCCESS.getCode(), message, data);
    }

    public static <T> Result<T> ok(String message){
        return new Result<T>(SUCCESS.getCode(), message, null);
    }

    public static <T> Result<T> ok(Integer code, String message, T data){
        return new Result<T>(code, message, data);
    }

    public static <T> Result<T> fail(){
        return new Result<T>(FAIL.getCode(), FAIL.getMessage(), null);
    }

    public static <T> Result<T> fail(String message){
        return new Result<T>(FAIL.getCode(), message, null);
    }

    public static <T> Result<T> fail(T data){
        return new Result<T>(FAIL.getCode(), FAIL.getMessage(), data);
    }

    public static <T> Result<T> fail(String message, T data){
        return new Result<T>(FAIL.getCode(), message, data);
    }

    public static <T> Result<T> fail(Integer code, String message){
        return new Result<T>(code, message, null);
    }

    public static <T> Result<T> fail(Integer code, String message, T data){
        return new Result<T>(code, message, data);
    }

}
