package com.xinmeng.pubick.service.impl;

import cn.hutool.core.io.FileTypeUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.net.url.UrlBuilder;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.OSSException;
import com.xinmeng.pubick.service.UploadService;
import com.xinmeng.util.ExceptionUtils;
import com.xinmeng.util.PathUtils;
import darabonba.core.exception.ClientException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import static com.xinmeng.constant.CommonConstant.*;
import static com.xinmeng.enums.ResultEnum.FAIL_TYPE_ERROR;

@Data
@Service
@Slf4j
//@ConfigurationProperties(prefix = "oss")
@ConfigurationProperties(prefix = "alioss")
public class UploadServiceImpl implements UploadService {

    // 七牛云
    private String accessKey;
    private String secretKey;
    private String bucket;

    // 阿里云
    private String endpoint;
    private String accessKeyId;
    private String accessKeySecret;
    private String bucketName;

    @Autowired
    private ExceptionUtils exceptionUtils;


    @Override
    public String uploadImg(MultipartFile img) {
        // 判断文件类型
        // 获取原始文件名
        String originalFilename = img.getOriginalFilename();
        File file = FileUtil.file(originalFilename);  // 此处创建了一个空文件对象
        try {
            img.transferTo(file);                     // 把img的文件内容保存到file对象中
            String type = FileTypeUtil.getType(file);
            exceptionUtils.exceptionDeal(!IMG_POST.equals(type), FAIL_TYPE_ERROR);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 对原始文件名判断 - 通过判断扩展名 来判断 文件类型
//        exceptionUtils.exceptionDeal(!FileNameUtil.extName(file).equals(IMG_POST), FAIL_TYPE_ERROR);

        // 判断通过，上传文件到OSS
        String filePath = PathUtils.generateFilePath(originalFilename);
        String url = null;  // 2023/8/10/vue.png
        try {
//            url = uploadOSS(img, filePath);                   // 七牛云
//            url = uploadOSS(filePath, img.getInputStream());  // 阿里云
            url = uploadOSS(filePath, FileUtil.getInputStream(file));  // 阿里云
        } catch (Exception e) {
            e.printStackTrace();
        }
        return url;
    }


    /**
     *  阿里云对象存储
     * @param filePath
     * @param inputStream
     * @return
     */
    public String uploadOSS(String filePath, InputStream inputStream){
        // 创建OSSClient实例
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
        try {
            // 创建OSSClient请求
            ossClient.putObject(bucketName, filePath, inputStream);
        } catch (OSSException oe) {
            System.out.println("Caught an OSSException, which means your request made it to OSS, "
                    + "but was rejected with an error response for some reason.");
            System.out.println("Error Message:" + oe.getErrorMessage());
            System.out.println("Error Code:" + oe.getErrorCode());
            System.out.println("Request ID:" + oe.getRequestId());
            System.out.println("Host ID:" + oe.getHostId());
        } catch (ClientException ce) {
            System.out.println("Caught an ClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with OSS, "
                    + "such as not being able to access the network.");
            System.out.println("Error Message:" + ce.getMessage());
        } finally {
            if (ossClient != null) {
                ossClient.shutdown();
            }
        }

        return UrlBuilder.create()
                .setScheme("https")
                .setHost(bucketName+"."+endpoint)
                .addPath(filePath)
                .build();

//        String template = "https://{}.{}/{}";
//        return StrUtil.format(template, bucketName, endpoint, filePath);

//        return "https://" + bucketName + "." + endpoint + "/" + filePath ;
    }




//    /**
//     *  七牛云对象存储
//     * @param imgFile
//     * @param filePath
//     * @return
//     */
//    public String uploadOSS(MultipartFile imgFile, String filePath){
//        //构造一个带指定 Region 对象的配置类   // 根据机房选择Region对象
//        Configuration cfg = new Configuration(Region.autoRegion());
//        //...其他参数参考类注释
//        UploadManager uploadManager = new UploadManager(cfg);
//        //...生成上传凭证，然后准备上传
//        //默认不指定key的情况下，以文件内容的hash值作为文件名
//        String key = filePath;  // 文件名(文件路径)
//        try {
//            // 要上传的数据
//            InputStream inputStream = imgFile.getInputStream();
//            Auth auth = Auth.create(accessKey, secretKey);
//            String upToken = auth.uploadToken(bucket);
//            try {
//                Response response = uploadManager.put(inputStream,key,upToken,null, null);
//                //解析上传成功的结果
//                DefaultPutRet putRet = new Gson().fromJson(response.bodyString(), DefaultPutRet.class);
//                System.out.println(putRet.key);  // 文件名
//                System.out.println(putRet.hash);
//                return DomainName + key;
//            } catch (QiniuException ex) {
//                Response r = ex.response;
//                System.err.println(r.toString());
//                try {
//                    System.err.println(r.bodyString());
//                } catch (QiniuException ex2) {
//                    //ignore
//                    ex2.printStackTrace();
//                }
//            }
//        } catch (Exception ex) {
//            //ignore
//            ex.printStackTrace();
//        }
//        return UPLOAD_ERROR;
//    }

}
