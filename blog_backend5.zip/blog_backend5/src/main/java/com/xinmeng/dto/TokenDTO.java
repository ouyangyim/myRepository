package com.xinmeng.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *  Token对象
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenDTO {

    private String token;

}
