package com.xinmeng.dto;

import lombok.Data;
import org.springframework.stereotype.Component;

/**
 *  用户信息参数对象
 */
@Data
@Component
public class ParameterDTO {

    private String username;

    private String password;

    private String mail;

    private String tel;

}
