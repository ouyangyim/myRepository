package com.xinmeng.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 *  用户身份校验
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthenDTO {

    private String password;

}
