package com.xinmeng.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginValidationDTO {

    /**
     * 评论用户id
     */
    private Integer userId;

    /**
     * 评论文章id
     */
    private Integer articleId;


    /**
     * 评论内容
     */
    private String content;


    /**
     * 文章得分
     */
    private Double articleRate;

}
