package com.xinmeng.dto;


import com.xinmeng.admin.dto.MenuDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 *  通过Token得到的用户信息
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InfoByTokenDTO {

    private String name;

    private String avatar;

    private List<String> role;

    private List<MenuDTO> menuList;

}
