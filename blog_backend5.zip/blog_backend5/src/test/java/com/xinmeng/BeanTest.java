package com.xinmeng;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class BeanTest {

    @Autowired
    private BeanPrinter beanPrinter;

    @Test
    public void beanTest() {
        beanPrinter.printAllBeans();
    }


}
