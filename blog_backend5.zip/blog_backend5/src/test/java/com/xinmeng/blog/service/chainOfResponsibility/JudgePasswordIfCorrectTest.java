package com.xinmeng.blog.service.chainOfResponsibility;

import static org.junit.jupiter.api.Assertions.*;

class JudgePasswordIfCorrectTest {

}