package com.xinmeng;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

 @Component
public class BeanPrinter {

    private static ApplicationContext applicationContext;

    @Autowired
    public void setApplicationContext(ApplicationContext context) {
        this.applicationContext = context;
    }

    public static void printAllBeans() {
        String[] beanNames = applicationContext.getBeanDefinitionNames();
        for (String beanName : beanNames) {
            System.out.println("Bean: " + beanName);
        }
        System.out.println("==============================");
        System.out.println(applicationContext.getBean("userMapper"));
        System.out.println(applicationContext.getBean("passwordEncoder"));
    }

}
