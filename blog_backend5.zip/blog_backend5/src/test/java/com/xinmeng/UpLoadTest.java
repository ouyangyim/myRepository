package com.xinmeng;

import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import java.io.FileInputStream;
import java.io.InputStream;

/**
 * 上传功能测试 七牛云OSS
 */
// @EnableConfigurationProperties(UpLoadTest.class)
// @SpringBootTest
// @ConfigurationProperties(prefix = "oss")
public class UpLoadTest {

    private String accessKey;
    private String secretKey;
    private String bucket;

    public void setAccessKey(String accessKey) {this.accessKey = accessKey;}
    public void setSecretKey(String secretKey) {this.secretKey = secretKey;}
    public void setBucket(String bucket) {this.bucket = bucket;}

//    @Test
//    public void OSSTest(){
//        //构造一个带指定 Region 对象的配置类   // 根据机房选择Region对象
//        Configuration cfg = new Configuration(Region.autoRegion());
//        //...其他参数参考类注释
//        UploadManager uploadManager = new UploadManager(cfg);
//        //...生成上传凭证，然后准备上传
//        //默认不指定key的情况下，以文件内容的hash值作为文件名
//        String key = "blog_pic.png";  // 文件名(文件路径)
//        try {
//            // 要上传的数据
//            InputStream inputStream = new FileInputStream("D:\\headimg.jpg");
//            Auth auth = Auth.create(accessKey, secretKey);
//            String upToken = auth.uploadToken(bucket);
//            try {
//                Response response = uploadManager.put(inputStream,key,upToken,null, null);
//                //解析上传成功的结果
//                DefaultPutRet putRet = new Gson().fromJson(response.bodyString(), DefaultPutRet.class);
//                System.out.println(putRet.key);  // 文件名
//                System.out.println(putRet.hash);
//            } catch (QiniuException ex) {
//                Response r = ex.response;
//                System.err.println(r.toString());
//                try {
//                    System.err.println(r.bodyString());
//                } catch (QiniuException ex2) {
//                }
//            }
//        } catch (Exception ex) {
//        }
//    }

}
